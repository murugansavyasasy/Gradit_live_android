package com.vsca.vsnapvoicecollege.Adapters

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import butterknife.BindView
import butterknife.ButterKnife
import com.vsca.vsnapvoicecollege.Activities.*
import com.vsca.vsnapvoicecollege.ActivitySender.AddAssignment
import com.vsca.vsnapvoicecollege.ActivitySender.AddRecipients
import com.vsca.vsnapvoicecollege.ActivitySender.Assignment_Submition
import com.vsca.vsnapvoicecollege.Model.GetAssignmentDetails
import com.vsca.vsnapvoicecollege.R
import com.vsca.vsnapvoicecollege.Utils.CommonUtil
import com.vsca.vsnapvoicecollege.Utils.CommonUtil.isExpandAdapter

class AssignmentAdapter constructor(data: List<GetAssignmentDetails>, context: Context) :
    RecyclerView.Adapter<AssignmentAdapter.MyViewHolder>() {
    var assignmentdata: List<GetAssignmentDetails> = ArrayList()
    var context: Context
    var Position: Int = 0
    private var mExpandedPosition: Int = -1
    private var pathlist: ArrayList<String>? = null
    val list: List<String> = ArrayList()
    var filepath: String? = null
    var ScreenName: String? = null


    var Imagepath: String? = null
    private lateinit var pdfUri: Uri
    var filecount: Int? = null
    var Multiplefile: ArrayList<String>? = null
    var filepathassignment: String? = null
    var Assignmnetview: String? = null
    var Type = ""

    public override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView: View = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.assignment_list_design, parent, false)
        return MyViewHolder(itemView)
    }

    public override fun onBindViewHolder(
        holder: MyViewHolder, @SuppressLint("RecyclerView") positionindex: Int
    ) {
        val data: GetAssignmentDetails = assignmentdata.get(positionindex)
        Position = holder.getAbsoluteAdapterPosition()
        holder.lblNoticeboardTitle!!.setText(data.topic)
        try {

            val createdDateTime: String = data.createdon.toString()
            val firstvalue: Array<String> = createdDateTime.split("-".toRegex()).toTypedArray()
            val createddate: String = firstvalue.get(0)
            holder.lblNoticeboardDate!!.setText(createddate)
            val createdTime: String = firstvalue.get(1)
            holder.lblNoticetime!!.setText(createdTime)
            val isExpanded: Boolean = positionindex == mExpandedPosition
            holder.rytNotice!!.setVisibility(if (isExpanded) View.VISIBLE else View.GONE)
            holder.lnrNoticeboardd!!.setActivated(isExpanded)
            holder.lnrNoticeboardd!!.setVisibility(View.VISIBLE)

            if (data.isappread.equals("0")) {
                holder.lblNewCircle!!.visibility = View.VISIBLE
            } else {
                holder.lblNewCircle!!.visibility = View.GONE
            }

            if (isExpanded) {
                isExpandAdapter = true
                holder.imgArrowdown!!.setImageResource(R.drawable.ic_arrow_up_blue)
                Type = "assignment"

                if (data.isappread.equals("0")) {
                    Log.d("appread", data.isappread!!)
                    BaseActivity.AppReadStatusContext(context, Type, data.assignmentdetailid!!)
                    Log.d("msgdetailid", data.assignmentdetailid!!)
                }
            } else {
                isExpandAdapter = false
                holder.imgArrowdown!!.setImageResource(R.drawable.ic_arrow_down_blue)
            }

//            if (!(data.userfilename == "")) {
//                val filename: String = data.userfilename!!
//                Log.d("filename", filename)
//                Log.d("filename", filename)
//                val file: Array<String> = filename.split("/".toRegex()).toTypedArray()
//                val Stringone: String = file.get(0)
//                val StringTwo: String = file.get(1)
//                filepath = file.get(2)
//            }

            holder.lnrNoticeboardd!!.setOnClickListener(object : View.OnClickListener {
                public override fun onClick(view: View) {
                    holder.lblNoticeboardDescription!!.setText(data.description)
                    holder.lblNoticePostedby!!.setText(data.sentbyname)
                    holder.lblSubmitedOn!!.setText(data.submissiondate)
                    CommonUtil.Assignmentid = data.assignmentid.toString()
                    if ((CommonUtil.Priority == "p4") || (CommonUtil.Priority == "p5") || (CommonUtil.Priority == "p6")) {
                        holder.LayoutSubmissions!!.setVisibility(View.VISIBLE)
                        holder.lblPreviousSubmission!!.setVisibility(View.VISIBLE)
                        holder.lblAssingmentSubmit!!.setVisibility(View.VISIBLE)
                        holder.lblAssingmentSubmition!!.setVisibility(View.GONE)
                    }

                    if ((CommonUtil.Priority == "p1") || (CommonUtil.Priority == "p2") || (CommonUtil.Priority == "p3")) {
                        val Createdby: String = data.createdby!!

                      //  if (CommonUtil.MemberId == Createdby.toInt()) {

                            if (data.submittedcount.equals("1")) {

                                holder.LayoutSubmissions!!.setVisibility(View.VISIBLE)
                                holder.lblPreviousSubmission!!.setVisibility(View.GONE)
                                holder.lblAssingmentSubmit!!.setVisibility(View.GONE)
                                holder.lblAssingmentSubmition!!.setVisibility(View.VISIBLE)
                                holder.lnrForward!!.setVisibility(View.VISIBLE)

                            } else if (data.createdby == CommonUtil.MemberId.toString()) {

                                holder.lnrForward!!.setVisibility(View.VISIBLE)
                                holder.LayoutSubmissions!!.setVisibility(View.VISIBLE)
                                holder.lblPreviousSubmission!!.setVisibility(View.GONE)
                                holder.lblAssingmentSubmit!!.setVisibility(View.GONE)
                                holder.lblAssingmentSubmition!!.setVisibility(View.VISIBLE)

                            } else {

                                holder.lnrForward!!.setVisibility(View.GONE)
                                holder.LayoutSubmissions!!.setVisibility(View.GONE)
                                holder.lblPreviousSubmission!!.setVisibility(View.GONE)
                                holder.lblAssingmentSubmit!!.setVisibility(View.GONE)
                                holder.lblAssingmentSubmition!!.setVisibility(View.GONE)
                            }
                   //     }
                    }

                    if ((data.assignmenttype == "image") || (data.assignmenttype == "video") || (data.assignmenttype == "pdf")) {

                        if (data.newfilepath != null) {

                            holder.rytAssignmentFiles!!.setVisibility(View.VISIBLE)
                            pathlist = data.newfilepath as ArrayList<String>?

                            val filecount: Int = pathlist!!.size
                            if (filecount > 1) {

                                val totalcount: Int = filecount - 1
                                holder.lblFileCount!!.setVisibility(View.VISIBLE)
                                holder.lblFileCount!!.setText("+" + totalcount.toString())

                            } else {
                                holder.lblFileCount!!.setVisibility(View.GONE)
                            }

                            for (j in pathlist!!.indices) {

                                holder.lnrAttachment!!.setOnClickListener {
                                    if (filecount > 1) {
                                        CommonUtil.filetype=""
                                        Assignmnetview = "AssignmentData"

                                        if (data.assignmenttype.equals("image")) {
                                            val i: Intent = Intent(
                                                context,
                                                Assignment_MultipleFileView::class.java
                                            )
                                            CommonUtil.filetype="Assignment"
                                            //     i.putExtra("Assignment", Assignmnetview)
                                            CommonUtil.Multipleiamge =
                                                (data.newfilepath as java.util.ArrayList<String>?)!!
                                            context.startActivity(i)

                                        } else if (data.assignmenttype.equals("pdf")) {
                                            val i: Intent = Intent(
                                                context,
                                                Assignment_MultipleFileView::class.java
                                            )
                                            i.putExtra("Assignmentmultiplepdf", pathlist!![j])
                                            context.startActivity(i)
                                        }
                                    } else {

                                        if (data.assignmenttype.equals("image")) {
                                            val i: Intent = Intent(context, ViewFiles::class.java)
                                            i.putExtra("images", pathlist!![j])
                                            context.startActivity(i)

                                        } else if (data.assignmenttype.equals("pdf")) {
                                            pdfUri = Uri.parse(pathlist!![j])
                                            readpdf()

                                        } else if (data.assignmenttype.equals("video")) {

                                            Toast.makeText(
                                                context,
                                                "Video File Is Empty",
                                                Toast.LENGTH_LONG
                                            ).show()

                                            // if you want to send the assignment in video type uncomment this beloo code

                                            //   CommonUtil.VimeoIframe = pathlist!![j]
//                                            if (CommonUtil.VimeoIframe != null) {
//                                                val filename: String =
//                                                    CommonUtil.VimeoIframe.toString()
//                                                val file: Array<String> =
//                                                    filename.split("src=".toRegex()).toTypedArray()
//                                                val Stringone: String = file.get(0)
//                                                val StringTwo: String = file.get(1)
//
//                                                val filenamefinal: String = StringTwo
//                                                val filevideo: Array<String> =
//                                                    filenamefinal.split(" ".toRegex())
//                                                        .toTypedArray()
//                                                val Stringonevideo: String = filevideo.get(0)
//                                                val StringTwovideo: String = filevideo.get(1)
//
//                                                val videourl = Stringonevideo
//                                                val videoiframe = videourl.replace("\"", "")
//                                                Log.d("videoiframe", videoiframe)
//
//                                                val i: Intent =
//                                                    Intent(context, VideoPlay::class.java)
//                                                i.putExtra("iframe", videoiframe)
//                                                i.putExtra("title", data.topic)
//                                                i.putExtra("description", data.description)
//                                                context.startActivity(i)
//                                            }
                                        }
                                    }
                                }
                            }
                        }

                    } else if (data.assignmenttype == "All" || data.assignmenttype == "text") {
                        holder.rytAssignmentFiles!!.setVisibility(View.GONE)
                    }
                    mExpandedPosition = if (isExpanded) -1 else positionindex
                    notifyDataSetChanged()
                }
            })

        } catch (e: NullPointerException) {
            e.printStackTrace()
        }

        holder.lnrForward!!.setOnClickListener {
            ScreenName = "Forward Assignment"

            val i: Intent = Intent(context, AddRecipients::class.java)
            i.putExtra("ScreenName", ScreenName)
            context.startActivity(i)
        }

        holder.lblAssingmentSubmit!!.setOnClickListener {
            ScreenName = "Assignment Submit"
            val i: Intent = Intent(context, AddAssignment::class.java)
            i.putExtra("ScreenName", ScreenName)
            context.startActivity(i)
        }

        holder.lblAssingmentSubmition!!.setOnClickListener {

            CommonUtil.Assignmentid = data.assignmentid.toString()
            val i: Intent = Intent(context, Assignment_Submition::class.java)
            context.startActivity(i)
        }

        holder.lblPreviousSubmission!!.setOnClickListener {

            CommonUtil.Assignmentid = data.assignmentid.toString()
            val i: Intent = Intent(context, Assignment_Submition::class.java)
            CommonUtil.filetype="Assignment previous Submited"
            context.startActivity(i)

        }
    }

    fun readpdf() {
        val intent = Intent(Intent.ACTION_VIEW)
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        intent.setClipData(ClipData.newRawUri("", pdfUri))
        intent.setDataAndType((pdfUri), "application/pdf")
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        context.startActivity(intent)
    }

    public override fun getItemCount(): Int {
        return assignmentdata.size
    }

    inner class MyViewHolder constructor(itemView: View?) : RecyclerView.ViewHolder(
        (itemView)!!
    ) {
        @JvmField
        @BindView(R.id.lblNoticeboardTitle)
        var lblNoticeboardTitle: TextView? = null

        @JvmField
        @BindView(R.id.lblNoticeboardDescription)
        var lblNoticeboardDescription: TextView? = null

        @JvmField
        @BindView(R.id.lblNoticeboardDate)
        var lblNoticeboardDate: TextView? = null

        @JvmField
        @BindView(R.id.lblNoticetime)
        var lblNoticetime: TextView? = null

        @JvmField
        @BindView(R.id.lblNoticePostedby)
        var lblNoticePostedby: TextView? = null

        @JvmField
        @BindView(R.id.lblSubmitedOn)
        var lblSubmitedOn: TextView? = null

        @JvmField
        @BindView(R.id.rytNotice)
        var rytNotice: RelativeLayout? = null

        @JvmField
        @BindView(R.id.lnrNoticeboardd)
        var lnrNoticeboardd: LinearLayout? = null

        @JvmField
        @BindView(R.id.LayoutSubmissions)
        var LayoutSubmissions: LinearLayout? = null

        @JvmField
        @BindView(R.id.imgArrowdown)
        var imgArrowdown: ImageView? = null

        @JvmField
        @BindView(R.id.rytAssignmentFiles)
        var rytAssignmentFiles: RelativeLayout? = null

        @JvmField
        @BindView(R.id.lblFileCount)
        var lblFileCount: TextView? = null

        @JvmField
        @BindView(R.id.lnrForward)
        var lnrForward: LinearLayout? = null

        @JvmField
        @BindView(R.id.lnrAttachment)
        var lnrAttachment: LinearLayout? = null

        @JvmField
        @BindView(R.id.lblAssignmentPath)
        var lblAssignmentPath: TextView? = null

        @JvmField
        @BindView(R.id.lblNewCircle)
        var lblNewCircle: TextView? = null

        @JvmField
        @BindView(R.id.lblPreviousSubmission)
        var lblPreviousSubmission: TextView? = null

        @JvmField
        @BindView(R.id.lblAssingmentSubmition)
        var lblAssingmentSubmition: TextView? = null

        @JvmField
        @BindView(R.id.lblAssingmentSubmit)
        var lblAssingmentSubmit: TextView? = null

        init {
            ButterKnife.bind(this, (itemView)!!)
        }
    }

    init {
        assignmentdata = data
        this.context = context
    }
}