package com.vsca.vsnapvoicecollege.Adapters

import com.vsca.vsnapvoicecollege.Model.DashboardSubItems
import com.vsca.vsnapvoicecollege.Model.Sectiondetail
import java.util.ArrayList

class Facultyoverall(

    var Facultyoverall: ArrayList<Sectiondetail>
)
