package com.vsca.vsnapvoicecollege.Adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import butterknife.BindView
import butterknife.ButterKnife
import com.vsca.vsnapvoicecollege.Model.Get_staff_yourclass
import com.vsca.vsnapvoicecollege.R
import com.vsca.vsnapvoicecollege.Utils.CommonUtil


class Subject_Adapter constructor(data: List<Get_staff_yourclass>, context: Context) :
    RecyclerView.Adapter<Subject_Adapter.MyViewHolder>() {
    var subjectdata: List<Get_staff_yourclass> = ArrayList()
    var context: Context
    var selectedPosition: Int? = null
    override fun onCreateViewHolder(
        parent: ViewGroup, viewType: Int
    ): Subject_Adapter.MyViewHolder {
        val itemView: View = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.staffselection_layout, parent, false)
        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val data: Get_staff_yourclass = subjectdata.get(position)

        holder.txt_financeandaccounding!!.setText(data.coursename)
        holder.txt_bcom_Accounts!!.setText(data.yearname)
        holder.txt_year1!!.setText(data.semestername)
        holder.txt_semester1!!.setText(data.sectionname)
        holder.txt_date!!.setText(data.subjectname)





        holder.check_sections!!.setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener { buttonView, isChecked ->

            if (isChecked) {

                CommonUtil.receivertype = "5"
                CommonUtil.receiverid = data.sectionid.toString()
                CommonUtil.YearId = data.yearid.toString()
                CommonUtil.SectionId = data.sectionid.toString()
                CommonUtil.Courseid = data.courseid.toString()
                CommonUtil.semesterid = data.semesterid.toString()

                //CommonUtil.selectcheckbox = "1"

            } else {

//                if (CommonUtil.selectcheckbox.equals("1")){
//                    CommonUtil.selectcheckbox = "0"
//                }else{
//                    CommonUtil.selectcheckbox = "0"
//                }
            }
        })
    }

    override fun getItemCount(): Int {
        return subjectdata.size

    }

    inner class MyViewHolder constructor(itemView: View?) : RecyclerView.ViewHolder(
        (itemView)!!
    ) {
        @JvmField
        @BindView(R.id.txt_financeandaccounding)
        var txt_financeandaccounding: TextView? = null

        @JvmField
        @BindView(R.id.txt_bcom_Accounts)
        var txt_bcom_Accounts: TextView? = null

        @JvmField
        @BindView(R.id.txt_year1)
        var txt_year1: TextView? = null

        @JvmField
        @BindView(R.id.txt_semester1)
        var txt_semester1: TextView? = null

        @JvmField
        @BindView(R.id.txt_date)
        var txt_date: TextView? = null

        @JvmField
        @BindView(R.id.check_sections)
        var check_sections: CheckBox? = null

        @JvmField
        @BindView(R.id.txt_selectspecfic)
        var txt_selectspecfic: TextView? = null


        init {
            ButterKnife.bind(this, (itemView)!!)
        }
    }

    init {
        subjectdata = data
        this.context = context
    }

}