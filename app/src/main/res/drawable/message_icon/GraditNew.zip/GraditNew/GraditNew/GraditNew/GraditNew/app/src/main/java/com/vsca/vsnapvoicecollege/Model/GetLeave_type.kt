package com.vsca.vsnapvoicecollege.Model

data class GetLeave_type(
    val Message: String,
    val Status: Int,
    val `data`: List<DataXXX>
)