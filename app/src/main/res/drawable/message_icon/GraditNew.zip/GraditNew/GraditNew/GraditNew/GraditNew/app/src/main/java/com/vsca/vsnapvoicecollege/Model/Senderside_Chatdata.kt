package com.vsca.vsnapvoicecollege.Model

data class Senderside_Chatdata(
    val answer: String,
    val answeredon: String,
    val changeanswer: String,
    val createdon: String,
    val is_student_blocked: String,
    val question: String,
    val questionid: String,
    val replytype: String,
    val studentid: String,
    val studentname: String
)