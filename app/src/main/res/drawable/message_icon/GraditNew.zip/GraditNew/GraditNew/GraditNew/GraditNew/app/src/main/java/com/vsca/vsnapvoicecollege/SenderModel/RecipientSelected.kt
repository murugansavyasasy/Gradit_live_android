package com.vsca.vsnapvoicecollege.SenderModel

import java.io.Serializable

class RecipientSelected(val SelectedId: String?, var SelectedName: String?) :
    Serializable {
}