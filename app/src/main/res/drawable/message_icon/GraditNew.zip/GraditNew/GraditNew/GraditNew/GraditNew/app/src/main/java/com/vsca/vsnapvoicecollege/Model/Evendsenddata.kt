package com.vsca.vsnapvoicecollege.Model

data class Evendsenddata (
    val Message: String,
    val Status: Int
)