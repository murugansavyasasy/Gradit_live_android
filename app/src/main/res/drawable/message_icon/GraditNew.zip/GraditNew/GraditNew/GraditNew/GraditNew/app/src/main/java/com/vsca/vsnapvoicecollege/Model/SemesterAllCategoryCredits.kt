package com.vsca.vsnapvoicecollege.Model

import java.util.ArrayList

class SemesterAllCategoryCredits(var CategoryNames: String, var smesterCredits: ArrayList<SemesterAllCategory>)