package com.vsca.vsnapvoicecollege.Model

data class Assignment_Forward(
    val Message: String,
    val Status: Int
)