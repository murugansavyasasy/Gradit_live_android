package com.vsca.vsnapvoicecollege.Adapters

class Examinationdata(sectionname: String?) {

    var sectioname: String? = sectionname
}