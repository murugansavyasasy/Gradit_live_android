package com.vsca.vsnapvoicecollege.Model

 class Assignment_Submittion(
    val Message: String,
    val Status: Int,
    val `data`: ArrayList<AssignmentSubmit>
)