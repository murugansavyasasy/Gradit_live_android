package com.vsca.vsnapvoicecollege.Model

data class VideoParticulerSend(
    val Message: String,
    val Status: Int,
    val `data`: List<DataXXXXXXX>
)