package com.vsca.vsnapvoicecollege.albumImage;

public class Album {
    public String name;
    public String cover;
    public String count;

    public Album(String name, String cover,String count) {
        this.name = name;
        this.cover = cover;
        this.count=count;
    }
}