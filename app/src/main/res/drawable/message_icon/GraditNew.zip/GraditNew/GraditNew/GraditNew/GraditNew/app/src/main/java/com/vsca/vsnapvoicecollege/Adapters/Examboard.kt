package com.vsca.vsnapvoicecollege.Adapters

class Examboard {

    var sectionname: String? = null
    var sectionid: String? = null

    constructor(
        sectionname: String?,
        sectionid: String?,
    ) {
        this.sectionname = sectionname
        this.sectionid = sectionid
    }
}