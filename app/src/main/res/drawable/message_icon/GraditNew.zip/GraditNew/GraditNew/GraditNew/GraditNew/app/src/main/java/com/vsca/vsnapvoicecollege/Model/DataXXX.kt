package com.vsca.vsnapvoicecollege.Model

data class DataXXX(
    val leavetypeid: String,
    val leavetypename: String
)