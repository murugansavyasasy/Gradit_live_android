package com.vsca.vsnapvoicecollege.Model

data class AssignmentSubmit(
    val course: String,
    val message: String,
    val section: String,
    val semester: String,
    val studentid: String,
    val studentname: String,
    val year: String
)