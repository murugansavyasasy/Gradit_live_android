package com.vsca.vsnapvoicecollege.AWS;

import com.amazonaws.regions.Regions;

public  class AWSKeys {

    // protected static final String COGNITO_POOL_ID = "us-east-1:dc2aacee-9de5-4e7c-a104-1a4b20ec2cbd";
    protected static final String COGNITO_POOL_ID = "us-east-1:dc2aacee-9de5-4e7c-a104-1a4b20ec2cbd";
    protected static final Regions MY_REGION = Regions.US_EAST_1; /*Change Region Here*/
    public static final String BUCKET_NAME ="college-app-files";
}
