package com.vsca.vsnapvoicecollege.Adapters

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView
import butterknife.BindView
import butterknife.ButterKnife
import com.vsca.vsnapvoicecollege.Model.ChatList
import com.vsca.vsnapvoicecollege.R
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class Chat_Text_adapter(
    var marklist: List<ChatList>,
    private val context: Context?,
) : RecyclerView.Adapter<Chat_Text_adapter.MyViewHolder>() {

    var Position: Int = 0
    var Livedate: String? = null
    var Livedateanswer: String? = null

    inner class MyViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        @JvmField
        @BindView(R.id.txt_financeandaccounding)
        var txt_financeandaccounding: TextView? = null

        @JvmField
        @BindView(R.id.txt_date)
        var txt_date: TextView? = null


        @JvmField
        @BindView(R.id.txt_testing_creating)
        var txt_testing_creating: TextView? = null

        @JvmField
        @BindView(R.id.txt_testing_creatingans)
        var txt_testing_creatingans: TextView? = null

        @JvmField
        @BindView(R.id.txt_financeandaccoundingans)
        var txt_financeandaccoundingans: TextView? = null

        @JvmField
        @BindView(R.id.examlist_constrineans)
        var examlist_constrineans: ConstraintLayout? = null

        @JvmField
        @BindView(R.id.txt_dateans)
        var txt_dateans: TextView? = null

        @JvmField
        @BindView(R.id.txt_question)
        var txt_question: TextView? = null


        init {
            ButterKnife.bind(this, (itemView))
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.chat_list, parent, false)
        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val data = marklist[position]


        val filename: String = data.createdon
        val file: Array<String> =
            filename.split(":".toRegex()).toTypedArray()
        val Stringone: String = file.get(0)
        val StringTwo: String = file.get(1)

        Livedate = Stringone + ":" + StringTwo

        holder.txt_date!!.setText(Livedate)
        holder.txt_testing_creating!!.setText(data.question)
        holder.txt_financeandaccounding!!.setText(data.studentname)



        if (data.answer.equals("Not answered yet")) {
            holder.examlist_constrineans!!.visibility = View.GONE
        } else {
            holder.examlist_constrineans!!.visibility = View.VISIBLE
            holder.txt_testing_creatingans!!.setText(data.answer)

            val filename1: String = data.answeredon
            val file1: Array<String> =
                filename1.split(":".toRegex()).toTypedArray()
            val Stringone1: String = file1.get(0)
            val StringTwo1: String = file1.get(1)

            Livedateanswer = Stringone1 + ":" + StringTwo1

            holder.txt_dateans!!.setText(Livedateanswer)
            holder.txt_financeandaccoundingans!!.setText(data.studentname)
            holder.txt_question!!.setText(data.question)
        }
    }

    override fun getItemCount(): Int {
        return marklist.size
    }
}