package com.vsca.vsnapvoicecollege.Adapters

import android.app.DatePickerDialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView
import butterknife.BindView
import butterknife.ButterKnife
import com.vsca.vsnapvoicecollege.Activities.Events
import com.vsca.vsnapvoicecollege.Model.*
import com.vsca.vsnapvoicecollege.R
import com.vsca.vsnapvoicecollege.Utils.CommonUtil
import java.util.Calendar

class Subject_List(data: List<Subjectdetail>, context: Context) :
    RecyclerView.Adapter<Subject_List.MyViewHolder>() {
    var subjectlist: List<Subjectdetail> = ArrayList()
    var context: Context
    var Position: Int = 0
    var mExpandedPosition = -1

    var date: String? = null
    var description: String? = null
    var title: String? = null
    var section: String? = null

    var Examination_Creation: List<Examination_Creation> = java.util.ArrayList()
    var Sectiondetail_ExamCreation: List<Sectiondetail_ExamCreation> = java.util.ArrayList()
    var Subjectdetail_ExamCreation: List<Subjectdetail_ExamCreation> = java.util.ArrayList()


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Subject_List.MyViewHolder {
        val itemView: View = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.subjectlist_particuler, parent, false)
        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: Subject_List.MyViewHolder, position: Int) {

        val data: Subjectdetail = subjectlist.get(position)

        holder.txt_test!!.setText(data.subjectname)

        val isExpanded = position == mExpandedPosition

        holder.constrine_test!!.setOnClickListener {

            if (isExpanded) {

                holder.tick1!!.setBackgroundResource(R.drawable.black_backroundtick)
                holder.down1!!.setBackgroundResource(R.drawable.ic_arrow_down)
                mExpandedPosition = if (isExpanded) -1 else position
                holder.constrin_second!!.visibility = View.GONE
                notifyDataSetChanged()

            } else {

                CommonUtil.examsubjectid = data.subjectid
                holder.tick1!!.setBackgroundResource(R.drawable.examinatin_changeexpandclolur)
                holder.down1!!.setBackgroundResource(R.drawable.ic_arraow_up)
                mExpandedPosition = if (isExpanded) -1 else position
                holder.constrin_second!!.visibility = View.VISIBLE
                notifyDataSetChanged()
            }
        }

        holder.start_date!!.setOnClickListener {


              holder.start_date?.let { it1 -> CommonUtil.Datepickeradaptersetavailabledate(context, it1) }
        }

        holder.txt_session1!!.setOnClickListener {

            val popupMenu = PopupMenu(context, holder.txt_session1)
            popupMenu.menuInflater.inflate(R.menu.fn_or_an, popupMenu.menu)
            popupMenu.setOnMenuItemClickListener { menuItem ->

                holder.txt_session1!!.setText(menuItem.title)

                true
            }
            popupMenu.show()
        }


        holder.btn_save!!.setOnClickListener {


            date = holder.start_date!!.text.toString()
            section = holder.txt_session1!!.text.toString()
            description = holder.txtDescription!!.text.toString()
            title = holder.txtTitle!!.text.toString()

//            CommonUtil.Venue = title.toString()
//            CommonUtil.examsyllabus = description.toString()
//            CommonUtil.examdate = date.toString()
//            CommonUtil.section = section.toString()


            if (date.isNullOrEmpty() || section.isNullOrEmpty() || description.isNullOrEmpty() || title.isNullOrEmpty()) {

                Toast.makeText(context, "Fill the all fields", Toast.LENGTH_SHORT).show()

            } else {

                CommonUtil.Subjectdetail_ExamCreation.add(
                    Subjectdetail_ExamCreation(
                        date,
                        section,
                        CommonUtil.examsubjectid,
                        description,
                        title
                    )
                )
                Log.d("examsessionsu", CommonUtil.Subjectdetail_ExamCreation.toString())


                var message: String? = null
                message = "Are you want to save... "
                val dlg = context.let { AlertDialog.Builder(it) }
                dlg.setTitle("Info")
                dlg.setMessage(message)
                dlg.setPositiveButton("Yes", DialogInterface.OnClickListener { dialog, which ->


                    var message1: String? = null
                    message1 = "Save Successfully... "
                    val dlg1 = context.let { AlertDialog.Builder(it) }
                    dlg1.setTitle("Info")
                    dlg1.setMessage(message1)
                    dlg1.setPositiveButton("OK", DialogInterface.OnClickListener { dialog, which ->

                        holder.tick1!!.setBackgroundResource(R.drawable.black_backroundtick)
                        holder.down1!!.setBackgroundResource(R.drawable.ic_arrow_down)
                        holder.constrin_second!!.visibility = View.GONE

                    })

                    dlg1.setCancelable(false)
                    dlg1.create()
                    dlg1.show()


                })

                dlg.setCancelable(false)
                dlg.create()
                dlg.show()
            }
        }
    }

    override fun getItemCount(): Int {
        return subjectlist.size
    }

    inner class MyViewHolder constructor(itemView: View?) : RecyclerView.ViewHolder(
        (itemView)!!
    ) {

        @JvmField
        @BindView(R.id.constrine_test)
        var constrine_test: ConstraintLayout? = null

        @JvmField
        @BindView(R.id.constrin_second)
        var constrin_second: ConstraintLayout? = null

        @JvmField
        @BindView(R.id.txtTitle)
        var txtTitle: EditText? = null

        @JvmField
        @BindView(R.id.txtDescription)
        var txtDescription: EditText? = null

        @JvmField
        @BindView(R.id.start_date)
        var start_date: TextView? = null


        @JvmField
        @BindView(R.id.down1)
        var down1: TextView? = null

        @JvmField
        @BindView(R.id.txt_session1)
        var txt_session1: TextView? = null

        @JvmField
        @BindView(R.id.txt_test)
        var txt_test: TextView? = null

        @JvmField
        @BindView(R.id.tick1)
        var tick1: TextView? = null


        @JvmField
        @BindView(R.id.btn_save)
        var btn_save: Button? = null

        init {
            ButterKnife.bind(this, (itemView)!!)
        }
    }

    init {
        if (data != null) {
            subjectlist = data
        }
        this.context = context
    }
}