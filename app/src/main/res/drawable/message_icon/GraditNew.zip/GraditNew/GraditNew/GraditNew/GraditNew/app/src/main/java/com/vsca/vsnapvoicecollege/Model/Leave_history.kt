package com.vsca.vsnapvoicecollege.Model

data class Leave_history(
    val Message: String, val Status: Int, val `data`: List<DataXXXX>
)