package com.vsca.vsnapvoicecollege.Model

data class Attendance_edit_List(
    val attendancetype: String,
    val memberid: String,
    val membername: String,
    val rollno: String
)