package com.vsca.vsnapvoicecollege.Activities

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.CompoundButton
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView
import butterknife.BindView
import butterknife.ButterKnife
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.vsca.vsnapvoicecollege.Model.AttendanceMark
import com.vsca.vsnapvoicecollege.Model.specificStudent_datalist
import com.vsca.vsnapvoicecollege.R
import com.vsca.vsnapvoicecollege.Repository.RestClient
import com.vsca.vsnapvoicecollege.Utils.CommonUtil
import okhttp3.internal.commonEmptyHeaders
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.ArrayList

class Specific_StudentList constructor(data: List<specificStudent_datalist>, context: Context) :
    RecyclerView.Adapter<Specific_StudentList.MyViewHolder>() {
    var specificstudentdata: List<specificStudent_datalist> = ArrayList()
    var context: Context
    var seleteddataArray = ArrayList<String>()
    var seletedStringdata: String? = null
    var PresendlistStudent: String? = null

    var AttendanceAbsendid = ArrayList<String>()
    var ABsend = ArrayList<String>()


    inner class MyViewHolder constructor(itemView: View?) : RecyclerView.ViewHolder(
        (itemView)!!
    ) {
        @JvmField
        @BindView(R.id.lblEntiredepartment)
        var lblEntiredepartment: TextView? = null

        @JvmField
        @BindView(R.id.chboxEntiredepartment)
        var chboxEntiredepartment: CheckBox? = null

        init {
            ButterKnife.bind(this, (itemView)!!)
        }
    }

    init {
        specificstudentdata = data
        this.context = context
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {

        val itemView: View = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.specific_student, parent, false)
        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val data: specificStudent_datalist = specificstudentdata.get(position)
        holder.lblEntiredepartment!!.setText(data.name)

        CommonUtil.PresentlistStudent.clear()
        CommonUtil.AttendanceAbsendid.clear()
        holder.chboxEntiredepartment!!.setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener { buttonView, isChecked ->

            if (isChecked) {
                CommonUtil.AttendanceAbsendid.remove(data.memberid.toString())

                seleteddataArray.add(data.memberid.toString())
                holder.chboxEntiredepartment!!.isChecked = true

                CommonUtil.PresentlistStudent.add(data.memberid.toString())
                Log.d("Attendance_P", CommonUtil.PresentlistStudent.toString())

            } else  {

                CommonUtil.PresentlistStudent.remove(data.memberid.toString())

                CommonUtil.AttendanceAbsendid.add(data.memberid.toString())
                Log.d("Attendance_A", CommonUtil.AttendanceAbsendid.toString())

                seleteddataArray.remove(data.memberid.toString())
                holder.chboxEntiredepartment!!.isChecked = false
            }


            for (i in seleteddataArray) {
                seletedStringdata = seleteddataArray.toString()
            }
            if (seleteddataArray.size > 0) {
                CommonUtil.receiverid = seletedStringdata.toString()
            } else {
                CommonUtil.receiverid = ""
            }
        })
    }

    override fun getItemCount(): Int {
        return specificstudentdata.size
    }

}