package com.vsca.vsnapvoicecollege.Model

data class Chat_StaffList(
    val Message: String,
    val Status: Int,
    val `data`: List<DataX>
)