package com.vsca.vsnapvoicecollege.Model

data class ExamCreation_dataclass(
    val Message: String,
    val Status: Int,
    val `data`: List<Examcreationdata>
)