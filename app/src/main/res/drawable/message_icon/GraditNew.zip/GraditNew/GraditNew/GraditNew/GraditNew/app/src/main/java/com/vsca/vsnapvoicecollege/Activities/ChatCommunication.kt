package com.vsca.vsnapvoicecollege.Activities

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import butterknife.BindView
import butterknife.ButterKnife
import butterknife.OnClick
import com.google.gson.JsonObject
import com.vsca.vsnapvoicecollege.Adapters.ChatSenderSide_Adapter
import com.vsca.vsnapvoicecollege.Adapters.Chat_Text_adapter
import com.vsca.vsnapvoicecollege.Interfaces.ChatClickListener
import com.vsca.vsnapvoicecollege.Model.*
import com.vsca.vsnapvoicecollege.R
import com.vsca.vsnapvoicecollege.Repository.ApiRequestNames
import com.vsca.vsnapvoicecollege.Utils.CommonUtil
import com.vsca.vsnapvoicecollege.ViewModel.App
import java.util.*


class ChatCommunication : BaseActivity() {

    var Chat_Text_adapter: Chat_Text_adapter? = null
    var ChatSenderSide_Adapter: ChatSenderSide_Adapter? = null
    override var appViewModel: App? = null
    var chat_offset_List: ArrayList<chat_offset_List>? = null
    var SenderSide_ChatModel: ArrayList<SenderSide_ChatModel>? = null
    var Senderside_Chatdata: List<Senderside_Chatdata>? = null
    var ChatList: List<ChatList>? = null


    @JvmField
    @BindView(R.id.recyclerCommon)
    var recyclerNoticeboard: RecyclerView? = null

    @JvmField
    @BindView(R.id.txt_replayConstrine)
    var txt_replayConstrine: ConstraintLayout? = null

    @JvmField
    @BindView(R.id.layoutSend)
    var layoutSend: ConstraintLayout? = null

    @JvmField
    @BindView(R.id.txt_replay)
    var txt_replay: TextView? = null

    @JvmField
    @BindView(R.id.lblNoChats)
    var lblNoChats: TextView? = null

    @JvmField
    @BindView(R.id.recyclerChat)
    var recyclerChat: RecyclerView? = null

    @JvmField
    @BindView(R.id.img_delete)
    var img_delete: ImageView? = null

    @JvmField
    @BindView(R.id.imgAdvertisement)
    var imgAdvertisement: ImageView? = null

    @JvmField
    @BindView(R.id.imgthumb)
    var imgthumb: ImageView? = null

    @JvmField
    @BindView(R.id.lbltotalsize)
    var lbltotalsize: TextView? = null

    @JvmField
    @BindView(R.id.lblMenuTitle)
    var lblMenuTitle: TextView? = null

    @JvmField
    @BindView(R.id.lblDepartment)
    var lblDepartment: TextView? = null

    @JvmField
    @BindView(R.id.layoutTab)
    var layoutTab: ConstraintLayout? = null


    @JvmField
    @BindView(R.id.txt_onandoff)
    var txt_onandoff: ConstraintLayout? = null

    @JvmField
    @BindView(R.id.lblContent)
    var lblContent: EditText? = null

    @JvmField
    @BindView(R.id.imgSend)
    var imgSend: ImageView? = null

    @JvmField
    @BindView(R.id.switchonAndoff)
    var switchonAndoff: Switch? = null

    @JvmField
    @BindView(R.id.lbl_switchLable)
    var lbl_switchLable: TextView? = null

    @JvmField
    @BindView(R.id.lblNoRecordsFound)
    var lblNoRecordsFound: TextView? = null


    @JvmField
    @BindView(R.id.lblyear)
    var lblyear: TextView? = null

    @JvmField
    @BindView(R.id.lblsemester)
    var lblsemester: TextView? = null

    @JvmField
    @BindView(R.id.lblsection)
    var lblsection: TextView? = null

    @JvmField
    @BindView(R.id.lblcourse)
    var lblcourse: TextView? = null

    @JvmField
    @BindView(R.id.lblsubject)
    var lblsubject: TextView? = null

    var GetVideoListData: List<GetVideoListDetails> = ArrayList()
    var CountVideo = "0"
    var textstudent: String? = null
    var Yearname: String? = null
    var semestername: String? = null
    var sectionname: String? = null
    var coursename: String? = null
    var subjectname: String? = null
    var staffname: String? = null
    var ReplayType: String? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        CommonUtil.SetTheme(this)

        super.onCreate(savedInstanceState)
        appViewModel = ViewModelProvider(this).get(App::class.java)
        appViewModel!!.init()
        ButterKnife.bind(this)
        ActionBarMethod(this)
        MenuBottomType()
        BaseActivity.UserMenuRequest(this)

        ReplayType = "2"

        if (CommonUtil.Priority.equals("p1") || CommonUtil.Priority.equals("p2") || CommonUtil.Priority.equals(
                "p3"
            )
        ) {
            layoutSend!!.visibility = View.GONE
            lblsemester!!.visibility = View.VISIBLE
            lblsection!!.visibility = View.VISIBLE
            lblsubject!!.visibility = View.VISIBLE

            Yearname = CommonUtil.yearnamae
            semestername = CommonUtil.semestername
            sectionname = CommonUtil.sectionname
            coursename = CommonUtil.coursename
            subjectname = CommonUtil.subjectname
            Log.d("Year_Name", Yearname.toString())

            lblyear!!.setText(Yearname)
            lblcourse!!.setText(coursename)
            lblsection!!.setText(sectionname)
            lblsemester!!.setText(semestername)
            lblsubject!!.setText(subjectname)

        } else if (CommonUtil.Priority.equals("p4") || CommonUtil.Priority.equals("p5")) {


            layoutSend!!.visibility = View.VISIBLE

            lblsemester!!.visibility = View.GONE
            lblsection!!.visibility = View.GONE
            lblsubject!!.visibility = View.GONE

            staffname = CommonUtil.staffname
            subjectname = CommonUtil.subjectname

            lblyear!!.setText(staffname)
            lblcourse!!.setText(subjectname)

        }

        try {
            layoutTab!!.visibility = View.GONE
            lblMenuTitle!!.setText(R.string.txt_Video)

        } catch (e: Exception) {
            e.printStackTrace()

        }

        CommonUtil.OnMenuClicks("ChatCommunication")

        imgSend!!.setOnClickListener {

            textstudent = lblContent!!.text.toString()
            CommonUtil.Textedit = textstudent.toString()
            if (CommonUtil.Priority.equals("p1") || CommonUtil.Priority.equals("p2") || CommonUtil.Priority.equals(
                    "p3"
                )
            ) {
                layoutSend!!.visibility = View.GONE

                ChatSender(ReplayType.toString())
                lblContent!!.setText("")
                ChatListSender()
                txt_replayConstrine!!.visibility = View.GONE
                txt_onandoff!!.visibility = View.GONE
                layoutSend!!.visibility=View.GONE
                ReplayType = "2"

            } else {
                layoutSend!!.visibility = View.VISIBLE

                ChatStudent()
                lblContent!!.setText("")
                ChatListStudent()
            }
        }

        imgRefresh!!.setOnClickListener(View.OnClickListener {

            if (CommonUtil.Priority.equals("p1") || CommonUtil.Priority.equals("p2") || CommonUtil.Priority.equals(
                    "p3"
                )
            ) {
                ChatListSender()
            } else {
                ChatListStudent()
            }
        })


        switchonAndoff!!.setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                ReplayType = "1"
            } else {
                ReplayType = "2"
            }
        })


        img_delete!!.setOnClickListener {
            txt_replayConstrine!!.visibility = View.GONE
            txt_onandoff!!.visibility = View.GONE
            layoutSend!!.visibility=View.GONE
            ReplayType = "2"
            txt_replay!!.setText("")
        }

        appViewModel!!.Chatstudentlist!!.observe(this) { response ->
            if (response != null) {
                val status = response.Status
                val message = response.Message
                if (status == 1) {

                } else {
                    CommonUtil.ApiAlert(this, "No Data Found")
                }
            } else {
                CommonUtil.ApiAlert(this, "Something went wrong")
            }
        }

        appViewModel!!.ChatList!!.observe(this) { response ->
            if (response != null) {
                val status = response.Status
                val message = response.Message
                if (status == 1) {
                    chat_offset_List = response.data

                    for (i in chat_offset_List!!.indices) {
                        ChatList = chat_offset_List!!.get(i).List
                    }
                    ChatList?.let { Collections.reverse(it) }

                    Chat_Text_adapter = Chat_Text_adapter(ChatList!!, this)
                    val mLayoutManager= LinearLayoutManager(this)

                    mLayoutManager.stackFromEnd = true
                    recyclerChat!!.layoutManager = mLayoutManager
                    recyclerChat!!.itemAnimator = DefaultItemAnimator()
                    recyclerChat!!.adapter = Chat_Text_adapter
                    recyclerChat!!.recycledViewPool.setMaxRecycledViews(0, 80)
                    Chat_Text_adapter!!.notifyDataSetChanged()

                } else {
                    CommonUtil.ApiAlert(this, "No Data Found")
                }

            } else {
                CommonUtil.ApiAlert(this, "Something went wrong")
            }
        }

        appViewModel!!.ChatSenderside!!.observe(this) { response ->
            if (response != null) {
                val status = response.result
                if (status.equals("1")) {
                    Senderside_Chatdata = response.data
                    Senderside_Chatdata?.let { Collections.reverse(it) }

                    ChatSenderSide_Adapter =
                        ChatSenderSide_Adapter(Senderside_Chatdata!!, this, object :

                            ChatClickListener {
                            override fun onchatClick(
                                holder: ChatSenderSide_Adapter.MyViewHolder,
                                item: Senderside_Chatdata
                            ) {
                                holder.img_dotthree!!.setOnClickListener(View.OnClickListener {

                                    CommonUtil.studentid = item.studentid
                                    CommonUtil.Questionid = item.questionid
                                    CommonUtil.StudentBlackORunblack = item.is_student_blocked

                                    if (CommonUtil.StudentBlackORunblack.equals("0")) {

                                        if (item.changeanswer.equals("0")) {

                                            CommonUtil.changeanswer = item.changeanswer
                                            val popupMenu =
                                                PopupMenu(
                                                    this@ChatCommunication,
                                                    holder.img_dotthree
                                                )
                                            popupMenu.menuInflater.inflate(
                                                R.menu.chat_replaymenu,
                                                popupMenu.menu
                                            )
                                            popupMenu.setOnMenuItemClickListener { menuItem ->
                                                var type: String? = null
                                                type = menuItem.toString()
                                                Log.d("MenuItem", type.toString())
                                                layoutSend!!.visibility = View.VISIBLE

                                                if (type.equals("Black Student")) {
                                                    BlackStudent()
                                                    ChatListSender()

                                                } else {
                                                    txt_replayConstrine!!.visibility = View.VISIBLE
                                                    txt_onandoff!!.visibility = View.VISIBLE
                                                    txt_replay!!.setText(item.question)
                                                }
                                                true
                                            }
                                            popupMenu.show()

                                        } else {

                                            CommonUtil.changeanswer = item.changeanswer
                                            val popupMenu =
                                                PopupMenu(
                                                    this@ChatCommunication,
                                                    holder.img_dotthree
                                                )
                                            popupMenu.menuInflater.inflate(
                                                R.menu.chat_changereplay,
                                                popupMenu.menu
                                            )
                                            popupMenu.setOnMenuItemClickListener { menuItem ->
                                                var type: String? = null
                                                type = menuItem.toString()
                                                layoutSend!!.visibility = View.VISIBLE


                                                if (type.equals("Black Student")) {
                                                    BlackStudent()
                                                    ChatListSender()
                                                } else {
                                                    txt_replayConstrine!!.visibility = View.VISIBLE
                                                    txt_onandoff!!.visibility = View.VISIBLE
                                                    txt_replay!!.setText(item.question)
                                                }
                                                true
                                            }
                                            popupMenu.show()
                                        }

                                    } else {

                                        if (item.changeanswer.equals("0")) {

                                            CommonUtil.changeanswer = item.changeanswer

                                            val popupMenu = PopupMenu(
                                                this@ChatCommunication,
                                                holder.img_dotthree
                                            )
                                            popupMenu.menuInflater.inflate(
                                                R.menu.menublackstudent,
                                                popupMenu.menu
                                            )
                                            popupMenu.setOnMenuItemClickListener { menuItem ->

                                                var type: String? = null
                                                type = menuItem.toString()
                                                layoutSend!!.visibility = View.VISIBLE

                                                if (type.equals("UnBlack Student")) {
                                                    UnBlackStudent()
                                                    ChatListSender()
                                                } else {
                                                    txt_replayConstrine!!.visibility = View.VISIBLE
                                                    txt_onandoff!!.visibility = View.VISIBLE
                                                    txt_replay!!.setText(item.question)
                                                }

                                                true
                                            }
                                            popupMenu.show()
                                        } else {

                                            CommonUtil.changeanswer = item.changeanswer
                                            val popupMenu =
                                                PopupMenu(
                                                    this@ChatCommunication,
                                                    holder.img_dotthree
                                                )
                                            popupMenu.menuInflater.inflate(
                                                R.menu.menublackstudent,
                                                popupMenu.menu
                                            )
                                            popupMenu.setOnMenuItemClickListener { menuItem ->

                                                var type: String? = null
                                                type = menuItem.toString()
                                                layoutSend!!.visibility = View.VISIBLE

                                                if (type.equals("UnBlack Student")) {
                                                    UnBlackStudent()
                                                    ChatListSender()
                                                } else {
                                                    txt_replayConstrine!!.visibility = View.VISIBLE
                                                    txt_onandoff!!.visibility = View.VISIBLE
                                                    txt_replay!!.setText(item.question)
                                                }

                                                true
                                            }
                                            popupMenu.show()

                                        }
                                    }
                                })
                            }
                        })

                    val mLayoutManager = LinearLayoutManager(this)
                    mLayoutManager.stackFromEnd = true
                    recyclerChat!!.layoutManager = mLayoutManager
                    recyclerChat!!.itemAnimator = DefaultItemAnimator()
                    recyclerChat!!.adapter = ChatSenderSide_Adapter
                    recyclerChat!!.recycledViewPool.setMaxRecycledViews(0, 80)
                    ChatSenderSide_Adapter!!.notifyDataSetChanged()
                } else {
                    CommonUtil.ApiAlert(this, "No Data Found")
                }
            } else {
                lblNoChats!!.visibility=View.VISIBLE

            }
        }


        appViewModel!!.BlackStudent!!.observe(this) { response ->
            if (response != null) {
                val status = response.Status
                val message = response.Message
                if (status == 1) {
                    CommonUtil.ApiAlert(this, message)
                    ChatListSender()
                } else {
                    CommonUtil.ApiAlert(this, "No Data Found")
                }
            } else {
                CommonUtil.ApiAlert(this, "Something went wrong")
            }
        }

        appViewModel!!.unblackStudent!!.observe(this) { response ->
            if (response != null) {
                val status = response.Status
                val message = response.Message
                if (status == 1) {
                    CommonUtil.ApiAlert(this, message)
                    ChatListSender()
                } else {
                    CommonUtil.ApiAlert(this, "No Data Found")
                }
            } else {
                CommonUtil.ApiAlert(this, "Something went wrong")
            }
        }

        if (CommonUtil.Priority.equals("p4") || CommonUtil.Priority.equals("p5")) {
            ChatListStudent()
        } else {
            ChatListSender()
        }
    }

    override val layoutResourceId: Int
        get() = R.layout.activity_chat_communication

    @OnClick(R.id.imgheaderBack)
    fun imgheaderBack() {
        onBackPressed()
    }

    override fun onBackPressed() {
        CommonUtil.OnBackSetBottomMenuClickTrue()
        super.onBackPressed()
    }

    private fun ChatListStudent() {

        val jsonObject = JsonObject()
        jsonObject.addProperty("offset", "0")
        jsonObject.addProperty("student_id", CommonUtil.MemberId)
        jsonObject.addProperty(ApiRequestNames.Req_staff_id, CommonUtil.staffid)
        jsonObject.addProperty(ApiRequestNames.Req_section_id, CommonUtil.SectionId)
        jsonObject.addProperty("subject_id", CommonUtil.subjectid)
        jsonObject.addProperty("is_classteacher", CommonUtil.isclassteacher)

        appViewModel!!.chatList(jsonObject, this)
        Log.d("ChatList_Student", jsonObject.toString())
    }

    private fun ChatListSender() {

        val jsonObject = JsonObject()
        jsonObject.addProperty("offset", "0")
        jsonObject.addProperty("staff_id", CommonUtil.MemberId)
        jsonObject.addProperty("limit", "10")
        jsonObject.addProperty(ApiRequestNames.Req_section_id, CommonUtil.SectionId)
        jsonObject.addProperty("subject_id", CommonUtil.subjectid)
        jsonObject.addProperty("is_classteacher", CommonUtil.isclassteacher)

        appViewModel!!.ChatSenderSide(jsonObject, this)
        Log.d("ChatSenderSide", jsonObject.toString())
    }

    private fun ChatStudent() {

        val jsonObject = JsonObject()
        jsonObject.addProperty("question", CommonUtil.Textedit)
        jsonObject.addProperty("student_id", CommonUtil.MemberId)
        jsonObject.addProperty(ApiRequestNames.Req_staff_id, CommonUtil.staffid)
        jsonObject.addProperty(ApiRequestNames.Req_section_id, CommonUtil.SectionId)
        jsonObject.addProperty("subject_id", CommonUtil.subjectid)
        jsonObject.addProperty("is_classteacher", CommonUtil.isclassteacher)
        jsonObject.addProperty("college_id", CommonUtil.CollegeId)

        appViewModel!!.ChatStudent(jsonObject, this)
        Log.d("ChatStudent", jsonObject.toString())
    }


    private fun ChatSender(replaytype: String) {

        val jsonObject = JsonObject()
        jsonObject.addProperty("answer", CommonUtil.Textedit)
        jsonObject.addProperty("staff_id", CommonUtil.MemberId)
        jsonObject.addProperty("question_id", CommonUtil.Questionid)
        jsonObject.addProperty("is_changeanswer", CommonUtil.changeanswer)
        jsonObject.addProperty("reply_type", replaytype)

        appViewModel!!.ChatStaff(jsonObject, this)
        Log.d("ChatStaff", jsonObject.toString())
    }

    private fun BlackStudent() {

        val jsonObject = JsonObject()
        jsonObject.addProperty("student_id", CommonUtil.studentid)
        jsonObject.addProperty("staff_id", CommonUtil.MemberId)
        jsonObject.addProperty("college_id", "1")

        appViewModel!!.StudentBlack(jsonObject, this)
        Log.d("StudentBlack", jsonObject.toString())
    }

    private fun UnBlackStudent() {

        val jsonObject = JsonObject()
        jsonObject.addProperty("student_id", CommonUtil.studentid)
        jsonObject.addProperty("staff_id", CommonUtil.MemberId)
        jsonObject.addProperty("college_id", "1")

        appViewModel!!.StudentUnBlack(jsonObject, this)
        Log.d("UnStudentBlack", jsonObject.toString())
    }
}