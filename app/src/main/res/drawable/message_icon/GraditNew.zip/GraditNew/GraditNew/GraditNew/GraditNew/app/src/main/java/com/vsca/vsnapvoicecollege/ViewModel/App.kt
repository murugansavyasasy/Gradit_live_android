package com.vsca.vsnapvoicecollege.ViewModel

import androidx.lifecycle.AndroidViewModel
import com.vsca.vsnapvoicecollege.Repository.AppServices
import androidx.lifecycle.LiveData
import com.google.gson.JsonObject
import android.app.Activity
import android.app.Application
import android.content.Context
import com.vsca.vsnapvoicecollege.Model.*
import com.vsca.vsnapvoicecollege.Model.StatusMessageResponse
import com.vsca.vsnapvoicecollege.SenderModel.GetCourseDepartmentResposne
import com.vsca.vsnapvoicecollege.SenderModel.GetDepartmentResponse
import com.vsca.vsnapvoicecollege.SenderModel.GetDivisionResponse
import com.vsca.vsnapvoicecollege.SenderModel.SenderStatusMessageData

class App(application: Application) : AndroidViewModel(application) {

    private var apiRepositories: AppServices? = null

    var courseDetailsResposneLiveData: LiveData<GetCourseDetailsResposne?>? = null
        private set
    private var ProfileDetailsResponseLiveData: LiveData<GetProfileResponse?>? = null
    var examApplicationResponseLiveData: LiveData<GetExamApplicationResponse?>? = null
        private set
    var noticeBoardResponseLiveData: LiveData<GetNoticeboardResposne?>? = null
        private set
    var circularResponseLiveData: LiveData<GetCircularListResponse?>? = null
        private set
    var assignmentListResponseLiveData: LiveData<GetAssignmentListResponse?>? = null
        private set
    var assignmentCountResponseLiveData: LiveData<GetAssignmentCountResponse?>? = null
        private set
    var assignmentViewContentResponseLiveData: LiveData<GetAssignmentViewContentResponse?>? = null
        private set

    var appreadstatusresponseLiveData: LiveData<StatusMessageResponse?>? = null
    var eventListbyTypeliveData: LiveData<GetEventListbyTypeResponse?>? = null
    var communicationLiveData: LiveData<GetCommunicationResponse?>? = null
    var OverAllMenuResponseLiveData: LiveData<GetOverAllCountResposne?>? = null
    var ExamListResponseLiveData: LiveData<GetExamListResponse?>? = null
    var ExamListResponseLiveDataReciver: LiveData<GetExamListResponse?>? = null

    var ExamMarkListLiveData: LiveData<ExamMarkListResponse?>? = null
    var VideoListLiveData: LiveData<GetVideoListResponse?>? = null
    var GetStaffDetailsLiveData: LiveData<GetStaffDetailsResponse?>? = null
    var GetStaffchat: LiveData<Chat_StaffList?>? = null

    var SemesterSectionLiveData: LiveData<SemesterAndSectionListResposne?>? = null
    var FacultyLiveData: LiveData<GetFacultyListResponse?>? = null
    var CategoryTypeLiveData: LiveData<GetCategoryTypesResponse?>? = null
    var CategoryWiseCreditLiveData: LiveData<GetCategoryWiseCreditResponse?>? = null
    var SemesterTypeLiveData: LiveData<GetSemesterWiseTypeResponse?>? = null
    var SemesterWiseCreditLiveData: LiveData<GetSemesterWiseCreditResponse?>? = null
    var SemesterWiseCreditAllLiveData: LiveData<GetSemesterWiseCreditALLResponse?>? = null
    var AttendanceDatesLiveData: LiveData<AttendanceResponse?>? = null
    var LeaveHistoryLiveData: LiveData<LeaveHistoryResponse?>? = null
    var LeaveTypeLiveData: LiveData<LeaveTypeResponse?>? = null
    var ChangePasswordLiveData: LiveData<StatusMessageResponse?>? = null
    var AdvertisementLiveData: LiveData<GetAdvertisementResponse?>? = null
    var UpdateDeviceTokenMutableLiveData: LiveData<StatusMessageResponse?>? = null
    var VideoRestrictContentMutableLiveData: LiveData<VideoRestrictionContentResponse?>? = null


    var GetDivisionMutableLiveData: LiveData<GetDivisionResponse?>? = null
    var GetDepartmentMutableLiveData: LiveData<GetDepartmentResponse?>? = null
    var GetCourseDepartmentMutableLiveData: LiveData<GetCourseDepartmentResposne?>? = null
    var SendSMSToEntireCollegeLiveData: LiveData<SenderStatusMessageData?>? = null
    var SendVoiceToEntireCollegeLiveData: LiveData<SenderStatusMessageData?>? = null

    var SendSMSToEntireCollegetutoeandsubjectLiveData: LiveData<SenderStatusMessageData?>? = null
    var SendSMStoParticularMutableData: LiveData<SenderStatusMessageData?>? = null
    var NoticeBoardSendSMStoParticularMutableData: LiveData<NoticeBoardSMSsend?>? = null
    var Eventsenddata: LiveData<Evendsenddata?>? = null
    var GetGrouplist: LiveData<GetGrouplist?>? = null
    var Getsubjectdata: LiveData<staffsubject_list?>? = null
    var Gettuter: LiveData<staffsubject_list?>? = null
    var Getspecificstudenttutot: LiveData<specificStudentdata?>? = null
    var Getspecificstudentsubject: LiveData<specificStudentdata?>? = null
    var GetCoursesByDepartmenthod: LiveData<department_course?>? = null
    var GetCoursesByDepartmenthodhod: LiveData<Yearandsection?>? = null
    var ImageorPdf: LiveData<ImageORpdfsend?>? = null
    var Imageorpdfparticuler: LiveData<ImageORpdfsend?>? = null
    var Assignment: LiveData<Assignmentsent?>? = null
    var Attendancetaking: LiveData<AttendancemardkingResponse?>? = null
    var Manageleave: LiveData<ManageLeave?>? = null
    var Leavehistory: LiveData<Leave_history?>? = null
    var LeaveRequest: LiveData<LeaveRequest?>? = null
    var Examsectionlist: LiveData<Section_and_Subject?>? = null
    var Examcreationdata: LiveData<ExamCreation_dataclass?>? = null
    var Examview: LiveData<Examlist_viewmodel?>? = null
    var Examdelete: LiveData<ExamDelete?>? = null
    var VideosendEntire: LiveData<VideoEntireSend?>? = null
    var VideoParticulerSend: LiveData<VideoParticulerSend?>? = null
    var DeleteNoticeboard: LiveData<Delete_noticeboard?>? = null
    var MarkAttendance: LiveData<AttendanceMark?>? = null
    var Eventpicupdate: LiveData<EventpicUpdate?>? = null
    var Assign_forward: LiveData<Assignment_Forward?>? = null
    var ChatList: LiveData<Chat_Text_model?>? = null
    var Chatstudentlist: LiveData<Chat_Student?>? = null
    var AssignmentSubmited: LiveData<Assignment_Submit?>? = null
    var Assignmentsubmittion: LiveData<Assignment_Submittion?>? = null
    var facultyListRecevier: LiveData<GetFacultyListResponse?>? = null
    var AttendanceEdit: LiveData<Attendance_Edit?>? = null
    var Assignmentview: LiveData<AssignmentContent_View?>? = null
    var ChatSenderside: LiveData<SenderSide_ChatModel?>? = null
    var ChatStaff: LiveData<SenderSide_ReplayChat?>? = null
    var BlackStudent: LiveData<BlackStudent?>? = null
    var unblackStudent: LiveData<Unblack_student?>? = null
    //var AttendanceEdit: LiveData<Attendance_EditX?>? = null

    fun init() {
        apiRepositories = AppServices()
        courseDetailsResposneLiveData = apiRepositories!!.courseDetailsResposneLiveData
        examApplicationResponseLiveData = apiRepositories!!.examApplicationResponseLiveData
        ProfileDetailsResponseLiveData = apiRepositories!!.profileResponseLiveData
        noticeBoardResponseLiveData = apiRepositories!!.noticeboardLiveData
        DeleteNoticeboard = apiRepositories!!.Noticeboarddelete
        circularResponseLiveData = apiRepositories!!.circularListResponseLiveData
        assignmentListResponseLiveData = apiRepositories!!.assignmentListResponseLiveData
        assignmentCountResponseLiveData = apiRepositories!!.assignmentCountResponseLiveData
        assignmentViewContentResponseLiveData =
            apiRepositories!!.assignmentViewContentResponseLiveData
        appreadstatusresponseLiveData = apiRepositories!!.appreadstatusLiveData
        OverAllMenuResponseLiveData = apiRepositories!!.OverAllCountMenuLiveData
        eventListbyTypeliveData = apiRepositories!!.getEventListLiveData
        communicationLiveData = apiRepositories!!.getCommunicationLiveData
        ExamListResponseLiveData = apiRepositories!!.getExamListLiveData
        ExamListResponseLiveDataReciver = apiRepositories!!.ExamlistReciver
        ExamMarkListLiveData = apiRepositories!!.getExamMarkListLiveData
        VideoListLiveData = apiRepositories!!.getVideoListMutableLiveData
        GetStaffDetailsLiveData = apiRepositories!!.getStaffListMutableLiveData

        GetStaffchat = apiRepositories!!.getStaffcatdata
        SemesterSectionLiveData = apiRepositories!!.getSemesterSectionListLiveData
        FacultyLiveData = apiRepositories!!.getFacultyReceiverLiveData
        CategoryTypeLiveData = apiRepositories!!.getCategoryTypeLiveData
        CategoryWiseCreditLiveData = apiRepositories!!.getCategoryWiseCreditLiveData
        SemesterTypeLiveData = apiRepositories!!.getSemesterTypeLiveData
        SemesterWiseCreditLiveData = apiRepositories!!.getSemesterwiseCreditsLiveData
        SemesterWiseCreditAllLiveData = apiRepositories!!.getSemesterwiseCreditsAllLiveData
        AttendanceDatesLiveData = apiRepositories!!.getAttendanceLiveData
        LeaveHistoryLiveData = apiRepositories!!.getLeaveHistoryLiveData
        LeaveTypeLiveData = apiRepositories!!.getLeaveTypeLiveData
        ChangePasswordLiveData = apiRepositories!!.getChangePawwordLiveData
        AdvertisementLiveData = apiRepositories!!.getAdvertisementMutableData
        UpdateDeviceTokenMutableLiveData = apiRepositories!!.UpdateDeviceTokenMutableLiveData
        VideoRestrictContentMutableLiveData = apiRepositories!!.VideoRestrictionMutableLiveData

        GetDivisionMutableLiveData = apiRepositories!!.GetDivisionMutableLiveData
        GetDepartmentMutableLiveData = apiRepositories!!.GetDepartmentMutableLiveData
        GetCourseDepartmentMutableLiveData = apiRepositories!!.GetCourseMutableLiveData
        SendSMSToEntireCollegeLiveData = apiRepositories!!.SendSMStoEntireCollegeMutableData
        SendSMSToEntireCollegetutoeandsubjectLiveData =
            apiRepositories!!.SendSMStoEntireCollegeMutableData
        SendVoiceToEntireCollegeLiveData = apiRepositories!!.SendVoiceEntire
        SendSMStoParticularMutableData = apiRepositories!!.SendSMStoParticularMutableData
        NoticeBoardSendSMStoParticularMutableData =
            apiRepositories!!.NoticeBoardSendSMStoParticularMutableData
        Eventsenddata = apiRepositories!!.Eventsenddatasend
        GetGrouplist = apiRepositories!!.getgroupdata
        Getsubjectdata = apiRepositories!!.getsubjectdata
        Gettuter = apiRepositories!!.gettuterdata
        Getspecificstudenttutot = apiRepositories!!.getSpecificstudenttutor
        Getspecificstudentsubject = apiRepositories!!.getSpecificstudentsubject
        GetCoursesByDepartmenthod = apiRepositories!!.getcoursedepartment
        GetCoursesByDepartmenthodhod = apiRepositories!!.getyearandsection
        ImageorPdf = apiRepositories!!.ImageOrPdfsend
        Imageorpdfparticuler = apiRepositories!!.ImageOrPdfsendparticuler
        Assignment = apiRepositories!!.Assignment
        Attendancetaking = apiRepositories!!.Attendancemarking
        Manageleave = apiRepositories!!.Manageleavesend
        Leavehistory = apiRepositories!!.leavehistory
        //   LeaveRequest=apiRepositories!!.Requestleave
        Examsectionlist = apiRepositories!!.ExamSectionandsubject
        Examcreationdata = apiRepositories!!.Examcreationdata
        Examview = apiRepositories!!.Examview
        Examdelete = apiRepositories!!.Examdelete
        VideosendEntire = apiRepositories!!.Videosendentire
        MarkAttendance = apiRepositories!!.TakeAttendance
        VideoParticulerSend = apiRepositories!!.Videosendparticuler
        Eventpicupdate = apiRepositories!!.Eventpictureupdate
        Assign_forward = apiRepositories!!.Assignmemntforward
        ChatList = apiRepositories!!.Chatlist
        Chatstudentlist = apiRepositories!!.chatstudentlist
        ChatSenderside = apiRepositories!!.sendersidechat
        AssignmentSubmited = apiRepositories!!.Assignment_submited
        Assignmentsubmittion = apiRepositories!!.AssignmentsubmittionSender
        facultyListRecevier = apiRepositories!!.FacultyRecevierList
        AttendanceEdit = apiRepositories!!.AttendanceEditList
        Assignmentview = apiRepositories!!.Assignmentcontentview
        ChatStaff = apiRepositories!!.SenderSideReplay
        BlackStudent = apiRepositories!!.BlackStudentparticuler
        unblackStudent = apiRepositories!!.unBlackStudent
    }

    fun getCourseDetails(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.GetCourseDetails(jsonObject, activity!!)
    }

    fun getExamApplication(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.GetExamApplicationDetails(jsonObject, activity!!)
    }

    fun getStudentProfile(memberid: Int, activity: Activity?) {
        apiRepositories!!.GetStudentProfile(memberid, activity!!)
    }

    fun getprofileResponseLiveData(): LiveData<GetProfileResponse?>? {
        return ProfileDetailsResponseLiveData
    }

    fun getNoticeboardList(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.GetNoticeboradList(jsonObject, activity!!)
    }

    fun getCircularList(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.GetCircularListbyType(jsonObject, activity!!)
    }

    fun getAssignmentListbyType(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.GetAssignmentListbyType(jsonObject, activity!!)
    }

    fun getAssignmentMemberCount(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.GetAssignmentmemberCount(jsonObject, activity!!)
    }

    fun getAssignmentViewContent(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.GetAssignmentViewContent(jsonObject, activity!!)
    }

    fun getAppreadStatus(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.GetAppreadStatus(jsonObject, activity!!)
    }

    fun getAppreadStatusContext(jsonObject: JsonObject?, activity: Context?) {
        apiRepositories!!.GetAppreadStatusContext(jsonObject, activity!!)
    }

    fun getOverAllMenuCount(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.GetOVerAllCount(jsonObject, activity!!)
    }

    fun getEventListbyType(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.GetEventListBytType(jsonObject, activity!!)
    }

    fun getCommunicationListbyType(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.GetCommunicationList(jsonObject, activity!!)
    }

    fun getExamListbyType(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.GetExamListReceiver(jsonObject, activity!!)
    }

    fun getExamListbyTypeReciver(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.GetExamListReceiverside(jsonObject, activity!!)
    }

    fun DeleteNoticeBoard(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.DeleteNoticeBoard(jsonObject, activity!!)
    }


    fun getStudentExamMarklist(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.ExamMarkList(jsonObject, activity!!)
    }

    fun getVideoList(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.GetVideoList(jsonObject, activity!!)
    }

    fun getSemesterAndSection(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.SemesterSectionListForApp(jsonObject, activity!!)
    }

    fun getFaculty(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.GetFacultyList(jsonObject, activity!!)
    }

    fun getCategoryType(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.GetCategoryType(jsonObject, activity!!)
    }

    fun getCategoryWiseCredit(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.GetCategoryCreditwise(jsonObject, activity!!)
    }

    fun getSmesterType(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.GetSemesterType(jsonObject, activity!!)
    }

    fun getSemesterWiseCredit(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.GetSemesterWiseCredits(jsonObject, activity!!)
    }

    fun getSemesterWiseCreditAll(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.GetSemesterWiseCreditsAll(jsonObject, activity!!)
    }

    fun getAttendanceReceiver(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.GetAttendanceForParent(jsonObject, activity!!)
    }

    fun getleaveHistory(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.GetLeaveHistoryParent(jsonObject, activity!!)
    }

    fun getLeaveType(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.GetLeaveType(jsonObject, activity!!)
    }

    fun getChangePassword(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.ChangePassword(jsonObject, activity!!)
    }

    fun getStaffDetailsForApp(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.GetStaffDetails(jsonObject, activity!!)
    }

    fun StaffClassesforChat(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.StaffClassesforChat(jsonObject, activity!!)
    }

    fun getAdforCollege(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.getAddFoCollege(jsonObject, activity!!)
    }

    fun UpdateDeviceToken(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.UpdateDeviceToken(jsonObject, activity!!)
    }

    fun VideoRestrictionContent(activity: Activity?) {
        apiRepositories!!.VideoRestriction(activity!!)
    }


    fun getDivision(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.GetDivisions(jsonObject, activity!!)
    }

    fun getDepartment(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.GetDepartmentData(jsonObject, activity!!)
    }


    fun getCourseDepartment(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.GetCoursesByDepartment(jsonObject, activity!!)
    }

    fun SendSmsToEntireCollege(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.SendSMSToEntireCollege(jsonObject, activity!!)
    }

    fun SendVoiceToEntireCollege(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.SendVoiceToEntireCollege(jsonObject, activity!!)
    }


    fun SendSmsToEntiretutorandsubjectCollege(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.SendSMSToEntiretotorandsubjectCollege(jsonObject, activity!!)
    }

    fun SendSmsToParticularType(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.SendSMStoParticularType(jsonObject, activity!!)
    }

    fun getGroup(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.GetGroup(jsonObject, activity!!)
    }

    fun getsubject(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.Getsubject(jsonObject, activity!!)
    }

    fun gettuter(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.Gettuter(jsonObject, activity!!)
    }

    fun getspecificstudentdata(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.Getspecificstudentdata(jsonObject, activity!!)
    }

    fun getspecificstudentdatasubject(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.Getspecificstudentdatasubject(jsonObject, activity!!)
    }

    fun getcoursedepartment(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.Getdepartmentcourse(jsonObject, activity!!)
    }

    fun getyearsndsection(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.Getyearandsection(jsonObject, activity!!)
    }

    fun NoticeBoardsmssending(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.NoticeBoardSendSMStoParticularType(jsonObject, activity!!)
    }

    fun ImageorPdf(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.ImageorPdfsend(jsonObject, activity!!)
    }

    fun ImageorPdfparticuler(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.ImageorPdfsendparticuler(jsonObject, activity!!)
    }

    fun Eventsend(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.EventsendData(jsonObject, activity!!)
    }

    fun Assignmentsend(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.Assignmentsenddata(jsonObject, activity!!)
    }

    fun AttendanceTakedata(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.AttendanceMarkingdata(jsonObject, activity!!)
    }

    fun Manageleave(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.ManageLeaveapplication(jsonObject, activity!!)
    }

    fun Leavehistortprinciple(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.Leavehistortprinciple(jsonObject, activity!!)
    }

    fun Examsectionandsubject(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.examsectionandsubject(jsonObject, activity!!)
    }

    fun Examcreation(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.Examcreation(jsonObject, activity!!)
    }

    fun Examview(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.Examview(jsonObject, activity!!)
    }

    fun VideoEntireSend(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.VideoEntireSend(jsonObject, activity!!)

    }

    fun VideoParticulerSend(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.VideoParticulerSend(jsonObject, activity!!)

    }

    fun MarkAttendance(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.TakeAttendance(jsonObject, activity!!)
    }


    fun ExamDelete(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.Examdeletedata(jsonObject, activity!!)

    }

//    fun LeaveRequest(jsonObject: JsonObject?, activity: Activity?) {
//        apiRepositories!!.LeaveRequest(jsonObject, activity!!)
//    }

    fun Eventimageupdate(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.EventpicUpdate(jsonObject, activity!!)

    }

    fun Assignmentfor(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.AssignmentForward(jsonObject, activity!!)
    }

    fun chatList(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.Chatlistdata(jsonObject, activity!!)
    }

    fun ChatStudent(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.ChatStudent(jsonObject, activity!!)
    }


    fun ChatStaff(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.ChatStaff(jsonObject, activity!!)
    }

    fun ChatSenderSide(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.SendersideChat(jsonObject, activity!!)
    }


    fun Assignmentsubmited(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.Assignmentsubmit(jsonObject, activity!!)
    }

    fun Assignmentsubmitedsender(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.AssignmentsubmitSender(jsonObject, activity!!)
    }

    fun GetFacultylistSenderside(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.GetFacultyListReceiver(jsonObject, activity!!)
    }

//    fun AttendanceCheck(jsonObject: JsonObject?, activity: Activity?) {
//        apiRepositories!!.AttendanceEdit(jsonObject, activity!!)
//    }

    fun Attendance_Edit(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.AttendanceEdit(jsonObject, activity!!)
    }

    fun AssignmentContent(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.AssignmentcontentView(jsonObject, activity!!)
    }

    fun StudentBlack(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.BlackStudent(jsonObject, activity!!)
    }

    fun StudentUnBlack(jsonObject: JsonObject?, activity: Activity?) {
        apiRepositories!!.UnBlackStudent(jsonObject, activity!!)
    }
}