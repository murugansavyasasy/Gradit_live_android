package com.vsca.vsnapvoicecollege.Model

data class Delete_noticeboard(
    val Message: String,
    val Status: Int
)