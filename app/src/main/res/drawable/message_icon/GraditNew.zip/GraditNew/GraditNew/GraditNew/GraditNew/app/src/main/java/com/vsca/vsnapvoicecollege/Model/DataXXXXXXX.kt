package com.vsca.vsnapvoicecollege.Model

data class DataXXXXXXX(
    val ivrheader: String
)