package com.vsca.vsnapvoicecollege.Model

data class SectiondetailX(
//    val Subjectdetails: List<SubjectdetailXX>,
    val clgdepartmentid: String,
    val clgsectionid: String,
    val subjectdetails: List<SubjectdetailXX>
)