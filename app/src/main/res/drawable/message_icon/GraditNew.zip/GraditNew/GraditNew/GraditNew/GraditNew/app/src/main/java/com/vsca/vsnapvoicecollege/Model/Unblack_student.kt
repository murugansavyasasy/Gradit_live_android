package com.vsca.vsnapvoicecollege.Model

data class Unblack_student(
    val Message: String,
    val Status: Int,
    val `data`: List<Unblackstudent>
)