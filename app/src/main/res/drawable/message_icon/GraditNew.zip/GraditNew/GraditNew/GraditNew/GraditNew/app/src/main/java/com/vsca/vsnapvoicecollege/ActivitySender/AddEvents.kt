package com.vsca.vsnapvoicecollege.ActivitySender

import android.app.TimePickerDialog
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import butterknife.BindView
import butterknife.ButterKnife
import butterknife.OnClick
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.google.gson.JsonObject
import com.vsca.vsnapvoicecollege.Activities.ActionBarActivity
import com.vsca.vsnapvoicecollege.Activities.BaseActivity
import com.vsca.vsnapvoicecollege.Model.GetAdvertiseData
import com.vsca.vsnapvoicecollege.Model.GetAdvertisementResponse
import com.vsca.vsnapvoicecollege.Model.GetEventDetailsData
import com.vsca.vsnapvoicecollege.R
import com.vsca.vsnapvoicecollege.Repository.ApiRequestNames
import com.vsca.vsnapvoicecollege.Utils.CommonUtil
import com.vsca.vsnapvoicecollege.Utils.SharedPreference
import com.vsca.vsnapvoicecollege.ViewModel.App
import java.util.*

class AddEvents : ActionBarActivity() {

    var appViewModel: App? = null
    var AdWebURl: String? = null
    var PreviousAddId: Int = 0
    var AdBackgroundImage: String? = null
    var AdSmallImage: String? = null
    var GetAdForCollegeData: List<GetAdvertiseData> = ArrayList()
    var MenuTitle: String? = null
    var MenuDescription: String? = null
    var Venue: String? = null
    var ScreenNameEvent: String? = null
    var Date: String? = null
    var Time: String? = null
    var eventsdata: GetEventDetailsData? = null
    var EventEdit: String? = null

    @JvmField
    @BindView(R.id.rytEventDate)
    var rytEventDate: RelativeLayout? = null

    @JvmField
    @BindView(R.id.rytEventTime)
    var rytEventTime: RelativeLayout? = null

    @JvmField
    @BindView(R.id.lblEventDate)
    var lblEventDate: TextView? = null

    @JvmField
    @BindView(R.id.lblEventTime)
    var lblEventTime: TextView? = null

    @JvmField
    @BindView(R.id.imgAdvertisement)
    var imgAdvertisement: ImageView? = null

    @JvmField
    @BindView(R.id.imgthumb)
    var imgthumb: ImageView? = null

    @JvmField
    @BindView(R.id.txtTitle)
    var txtTitle: EditText? = null

    @JvmField
    @BindView(R.id.edt_venue)
    var edt_venue: EditText? = null

    @JvmField
    @BindView(R.id.txtDescription)
    var txtDescription: EditText? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        CommonUtil.SetTheme(this)
        super.onCreate(savedInstanceState)
        appViewModel = ViewModelProvider(this).get(App::class.java)
        appViewModel!!.init()
        ButterKnife.bind(this)
        ActionbarWithoutBottom(this)


        eventsdata = intent.getSerializableExtra("EventsData") as? GetEventDetailsData
        EventEdit= intent.getSerializableExtra("EventEdit") as String?


        if (EventEdit.equals("EventEdit")){

            CommonUtil.EventsendType="Edit"
            lblEventDate!!.setText(eventsdata!!.event_date)
            lblEventTime!!.setText(eventsdata!!.event_time)
            txtTitle!!.setText(eventsdata!!.topic)
            txtDescription!!.setText(eventsdata!!.body)
            edt_venue!!.setText(eventsdata!!.venue)

        }

        appViewModel!!.AdvertisementLiveData?.observe(this,
            Observer<GetAdvertisementResponse?> { response ->
                if (response != null) {
                    val status = response.status
                    val message = response.message
                    if (status == 1) {
                        GetAdForCollegeData = response.data!!
                        for (j in GetAdForCollegeData.indices) {
                            AdSmallImage = GetAdForCollegeData[j].add_image
                            AdBackgroundImage = GetAdForCollegeData[0].background_image!!
                            AdWebURl = GetAdForCollegeData[0].add_url.toString()
                        }
                        Glide.with(this).load(AdBackgroundImage)
                            .diskCacheStrategy(DiskCacheStrategy.ALL).into(imgAdvertisement!!)
                        Log.d("AdBackgroundImage", AdBackgroundImage!!)

                        Glide.with(this).load(AdSmallImage).diskCacheStrategy(DiskCacheStrategy.ALL)
                            .into(imgthumb!!)
                    }
                }
            })


        rytEventTime!!.setOnClickListener {
            val mTimePicker: TimePickerDialog
            val mcurrentTime = Calendar.getInstance()
            val hour = mcurrentTime.get(Calendar.HOUR_OF_DAY)
            val minute = mcurrentTime.get(Calendar.MINUTE)

            mTimePicker = TimePickerDialog(this, object : TimePickerDialog.OnTimeSetListener {
                override fun onTimeSet(view: TimePicker?, hourOfDay: Int, minute: Int) {
                    lblEventTime!!.setText(String.format("%d:%d", hourOfDay, minute))
                }
            }, hour, minute, false)


            lblEventTime!!.setOnClickListener({ v ->
                mTimePicker.show()
            })
        }

    }

    private fun AdForCollegeApi() {

        var mobilenumber = SharedPreference.getSH_MobileNumber(this)
        var devicetoken = SharedPreference.getSH_DeviceToken(this)
        val jsonObject = JsonObject()
        jsonObject.addProperty(ApiRequestNames.Req_ad_device_token, devicetoken)
        jsonObject.addProperty(ApiRequestNames.Req_MemberID, CommonUtil.MemberId)
        jsonObject.addProperty(ApiRequestNames.Req_mobileno, mobilenumber)
        jsonObject.addProperty(ApiRequestNames.Req_college_id, CommonUtil.CollegeId)
        jsonObject.addProperty(ApiRequestNames.Req_priority, CommonUtil.Priority)
        jsonObject.addProperty(ApiRequestNames.Req_previous_add_id, PreviousAddId)
        ActionBarActivity.appviewModelbase!!.getAdforCollege(jsonObject, this)
        Log.d("AdForCollege:", jsonObject.toString())

        PreviousAddId = PreviousAddId + 1
        Log.d("PreviousAddId", PreviousAddId.toString())
    }

    override val layoutResourceId: Int
        get() = R.layout.activity_add_events

    @OnClick(R.id.btnConfirm)
    fun btnNextClick() {

        Date = lblEventDate!!.text.toString()
        Time = lblEventTime!!.text.toString()
        MenuTitle = txtTitle!!.text.toString()
        MenuDescription = txtDescription!!.text.toString()
        Venue = edt_venue!!.text.toString()

        CommonUtil.Time = Time.toString()
        CommonUtil.Date = Date.toString()
        CommonUtil.MenuTitle = MenuTitle.toString()
        CommonUtil.MenuDescription = MenuDescription.toString()
        CommonUtil.Venuetext = Venue.toString()

        ScreenNameEvent = "ScreenNameEvent"
        if (!MenuTitle.isNullOrEmpty() && !MenuDescription.isNullOrEmpty() && !Date.isNullOrEmpty() && !Time.isNullOrEmpty() && !Venue.isNullOrEmpty()) {
            val i: Intent = Intent(this, AddRecipients::class.java)
            i.putExtra("ScreenNameEvent", ScreenNameEvent)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(i)
        } else {
            CommonUtil.ApiAlert(this, "Kindly Enter Details")
        }
    }


    @OnClick(R.id.rytEventDate)
    fun eventdateClick() {
        CommonUtil.Datepicker(this, lblEventDate!!)
    }

    @OnClick(R.id.imgImagePdfback)
    fun imgImagePdfback() {
        onBackPressed()
    }

    @OnClick(R.id.btnCancel)
    fun btnCancelClick() {
        onBackPressed()
    }

    @OnClick(R.id.LayoutAdvertisement)
    fun adclick() {
        BaseActivity.LoadWebViewContext(this, AdWebURl)
    }

    override fun onResume() {
        var AddId: Int = 1
        PreviousAddId = PreviousAddId + 1
        AdForCollegeApi()
        super.onResume()
    }
}














