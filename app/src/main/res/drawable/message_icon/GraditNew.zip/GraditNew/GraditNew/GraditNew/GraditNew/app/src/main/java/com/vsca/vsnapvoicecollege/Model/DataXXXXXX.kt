package com.vsca.vsnapvoicecollege.Model

data class DataXXXXXX(
    val ivrheader: String
)