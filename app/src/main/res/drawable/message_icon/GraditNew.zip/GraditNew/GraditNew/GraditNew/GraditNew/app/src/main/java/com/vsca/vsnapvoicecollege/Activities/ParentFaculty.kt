package com.vsca.vsnapvoicecollege.Activities


import androidx.appcompat.app.AppCompatActivity
import com.vsca.vsnapvoicecollege.R
import android.os.Bundle

class ParentFaculty : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.faculty_list_design)
    }
}