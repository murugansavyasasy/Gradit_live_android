package com.vsca.vsnapvoicecollege.Model

data class EventpicUpdate(
    val Message: String,
    val Status: Int,
    val `data`: List<DataXXXXXXXX>
)