package com.vsca.vsnapvoicecollege.Model

data class Attendance_Checking(
    val Message: String,
    val Status: Int
)