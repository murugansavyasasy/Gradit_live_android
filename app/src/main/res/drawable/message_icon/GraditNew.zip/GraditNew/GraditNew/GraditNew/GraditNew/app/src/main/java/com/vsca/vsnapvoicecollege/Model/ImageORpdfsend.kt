package com.vsca.vsnapvoicecollege.Model

data class ImageORpdfsend(
    val Message: String,
    val Status: Int,
    val `data`: List<DataXX>
)