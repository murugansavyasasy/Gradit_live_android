package com.vsca.vsnapvoicecollege.Model

data class ManageLeave(
    val Message: String,
    val Status: Int
)