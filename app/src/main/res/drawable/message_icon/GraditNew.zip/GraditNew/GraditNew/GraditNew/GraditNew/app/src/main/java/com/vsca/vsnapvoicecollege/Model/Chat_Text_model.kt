package com.vsca.vsnapvoicecollege.Model

import java.util.ArrayList

data class Chat_Text_model(
    val Message: String,
    val Status: Int,
    val data: ArrayList<chat_offset_List>
)