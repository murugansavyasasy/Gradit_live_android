package com.vsca.vsnapvoicecollege.Model

data class DataXXXXXXXX(
    val ivrheader: String
)