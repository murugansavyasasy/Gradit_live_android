package com.vsca.vsnapvoicecollege.Adapters

import com.vsca.vsnapvoicecollege.Model.DashboardSubItems
import java.util.ArrayList

class ExaminationOverall(
    var menusubitemlist: ArrayList<Examinationdata>
)