package com.vsca.vsnapvoicecollege.Interfaces

import com.vsca.vsnapvoicecollege.Model.MenuDetailsResponse

interface MenuCountResponseCallback {
    fun menucountcallback(responseBody: MenuDetailsResponse)

}
