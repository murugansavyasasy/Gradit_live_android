package com.vsca.vsnapvoicecollege.Model

data class BlackStudent(
    val Message: String,
    val Status: Int,
    val `data`: List<Black_Student>
)