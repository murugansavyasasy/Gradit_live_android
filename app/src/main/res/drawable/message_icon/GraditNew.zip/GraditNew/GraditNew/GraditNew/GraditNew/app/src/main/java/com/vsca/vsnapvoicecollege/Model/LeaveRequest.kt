package com.vsca.vsnapvoicecollege.Model

data class LeaveRequest(
    val Message: String,
    val Status: Int
)