package com.vsca.vsnapvoicecollege.Model

data class AssignmentContent_ViewData(
    val content: String,
    val description: String,
    val file_name: String,
    val submittedtime: String
)