package com.vsca.vsnapvoicecollege.Model

data class Assignment_Submit(
    val Message: String,
    val Status: Int
)