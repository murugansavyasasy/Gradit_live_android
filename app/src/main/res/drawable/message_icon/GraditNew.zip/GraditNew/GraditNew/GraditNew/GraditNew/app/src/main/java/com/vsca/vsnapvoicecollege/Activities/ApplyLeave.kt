package com.vsca.vsnapvoicecollege.Activities

import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import butterknife.BindView
import butterknife.ButterKnife
import butterknife.OnClick
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.google.gson.JsonObject
import com.vsca.vsnapvoicecollege.Model.GetAdvertiseData
import com.vsca.vsnapvoicecollege.Model.GetAdvertisementResponse
import com.vsca.vsnapvoicecollege.Model.LeaveTypeData
import com.vsca.vsnapvoicecollege.R
import com.vsca.vsnapvoicecollege.Repository.ApiRequestNames
import com.vsca.vsnapvoicecollege.Utils.CommonUtil
import com.vsca.vsnapvoicecollege.Utils.CommonUtil.SetTheme
import com.vsca.vsnapvoicecollege.Utils.SharedPreference
import com.vsca.vsnapvoicecollege.ViewModel.App

class ApplyLeave : ActionBarActivity() {

    var appViewModel: App? = null
    var AdWebURl: String? = null
    var PreviousAddId: Int = 0
    var AdBackgroundImage: String? = null
    var AdSmallImage: String? = null
    var GetAdForCollegeData: List<GetAdvertiseData> = ArrayList()
    var StartDate: String? = null
    var EndDate: String? = null
    var Numberoddays: String? = null


    @JvmField
    @BindView(R.id.imgAdvertisement)
    var imgAdvertisement: ImageView? = null

    @JvmField
    @BindView(R.id.imgthumb)
    var imgthumb: ImageView? = null

    @JvmField
    @BindView(R.id.SpinnerLeaveType)
    var SpinnerLeaveType: Spinner? = null

    @JvmField
    @BindView(R.id.lblFromDate)
    var lblFromDate: TextView? = null

    @JvmField
    @BindView(R.id.lblToDate)
    var lblToDate: TextView? = null

    @JvmField
    @BindView(R.id.txtNoofDays)
    var txtNoofDays: EditText? = null

    @JvmField
    @BindView(R.id.txtLeaveReason)
    var txtLeaveReason: EditText? = null


    var GetLeaveTypeData: List<LeaveTypeData> = ArrayList()
    var bookArrayList = ArrayList<String>()
    var LeaveName: String? = null
    var LeaveType: String? = null
    var LeaveID = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        SetTheme(this)
        super.onCreate(savedInstanceState)
        appViewModel = ViewModelProvider(this).get(App::class.java)
        appViewModel!!.init()
        ButterKnife.bind(this)
        ActionbarWithoutBottom(this)

        appViewModel!!.AdvertisementLiveData?.observe(
            this,
            Observer<GetAdvertisementResponse?> { response ->
                if (response != null) {
                    val status = response.status
                    val message = response.message
                    if (status == 1) {
                        GetAdForCollegeData = response.data!!
                        for (j in GetAdForCollegeData.indices) {
                            AdSmallImage = GetAdForCollegeData[j].add_image
                            AdBackgroundImage = GetAdForCollegeData[0].background_image!!
                            AdWebURl = GetAdForCollegeData[0].add_url.toString()
                        }
                        Glide.with(this)
                            .load(AdBackgroundImage)
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .into(imgAdvertisement!!)
                        Log.d("AdBackgroundImage", AdBackgroundImage!!)

                        Glide.with(this)
                            .load(AdSmallImage)
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .into(imgthumb!!)
                    }
                }
            })

        try {

            appViewModel!!.LeaveTypeLiveData!!.observe(this) { response ->
                if (response != null) {
                    val status = response.status
                    val message = response.message
                    BaseActivity.UserMenuRequest(this)
                    bookArrayList.clear()
                    if (status == 1) {
                        GetLeaveTypeData = response.data!!
                        if (GetLeaveTypeData.size > 0) {
                            bookArrayList.add("Select Leave Type")
                            for (i in GetLeaveTypeData.indices) {
                                LeaveName = GetLeaveTypeData.get(i).leavetypename!!
                                bookArrayList.add(LeaveName!!)
                            }
                            val adapter: ArrayAdapter<String>
                            adapter = ArrayAdapter(
                                this,
                                android.R.layout.simple_spinner_item,
                                bookArrayList
                            )
                            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                            SpinnerLeaveType!!.setAdapter(adapter)
                            SpinnerLeaveType!!.setOnItemSelectedListener(object :
                                AdapterView.OnItemSelectedListener {
                                override fun onItemSelected(
                                    adapterView: AdapterView<*>?, view: View, i: Int, l: Long
                                ) {
                                    val index: Int = SpinnerLeaveType!!.getSelectedItemPosition()
                                    LeaveID = index
                                    LeaveType = SpinnerLeaveType!!.getSelectedItem().toString()
                                }

                                override fun onNothingSelected(adapterView: AdapterView<*>?) {}
                            })
                        } else {

                        }
                    } else {

                    }

                } else {

                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        appViewModel!!.Manageleave!!.observe(this) { response ->
            if (response != null) {
                val status = response.Status
                val message = response.Message
                if (status != null) {
                    if (status==1) {

                        val dlg = this.let { AlertDialog.Builder(it) }
                        dlg.setTitle("Info")
                        dlg.setMessage(message)
                        dlg.setPositiveButton("OK", DialogInterface.OnClickListener { dialog, which ->
                            val i: Intent =

                                Intent(this, Attendance::class.java)
                            i.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                            startActivity(i)
                        })

                        dlg.setCancelable(false)
                        dlg.create()
                        dlg.show()

                    } else {
                        CommonUtil.ApiAlert(this, message)
                    }
                }
            } else {
                CommonUtil.ApiAlert(this, "Something went wrong")
            }
        }
    }

    private fun AdForCollegeApi() {

        var mobilenumber = SharedPreference.getSH_MobileNumber(this)
        var devicetoken = SharedPreference.getSH_DeviceToken(this)
        val jsonObject = JsonObject()
        jsonObject.addProperty(ApiRequestNames.Req_ad_device_token, devicetoken)
        jsonObject.addProperty(ApiRequestNames.Req_MemberID, CommonUtil.MemberId)
        jsonObject.addProperty(ApiRequestNames.Req_mobileno, mobilenumber)
        jsonObject.addProperty(ApiRequestNames.Req_college_id, CommonUtil.CollegeId)
        jsonObject.addProperty(ApiRequestNames.Req_priority, CommonUtil.Priority)
        jsonObject.addProperty(ApiRequestNames.Req_previous_add_id, PreviousAddId)
        appviewModelbase!!.getAdforCollege(jsonObject, this)
        Log.d("AdForCollege:", jsonObject.toString())

        PreviousAddId = PreviousAddId + 1
        Log.d("PreviousAddId", PreviousAddId.toString())
    }

    private fun Manageleavesend() {
        val jsonObject = JsonObject()
        jsonObject.addProperty(ApiRequestNames.Req_colgid, CommonUtil.CollegeId)
        jsonObject.addProperty(ApiRequestNames.Req_memberid, CommonUtil.MemberId)
        jsonObject.addProperty(ApiRequestNames.Req_applicationid, "0")
        jsonObject.addProperty(ApiRequestNames.Req_leavetypeid, "1")
        jsonObject.addProperty(ApiRequestNames.Req_leavefromdate, CommonUtil.leavestartdate)
        jsonObject.addProperty(ApiRequestNames.Req_leavetodate, CommonUtil.leaveenddate)
        jsonObject.addProperty(ApiRequestNames.Req_numofdays, CommonUtil.numberofday)
        jsonObject.addProperty(ApiRequestNames.Req_processtype, "add")
        jsonObject.addProperty(ApiRequestNames.Req_clgsectionid, "20")
        jsonObject.addProperty(ApiRequestNames.Req_leavereason, "=======")

        appViewModel!!.Manageleave(jsonObject, this)
        Log.d("SMSJsonObject", jsonObject.toString())
    }

    override val layoutResourceId: Int
        protected get() = R.layout.activity_apply_leave

    @OnClick(R.id.imgLeaveback)
    fun LeaveApplyback() {
        onBackPressed()

    }

    @OnClick(R.id.btnConfirm)
    fun btnConform() {

        StartDate = lblFromDate!!.text.toString()
        EndDate = lblToDate!!.text.toString()
        Numberoddays = txtNoofDays!!.text.toString()

        CommonUtil.leavestartdate = StartDate.toString()
        CommonUtil.leaveenddate = EndDate.toString()
        CommonUtil.numberofday = Numberoddays.toString()


        val alertDialog: AlertDialog.Builder = AlertDialog.Builder(this@ApplyLeave)
        alertDialog.setTitle("info")
        alertDialog.setMessage("Are you want to Send?")
        alertDialog.setPositiveButton("yes") { _, _ ->

            Manageleavesend()

        }

        alertDialog.setNegativeButton("No") { _, _ ->


        }
        val alert: AlertDialog = alertDialog.create()
        alert.setCanceledOnTouchOutside(false)
        alert.show()

    }

    @OnClick(R.id.btnCancel)
    fun btnCancel() {
        onBackPressed()
    }


    @OnClick(R.id.lnrFromDate)
    fun startdata() {
        CommonUtil.Datepicker(this, lblFromDate!!)
    }

    @OnClick(R.id.lnrToDate)
    fun enddate() {
        CommonUtil.Datepicker(this, lblToDate!!)
    }

    override fun onBackPressed() {
        super.onBackPressed()
    }

    @OnClick(R.id.LayoutAdvertisement)
    fun adclick() {
        BaseActivity.LoadWebViewContext(this, AdWebURl)
    }

    fun Leavetype() {
        val jsonObject = JsonObject()

        jsonObject.addProperty(ApiRequestNames.Req_appid, CommonUtil.Appid)
        jsonObject.addProperty(ApiRequestNames.Req_userid, CommonUtil.MemberId)
        appViewModel!!.getLeaveType(jsonObject, this)
        Log.d("LeavetypeRequest:", jsonObject.toString())


    }

    override fun onResume() {
        var AddId: Int = 1
        PreviousAddId = PreviousAddId + 1
        AdForCollegeApi()
        Leavetype()
        super.onResume()
    }
}



