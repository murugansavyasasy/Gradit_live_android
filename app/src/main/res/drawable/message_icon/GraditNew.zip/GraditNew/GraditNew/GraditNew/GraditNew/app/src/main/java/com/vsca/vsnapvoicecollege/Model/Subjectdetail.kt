package com.vsca.vsnapvoicecollege.Model

data class Subjectdetail(
    val subjectid: String,
    val subjectname: String
)