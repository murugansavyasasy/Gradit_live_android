package com.vsca.vsnapvoicecollege.Adapters

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.CompoundButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import butterknife.BindView
import butterknife.ButterKnife
import com.vsca.vsnapvoicecollege.Model.Attendance_edit_List
import com.vsca.vsnapvoicecollege.Model.specificStudent_datalist
import com.vsca.vsnapvoicecollege.R
import com.vsca.vsnapvoicecollege.Utils.CommonUtil
import java.util.ArrayList

class Attendance_Edit_Adapter(data: List<Attendance_edit_List>, context: Context) :
    RecyclerView.Adapter<Attendance_Edit_Adapter.MyViewHolder>() {
    var AttendanceEdit: List<Attendance_edit_List> = ArrayList()
    var context: Context
    var seleteddataArray = ArrayList<String>()
    var seletedStringdata: String? = null


    inner class MyViewHolder constructor(itemView: View?) : RecyclerView.ViewHolder(
        (itemView)!!
    ) {
        @JvmField
        @BindView(R.id.lblEntiredepartment)
        var lblEntiredepartment: TextView? = null

        @JvmField
        @BindView(R.id.chboxEntiredepartment)
        var chboxEntiredepartment: CheckBox? = null

        init {
            ButterKnife.bind(this, (itemView)!!)
        }
    }

    init {
        AttendanceEdit = data
        this.context = context
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {

        val itemView: View = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.specific_student, parent, false)
        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val data: Attendance_edit_List = AttendanceEdit.get(position)
        holder.lblEntiredepartment!!.setText(data.membername)

        CommonUtil.AttendanceAbsendid.clear()

        if (data.attendancetype.equals("Present")) {
            holder.chboxEntiredepartment!!.isChecked=true
            CommonUtil.PresentlistStudent.add(data.memberid)
        }else{
            holder.chboxEntiredepartment!!.isChecked=false
            CommonUtil.AttendanceAbsendid.add(data.memberid)
        }

        holder.chboxEntiredepartment!!.setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener { buttonView, isChecked ->

            if (isChecked) {

                CommonUtil.AttendanceAbsendid.remove(data.memberid)

                CommonUtil.PresentlistStudent.add(data.memberid)
                Log.d("Attendance_P", CommonUtil.PresentlistStudent.toString())

            } else {

                CommonUtil.PresentlistStudent.remove(data.memberid)

                CommonUtil.AttendanceAbsendid.add(data.memberid)
                Log.d("Attendance_A", CommonUtil.AttendanceAbsendid.toString())
            }
        })
    }

    override fun getItemCount(): Int {
        return AttendanceEdit.size
    }
}