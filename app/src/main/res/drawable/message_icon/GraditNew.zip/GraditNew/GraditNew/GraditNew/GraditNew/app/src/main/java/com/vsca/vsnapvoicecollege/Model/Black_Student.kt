package com.vsca.vsnapvoicecollege.Model

data class Black_Student(
    val idstaff: String,
    val idstudent: String
)