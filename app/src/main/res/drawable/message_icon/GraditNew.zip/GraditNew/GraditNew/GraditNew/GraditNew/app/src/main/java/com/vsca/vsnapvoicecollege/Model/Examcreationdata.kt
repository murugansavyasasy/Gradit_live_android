package com.vsca.vsnapvoicecollege.Model

data class Examcreationdata(
    val ivrheader: String
)