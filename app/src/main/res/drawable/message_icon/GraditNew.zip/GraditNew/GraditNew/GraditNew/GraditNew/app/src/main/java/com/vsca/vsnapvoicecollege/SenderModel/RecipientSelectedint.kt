package com.vsca.vsnapvoicecollege.SenderModel

import java.io.Serializable

class RecipientSelectedint(val SelectedId: Int?, var SelectedName: String?) :
    Serializable {
}