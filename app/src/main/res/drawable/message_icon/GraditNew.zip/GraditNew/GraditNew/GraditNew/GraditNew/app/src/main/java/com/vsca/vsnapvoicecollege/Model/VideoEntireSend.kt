package com.vsca.vsnapvoicecollege.Model

data class VideoEntireSend(
    val Message: String,
    val Status: Int,
    val `data`: List<DataXXXXX>
)