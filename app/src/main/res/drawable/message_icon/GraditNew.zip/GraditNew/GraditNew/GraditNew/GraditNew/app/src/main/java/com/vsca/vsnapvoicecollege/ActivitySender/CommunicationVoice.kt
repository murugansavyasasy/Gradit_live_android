package com.vsca.vsnapvoicecollege.ActivitySender

import android.content.Intent
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import butterknife.BindView
import butterknife.ButterKnife
import butterknife.OnClick
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.vsca.vsnapvoicecollege.Activities.ActionBarActivity
import com.vsca.vsnapvoicecollege.Activities.BaseActivity
import com.vsca.vsnapvoicecollege.Model.GetAdvertiseData
import com.vsca.vsnapvoicecollege.Model.GetAdvertisementResponse
import com.vsca.vsnapvoicecollege.R
import com.vsca.vsnapvoicecollege.Repository.ApiRequestNames
import com.vsca.vsnapvoicecollege.Utils.CommonUtil
import com.vsca.vsnapvoicecollege.Utils.SharedPreference
import com.vsca.vsnapvoicecollege.ViewModel.App
import okhttp3.MultipartBody
import okhttp3.RequestBody
import org.json.JSONArray
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File
import java.io.IOException

class CommunicationVoice : ActionBarActivity() {
    var mediaPlayer: MediaPlayer? = null
    var bIsRecording = false
    private val iRequestCode = 0
    var mediaFileLengthInMilliseconds = 0
    var handler = Handler()
    var recTime = 0
    var recorder: MediaRecorder? = null
    var recTimerHandler = Handler()
    var iMediaDuration = 0

    //    var futureStudioIconFile: File? = null
    var iMaxRecDur = 0
    val VOICE_FOLDER_NAME = "Gradit"
    val VOICE_FILE_NAME = ".mp3"
    var VoiceFilePath: String? = null

    //  var VoiceDuration: String? = null
    var appViewModel: App? = null
    var AdWebURl: String? = null
    var PreviousAddId: Int = 0
    var AdBackgroundImage: String? = null
    var AdSmallImage: String? = null
    var GetAdForCollegeData: List<GetAdvertiseData> = ArrayList()

    //  var voicetitle: String? = null
    var ScreenType: Boolean? = null
    var ScreenName: String? = null

    @JvmField
    @BindView(R.id.imgAdvertisement)
    var imgAdvertisement: ImageView? = null

    @JvmField
    @BindView(R.id.imgthumb)
    var imgthumb: ImageView? = null

    @JvmField
    @BindView(R.id.imgrecord)
    var imgrecord: ImageView? = null

    @JvmField
    @BindView(R.id.switchonAndoff)
    var switchonAndoff: Switch? = null

    @JvmField
    @BindView(R.id.lbl_switchLable)
    var lbl_switchLable: TextView? = null

    @JvmField
    @BindView(R.id.imgPlayPasue)
    var imgPlayPasue: ImageView? = null

    @JvmField
    @BindView(R.id.lblRecordTime)
    var lblRecordTime: TextView? = null

    @JvmField
    @BindView(R.id.seekbarplayvoice)
    var seekbarplayvoice: SeekBar? = null

    @JvmField
    @BindView(R.id.lbltotalduration)
    var lbltotalduration: TextView? = null

    @JvmField
    @BindView(R.id.rytLayoutSeekPlay)
    var rytLayoutSeekPlay: RelativeLayout? = null

    @JvmField
    @BindView(R.id.btnConfirm)
    var btnConfirm: Button? = null

    @JvmField
    @BindView(R.id.edt_voicename)
    var edt_voicename: EditText? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CommonUtil.SetTheme(this)

        setContentView(R.layout.activity_communication_voice)
        appViewModel = ViewModelProvider(this).get(App::class.java)
        appViewModel!!.init()
        ButterKnife.bind(this)
        setupAudioPlayer()
        ActionbarWithoutBottom(this)
        CommonUtil.VoiceType = "0"

        appViewModel!!.AdvertisementLiveData?.observe(
            this,
            Observer<GetAdvertisementResponse?> { response ->
                if (response != null) {
                    val status = response.status
                    val message = response.message
                    if (status == 1) {
                        GetAdForCollegeData = response.data!!
                        for (j in GetAdForCollegeData.indices) {
                            AdSmallImage = GetAdForCollegeData[j].add_image
                            AdBackgroundImage = GetAdForCollegeData[0].background_image!!
                            AdWebURl = GetAdForCollegeData[0].add_url.toString()
                        }
                        Glide.with(this)
                            .load(AdBackgroundImage)
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .into(imgAdvertisement!!)
                        Log.d("AdBackgroundImage", AdBackgroundImage!!)

                        Glide.with(this)
                            .load(AdSmallImage)
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .into(imgthumb!!)
                    }
                }
            })

        ScreenType = intent.getBooleanExtra("screentype", true)
        if (ScreenType!!) {
            ScreenName = "Noticeboard"
        } else {
            ScreenName = "Communication"
        }
        Log.d("screentype", ScreenType.toString())


        switchonAndoff!!.setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                CommonUtil.VoiceType = "1"
            } else {
                CommonUtil.VoiceType = "0"
            }
        })
    }

    override val layoutResourceId: Int
        get() = R.layout.activity_communication_voice

    @OnClick(R.id.btnConfirm)
    fun addreception() {
        CommonUtil.voicetitle = edt_voicename!!.text.toString()
        if (!CommonUtil.voicetitle!!.isEmpty() && lblRecordTime!!.getText().toString() != "00:00") {
            val i: Intent = Intent(this, AddRecipients::class.java)
            i.putExtra("ScreenName", ScreenName)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(i)
        } else {
            CommonUtil.ApiAlert(this, "some data is not filled")
        }
    }

    private fun AdForCollegeApi() {

        var mobilenumber = SharedPreference.getSH_MobileNumber(this)
        var devicetoken = SharedPreference.getSH_DeviceToken(this)
        val jsonObject = JsonObject()
        jsonObject.addProperty(ApiRequestNames.Req_ad_device_token, devicetoken)
        jsonObject.addProperty(ApiRequestNames.Req_MemberID, CommonUtil.MemberId)
        jsonObject.addProperty(ApiRequestNames.Req_mobileno, mobilenumber)
        jsonObject.addProperty(ApiRequestNames.Req_college_id, CommonUtil.CollegeId)
        jsonObject.addProperty(ApiRequestNames.Req_priority, CommonUtil.Priority)
        jsonObject.addProperty(ApiRequestNames.Req_previous_add_id, PreviousAddId)
        appviewModelbase!!.getAdforCollege(jsonObject, this)
        Log.d("AdForCollege:", jsonObject.toString())

        PreviousAddId = PreviousAddId + 1
        Log.d("PreviousAddId", PreviousAddId.toString())
    }

    @OnClick(R.id.imgrecord)
    fun imgvoicerecordClick() {
        if (bIsRecording) {
            if (lblRecordTime!!.getText().toString() == "00:00") {
                imgrecord!!.setClickable(false)
                imgrecord!!.setEnabled(false)
            } else {
                stop_RECORD()
            }
        } else {
            start_RECORD()
        }
    }

    @OnClick(R.id.imgEventback)
    fun imgEventback() {
        onBackPressed()
    }

    @OnClick(R.id.btnCancel)
    fun btncancleclick() {
        onBackPressed()
    }

    @OnClick(R.id.imgPlayPasue)
    fun playvoiceatseekbar() {
        recplaypause()
    }

    @OnClick(R.id.LayoutAdvertisement)
    fun adclick() {
        BaseActivity.LoadWebViewContext(this, AdWebURl)
    }

    fun start_RECORD() {
        if (mediaPlayer!!.isPlaying) {
            mediaPlayer!!.stop()
        }
        imgrecord!!.setImageResource(R.drawable.voice_stop)
        imgrecord!!.setClickable(true)
        rytLayoutSeekPlay!!.setVisibility(View.GONE)

        try {
            recorder = MediaRecorder()
            recorder!!.setAudioSource(MediaRecorder.AudioSource.MIC)
            recorder!!.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            recorder!!.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB)
            recorder!!.setAudioEncodingBitRate(16)
            recorder!!.setAudioSamplingRate(44100)
            recorder!!.setOutputFile(getRecFilename())
            Log.d("Record",recorder.toString())
            recorder!!.prepare()
            recorder!!.start()
            recTimeUpdation()
            bIsRecording = true
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    fun stop_RECORD() {
        recorder!!.stop()
        recTimerHandler.removeCallbacks(runson)
        bIsRecording = false
        imgrecord!!.setImageResource(R.drawable.voice_record)
        rytLayoutSeekPlay!!.setVisibility(View.VISIBLE)
        fetchSong()

    }

    fun setupAudioPlayer() {
        mediaPlayer = MediaPlayer()
        mediaPlayer!!.setOnCompletionListener {
            imgPlayPasue!!.setImageResource(R.drawable.ic_play)
            mediaPlayer!!.seekTo(0)
        }
    }

    fun recplaypause() {
        mediaFileLengthInMilliseconds = mediaPlayer!!.duration

        if (!mediaPlayer!!.isPlaying) {
            mediaPlayer!!.start()
            imgPlayPasue!!.setImageResource(R.drawable.ic_pause)

        } else {
            mediaPlayer!!.pause()
            imgPlayPasue!!.setClickable(true)
            imgPlayPasue!!.setImageResource(R.drawable.ic_play)
        }
        primarySeekBarProgressUpdater(mediaFileLengthInMilliseconds)
    }

    private fun primarySeekBarProgressUpdater(fileLength: Int) {
        val iProgress =
            ((mediaPlayer!!.currentPosition.toFloat() / fileLength) * 100).toInt()
        seekbarplayvoice!!.progress = iProgress
        if (mediaPlayer!!.isPlaying) {
            val notification: Runnable = object : Runnable {
                override fun run() {
                    lbltotalduration!!.text = milliSecondsToTimer(
                        mediaPlayer!!.currentPosition.toLong()
                    )
                    primarySeekBarProgressUpdater(fileLength)
                }
            }
            handler.postDelayed(notification, 1000)
        }
    }

    fun getRecFilename(): String? {
        val filepath: String
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {

            filepath = this.getApplicationContext()
                .getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)!!.path


        } else {

            filepath = Environment.getExternalStorageDirectory().path

        }

        val fileDir = File(filepath, VOICE_FOLDER_NAME)
        if (!fileDir.exists()) {
            fileDir.mkdirs()

        }
        val fileNamePath = File(fileDir, VOICE_FILE_NAME)
        return fileNamePath.path



    }

    fun recTimeUpdation() {
        recTime = 1
        recTimerHandler.postDelayed(runson, 1000)
    }

    val runson: Runnable = object : Runnable {
        override fun run() {
            lblRecordTime!!.setText(milliSecondsToTimer(recTime * 1000.toLong()))
            val timing: String = lblRecordTime!!.getText().toString()
            if (lblRecordTime!!.getText().toString() != "00:00") {
                imgrecord!!.setEnabled(true)
            }
            recTime = recTime + 1
            if (recTime != iMaxRecDur) {
                recTimerHandler.postDelayed(this, 1000)
            } else {
                stop_RECORD()
            }
        }
    }

    fun milliSecondsToTimer(milliseconds: Long): String? {
        var finalTimerString = ""
        var secondsString = ""
        var minutesString = ""

        val hours = (milliseconds / (1000 * 60 * 60)).toInt()
        val minutes = (milliseconds % (1000 * 60 * 60)).toInt() / (1000 * 60)
        val seconds = (milliseconds % (1000 * 60 * 60) % (1000 * 60) / 1000).toInt()
        if (hours > 0) {
            finalTimerString = "$hours:"
        }

        minutesString = if (minutes < 10) {
            "0$minutes"
        } else {
            "" + minutes
        }
        secondsString = if (seconds < 10) {
            "0$seconds"
        } else {
            "" + seconds
        }
        finalTimerString = "$finalTimerString$minutesString:$secondsString"
        return finalTimerString
    }

    fun fetchSong() {
        Log.d("FetchSong", "Start***************************************")
        try {
            val filepath: String
            if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {

                filepath = this.getApplicationContext()
                    .getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)!!.getPath()
                Log.d("File 11", filepath!!)

            } else {

                filepath = Environment.getExternalStorageDirectory().getPath()
                Log.d("File 10", filepath!!)

            }

            val fileDir = File(filepath, VOICE_FOLDER_NAME)

            if (!fileDir.exists()) {
                fileDir.mkdirs()
            }

            CommonUtil.futureStudioIconFile = File(fileDir, VOICE_FILE_NAME)
            VoiceFilePath = CommonUtil.futureStudioIconFile?.path
            println("FILE_PATH:" + CommonUtil.futureStudioIconFile!!.path)
            mediaPlayer!!.reset()
            mediaPlayer!!.setDataSource(CommonUtil.futureStudioIconFile!!.path)
            mediaPlayer!!.prepare()
            iMediaDuration = (mediaPlayer!!.duration / 1000.0).toInt()
            CommonUtil.VoiceDuration = iMediaDuration.toString()

        } catch (e: Exception) {
            Log.d("in Fetch Song", e.toString())
        }
        Log.d("FetchSong", "END***************************************")
    }

    override fun onResume() {
        var AddId: Int = 1
        PreviousAddId = PreviousAddId + 1
        AdForCollegeApi()
        super.onResume()
        super.onResume()
        this!!.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    override fun onPause() {
        super.onPause()
        if (mediaPlayer!!.isPlaying) {
            imgrecord!!.setClickable(false)
            mediaPlayer!!.pause()
            imgPlayPasue!!.setImageResource(R.drawable.ic_play)
        }
        if (bIsRecording) imgrecord!!.setClickable(true)
        this!!.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }
}