package com.vsca.vsnapvoicecollege.ActivitySender


import android.app.Activity
import android.app.ProgressDialog
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.widget.NestedScrollView
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import butterknife.BindView
import butterknife.ButterKnife
import butterknife.OnClick
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.vsca.vsnapvoicecollege.AWS.S3Uploader
import com.vsca.vsnapvoicecollege.AWS.S3Utils
import com.vsca.vsnapvoicecollege.Activities.*
import com.vsca.vsnapvoicecollege.Adapters.*
import com.vsca.vsnapvoicecollege.Interfaces.RecipientCheckListener
import com.vsca.vsnapvoicecollege.Model.*
import com.vsca.vsnapvoicecollege.R
import com.vsca.vsnapvoicecollege.Repository.ApiRequestNames
import com.vsca.vsnapvoicecollege.Repository.RestClient
import com.vsca.vsnapvoicecollege.SenderModel.*
import com.vsca.vsnapvoicecollege.Utils.CommonUtil
import com.vsca.vsnapvoicecollege.Utils.CustomLoading
import com.vsca.vsnapvoicecollege.ViewModel.App
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.MultipartBody.Part.Companion.createFormData
import okhttp3.RequestBody
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File
import java.text.SimpleDateFormat
import java.util.*


class AddRecipients : ActionBarActivity() {


    @JvmField
    @BindView(R.id.chboxEntire)
    var chboxEntire: CheckBox? = null

    @JvmField
    @BindView(R.id.lblDivision)
    var lblDivision: TextView? = null

    @JvmField
    @BindView(R.id.edt_selectiontuterorsubject)
    var edt_selectiontuterorsubject: TextView? = null

    @JvmField
    @BindView(R.id.NestedScrollView)
    var NestedScrollView: NestedScrollView? = null

    @JvmField
    @BindView(R.id.layoutEntireCollege)
    var layoutEntireCollege: ConstraintLayout? = null


    @JvmField
    @BindView(R.id.LayoutRecipient)
    var LayoutRecipient: ConstraintLayout? = null

    @JvmField
    @BindView(R.id.lblDepartment)
    var lblDepartment: TextView? = null

    @JvmField
    @BindView(R.id.lblEntire)
    var lblEntire: TextView? = null

    @JvmField
    @BindView(R.id.txt_selectsubortutor)
    var txt_selectsubortutor: TextView? = null

    @JvmField
    @BindView(R.id.lblCourse)
    var lblCourse: TextView? = null

    @JvmField
    @BindView(R.id.lblYourClasses)
    var lblYourClasses: TextView? = null

    @JvmField
    @BindView(R.id.lblGroups)
    var lblGroups: TextView? = null

    @JvmField
    @BindView(R.id.txt_division)
    var txt_division: TextView? = null

    @JvmField
    @BindView(R.id.recycleRecipients)
    var recycleRecipients: RecyclerView? = null

    @JvmField
    @BindView(R.id.lblSelectedRecipient)
    var lblSelectedRecipient: TextView? = null


    @JvmField
    @BindView(R.id.spinnerDropdown)
    var spinnerDropdown: Spinner? = null

    @JvmField
    @BindView(R.id.spinnerDropdowncourse)
    var spinnerDropdowncourse: Spinner? = null

    @JvmField
    @BindView(R.id.chboxParents)
    var chboxParents: CheckBox? = null

    @JvmField
    @BindView(R.id.Viewlineone)
    var Viewlineone: View? = null

    @JvmField
    @BindView(R.id.chboxStaff)
    var chboxStaff: CheckBox? = null


    @JvmField
    @BindView(R.id.recycleRecipientscourse)
    var recycleRecipientscourse: RecyclerView? = null

    @JvmField
    @BindView(R.id.recycleyearandsection)
    var recycleyearandsection: RecyclerView? = null

    @JvmField
    @BindView(R.id.chboxStudent)
    var chboxStudent: CheckBox? = null

    @JvmField
    @BindView(R.id.Viewlinetwo)
    var Viewlinetwo: View? = null


    @JvmField
    @BindView(R.id.recycle_Staffrecipients)
    var recycle_Staffrecipients: RecyclerView? = null

    @JvmField
    @BindView(R.id.txt_selectspecfic)
    var txt_selectspecfic: TextView? = null


    @JvmField
    @BindView(R.id.layoutstudentlist)
    var layoutstudentlist: ConstraintLayout? = null

    @JvmField
    @BindView(R.id.txt_department)
    var txt_department: TextView? = null

    @JvmField
    @BindView(R.id.Viewlinethree)
    var Viewlinethree: View? = null

    @JvmField
    @BindView(R.id.txt_mydepartment)
    var txt_mydepartment: TextView? = null

    @JvmField
    @BindView(R.id.txt_myclass)
    var txt_myclass: TextView? = null

    @JvmField
    @BindView(R.id.lbl_select_student)
    var lbl_select_student: TextView? = null

    @JvmField
    @BindView(R.id.recycle_specificstudent)
    var recycle_specificstudent: RecyclerView? = null

    @JvmField
    @BindView(R.id.Viewlinefour)
    var Viewlinefour: View? = null

    @JvmField
    @BindView(R.id.lnrStaff)
    var lnrStaff: LinearLayout? = null


    //AWS
    var Awsuploadedfile = java.util.ArrayList<String>()

    var Awsimagefile = java.util.ArrayList<String>()

    var pathIndex = 0
    var uploadFilePath: String? = null
    var contentType: String? = null
    var AWSUploadedFilesList = java.util.ArrayList<AWSUploadedFiles>()
    var progressDialog: ProgressDialog? = null
    var fileNameDateTime: String? = null

    //  var urlFromS3: String? = null
    var fileName: File? = null
    var filename: String? = null
    var Awsaupladedfilepath: String? = null
    var separator = ","


    var specificStudent_adapter: specificStudent_adapter? = null
    var sublectadapter: Subject_Adapter? = null
    var getsubjectlist: List<Get_staff_yourclass> = ArrayList()
    var getspecifictuterstudent: List<specificStudent_datalist> = ArrayList()
    var sectionandyear_Adapter: sectionandyear_Adapter? = null
    var appViewModel: App? = null
    var SelecteRecipientType: String? = null
    var GetDivisionData: ArrayList<GetDivisionData>? = null
    var GetGroupdata: ArrayList<GetGroupData>? = null
    var GetDepartmentData: ArrayList<GetDepartmentData>? = null
    var Getyouurclassdata: ArrayList<Data>? = null
    var GetCourseData: ArrayList<GetCourseData>? = null
    var Getcoursedepartment: ArrayList<department_coursedata>? = null
    var divisionadapter: SelectedRecipientAdapter? = null
    var SelectedcourseAdapter: SelectedRecipientAdapter? = null
    var departmentAdapter: SelectedRecipientAdapter? = null
    var groupAdapter: SelectedRecipientAdapter? = null
    var SpinnerData = ArrayList<String>()
    var SpinningCoursedata = ArrayList<String>()
    var SpinningCoursedatahod = ArrayList<String>()
    var SelectedSpinnerID: String? = null
    var SelectedSpinnerIDhod: String? = null
    var ScreenName: String? = null
    var FileType: String? = null

    var ScreenNameEvent: String? = null
    var isStaff: Boolean? = null
    var isStudent: Boolean? = null
    var isParent: Boolean? = null
    var recivertype: String? = null


    override fun onCreate(savedInstanceState: Bundle?) {

        CommonUtil.SetTheme(this)
        super.onCreate(savedInstanceState)
        ButterKnife.bind(this)
        ActionbarWithoutBottom(this)

        ScreenName = intent.getStringExtra("ScreenName")
        Log.d("ScreenName", ScreenName.toString())
        ScreenNameEvent = intent.getStringExtra("ScreenNameEvent")
        Log.d("ScreenNameEvent", ScreenNameEvent.toString())
        FileType = intent.getStringExtra("FileType")

        if (ScreenName.equals("New Assignment") || ScreenName.equals("Forward Assignment")) {

            txt_selectsubortutor!!.visibility = View.VISIBLE
            Viewlinetwo!!.visibility = View.VISIBLE
            edt_selectiontuterorsubject!!.visibility = View.VISIBLE
            recycle_Staffrecipients!!.visibility = View.VISIBLE
            txt_selectspecfic!!.visibility = View.VISIBLE

//            recycle_Staffrecipients!!.visibility = View.VISIBLE
//            CommonUtil.receivertype = "5"
//            GetSubjectprinciple()

            lblDivision!!.visibility = View.GONE
            lblCourse!!.visibility = View.GONE
            lblDepartment!!.visibility = View.GONE
            lblGroups!!.visibility = View.GONE
            lblYourClasses!!.visibility = View.GONE
            chboxEntire!!.visibility = View.GONE
            lblEntire!!.visibility = View.GONE

//            CommonUtil.receivertype = "5"
//            lnrStaff!!.visibility = View.GONE
//
//            recycleRecipients!!.visibility = View.GONE
//            spinnerDropdown!!.visibility = View.GONE
//            spinnerDropdowncourse!!.visibility = View.GONE
//            recycleRecipientscourse!!.visibility = View.GONE
//            txt_division!!.visibility = View.GONE
//
//            chboxEntire!!.isChecked = false
//
//
//            layoutEntireCollege!!.visibility = View.GONE
//            LayoutRecipient!!.visibility = View.GONE
//            Viewlineone!!.visibility = View.GONE
//            NestedScrollView!!.visibility = View.GONE
//
//            txt_department!!.visibility = View.GONE
//            Viewlinethree!!.visibility = View.GONE
//            txt_mydepartment!!.visibility = View.GONE
//            txt_myclass!!.visibility = View.GONE


        }

        if (chboxEntire!!.isChecked == true) {
            lnrStaff!!.visibility = View.VISIBLE
        }

        isParent = false
        isStudent = false
        isStaff = false

        chboxParents!!.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                isParent = true

            } else {
                isParent = false
            }
        }

        chboxStudent?.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                isStudent = true

            } else {
                isStudent = false

            }
        }

        chboxStaff?.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                isStaff = true

            } else {
                isStaff = false

            }
        }
        if (CommonUtil.Priority.equals("p1")) {
            lnrStaff!!.visibility = View.VISIBLE
        } else if (lblEntire!!.text.equals("Entire Department")) {
            lnrStaff!!.visibility = View.VISIBLE
        }


        if (CommonUtil.Priority.equals("p1")) {

            layoutEntireCollege!!.visibility = View.VISIBLE
            LayoutRecipient!!.visibility = View.VISIBLE
            // Viewlineone!!.visibility = View.VISIBLE
            NestedScrollView!!.visibility = View.VISIBLE

            //    txt_selectsubortutor!!.visibility = View.GONE
//            Viewlinetwo!!.visibility = View.GONE
//            edt_selectiontuterorsubject!!.visibility = View.GONE
//            recycle_Staffrecipients!!.visibility = View.GONE
//            txt_selectspecfic!!.visibility = View.GONE


            txt_department!!.visibility = View.GONE
            Viewlinethree!!.visibility = View.GONE
            txt_mydepartment!!.visibility = View.GONE
            txt_myclass!!.visibility = View.GONE

            lbl_select_student!!.visibility = View.GONE
            Viewlinefour!!.visibility = View.GONE
            recycle_specificstudent!!.visibility = View.GONE


        } else if (CommonUtil.Priority.equals("p3")) {

            layoutEntireCollege!!.visibility = View.GONE
            LayoutRecipient!!.visibility = View.GONE
            Viewlineone!!.visibility = View.GONE
            NestedScrollView!!.visibility = View.GONE

            txt_selectsubortutor!!.visibility = View.VISIBLE
            Viewlinetwo!!.visibility = View.VISIBLE
            edt_selectiontuterorsubject!!.visibility = View.VISIBLE
            recycle_Staffrecipients!!.visibility = View.VISIBLE
            txt_selectspecfic!!.visibility = View.VISIBLE

            txt_department!!.visibility = View.GONE
            Viewlinethree!!.visibility = View.GONE
            txt_mydepartment!!.visibility = View.GONE
            txt_myclass!!.visibility = View.GONE


        } else if (CommonUtil.Priority.equals("p2")) {

            txt_department!!.visibility = View.VISIBLE
            Viewlinethree!!.visibility = View.VISIBLE
            txt_mydepartment!!.visibility = View.VISIBLE
            txt_myclass!!.visibility = View.VISIBLE

            layoutEntireCollege!!.visibility = View.GONE
            LayoutRecipient!!.visibility = View.GONE
            Viewlineone!!.visibility = View.GONE
            NestedScrollView!!.visibility = View.GONE

            txt_selectsubortutor!!.visibility = View.GONE
            Viewlinetwo!!.visibility = View.GONE
            edt_selectiontuterorsubject!!.visibility = View.GONE
            recycle_Staffrecipients!!.visibility = View.GONE
            txt_selectspecfic!!.visibility = View.GONE

            lbl_select_student!!.visibility = View.GONE
            Viewlinefour!!.visibility = View.GONE
            recycle_specificstudent!!.visibility = View.GONE
        }

        appViewModel = ViewModelProvider(this).get(App::class.java)
        appViewModel!!.init()


        txt_selectspecfic!!.setOnClickListener {


            if (CommonUtil.selectcheckbox.equals("1")) {
                lbl_select_student!!.visibility = View.VISIBLE
                Viewlinefour!!.visibility = View.VISIBLE
                recycle_specificstudent!!.visibility = View.VISIBLE

                txt_selectsubortutor!!.visibility = View.GONE
                Viewlinetwo!!.visibility = View.GONE
                edt_selectiontuterorsubject!!.visibility = View.GONE
                recycle_Staffrecipients!!.visibility = View.GONE
                txt_selectspecfic!!.visibility = View.GONE

                layoutEntireCollege!!.visibility = View.GONE
                LayoutRecipient!!.visibility = View.GONE
                Viewlineone!!.visibility = View.GONE
                NestedScrollView!!.visibility = View.GONE

                txt_department!!.visibility = View.GONE
                Viewlinethree!!.visibility = View.GONE
                txt_mydepartment!!.visibility = View.GONE
                txt_myclass!!.visibility = View.GONE


                if (edt_selectiontuterorsubject!!.text.equals("Subjects")) {
                    getspecificstudentdatasubject()

//                    CommonUtil.deptid = ""
//                    CommonUtil.YearId = ""
//                    CommonUtil.SectionId = ""
//                    CommonUtil.Courseid = ""

                } else if (edt_selectiontuterorsubject!!.text.equals("Tutor")) {

                    getspecificstudentdata()
//                    CommonUtil.deptid = ""
//                    CommonUtil.YearId = ""
//                    CommonUtil.SectionId = ""
//                    CommonUtil.Courseid = ""
                }
            }
        }

        txt_mydepartment!!.setOnClickListener {

            lblEntire!!.setText("Entire Department")
            lblDepartment!!.setText("Year/Section")
            lblDivision!!.setText("Courses")

            layoutEntireCollege!!.visibility = View.VISIBLE
            LayoutRecipient!!.visibility = View.VISIBLE
            Viewlineone!!.visibility = View.VISIBLE

            lblYourClasses!!.visibility = View.GONE
            lblGroups!!.visibility = View.GONE
            lblCourse!!.visibility = View.GONE
            lblDivision!!.visibility = View.VISIBLE
            lblDepartment!!.visibility = View.VISIBLE


            txt_department!!.visibility = View.GONE
            Viewlinethree!!.visibility = View.GONE
            txt_mydepartment!!.visibility = View.GONE
            txt_myclass!!.visibility = View.GONE

        }

        txt_myclass!!.setOnClickListener {

            layoutEntireCollege!!.visibility = View.GONE
            LayoutRecipient!!.visibility = View.GONE
            Viewlineone!!.visibility = View.GONE
            NestedScrollView!!.visibility = View.GONE

            txt_selectsubortutor!!.visibility = View.VISIBLE
            Viewlinetwo!!.visibility = View.VISIBLE
            edt_selectiontuterorsubject!!.visibility = View.VISIBLE
            recycle_Staffrecipients!!.visibility = View.VISIBLE
            txt_selectspecfic!!.visibility = View.VISIBLE

            txt_department!!.visibility = View.GONE
            Viewlinethree!!.visibility = View.GONE
            txt_mydepartment!!.visibility = View.GONE
            txt_myclass!!.visibility = View.GONE

        }

//        if (CommonUtil.Priority.equals("p3")) {
//            GetSubjectstaff()
//        } else if (CommonUtil.Priority.equals("p2")) {
//            GetSubjecthod()
//        }

        //specific student subject

        appViewModel!!.Getspecificstudentsubject!!.observe(this) { response ->
            if (response != null) {
                val status = response.status
                val message = response.message
                if (status == 1) {
                    getspecifictuterstudent = response.data!!
                    specificStudent_adapter = specificStudent_adapter(getspecifictuterstudent, this)
                    val mLayoutManager: RecyclerView.LayoutManager = LinearLayoutManager(this)
                    recycle_specificstudent!!.layoutManager = mLayoutManager
                    recycle_specificstudent!!.itemAnimator = DefaultItemAnimator()
                    recycle_specificstudent!!.adapter = specificStudent_adapter
                    recycle_specificstudent!!.recycledViewPool.setMaxRecycledViews(0, 80)
                    specificStudent_adapter!!.notifyDataSetChanged()
                }
            }
        }

        //sprcific student tutor

        appViewModel!!.Getspecificstudenttutot!!.observe(this) { response ->
            if (response != null) {
                val status = response.status
                val message = response.message
                if (status == 1) {
                    getspecifictuterstudent = response.data!!
                    specificStudent_adapter = specificStudent_adapter(getspecifictuterstudent, this)
                    val mLayoutManager: RecyclerView.LayoutManager = LinearLayoutManager(this)
                    recycle_specificstudent!!.layoutManager = mLayoutManager
                    recycle_specificstudent!!.itemAnimator = DefaultItemAnimator()
                    recycle_specificstudent!!.adapter = specificStudent_adapter
                    recycle_specificstudent!!.recycledViewPool.setMaxRecycledViews(0, 80)
                    specificStudent_adapter!!.notifyDataSetChanged()
                }
            }
        }

        //Event send

        appViewModel!!.Eventsenddata!!.observe(this) { response ->
            if (response != null) {
                val status = response.Status
                val message = response.Message
                if (status == 1) {

                    val dlg = this.let { AlertDialog.Builder(it) }
                    dlg.setTitle("Info")
                    dlg.setMessage(message)
                    dlg.setPositiveButton("OK", DialogInterface.OnClickListener { dialog, which ->
                        val i: Intent =

                            Intent(this, Events::class.java)
                        i.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                        startActivity(i)
                    })

                    dlg.setCancelable(false)
                    dlg.create()
                    dlg.show()

                } else {

                    val dlg = this.let { AlertDialog.Builder(it) }
                    dlg.setTitle("Info")
                    dlg.setMessage(message)
                    dlg.setPositiveButton("OK", DialogInterface.OnClickListener { dialog, which ->
                        val i: Intent =

                            Intent(this, Events::class.java)
                        i.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                        startActivity(i)
                    })

                    dlg.setCancelable(false)
                    dlg.create()
                    dlg.show()

                }

            } else {
                CommonUtil.ApiAlert(this, "Something went wrong")
            }
        }

        //ImageOrPdfsend Entire

        appViewModel!!.ImageorPdf!!.observe(this) { response ->
            if (response != null) {
                val status = response.Status
                val message = response.Message
                if (status == 1) {


                    val dlg = this.let { AlertDialog.Builder(it) }
                    dlg.setTitle("Info")
                    dlg.setMessage(message)
                    dlg.setPositiveButton("OK", DialogInterface.OnClickListener { dialog, which ->
                        val i: Intent =

                            Intent(this, Circular::class.java)
                        i.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                        startActivity(i)
                    })

                    dlg.setCancelable(false)
                    dlg.create()
                    dlg.show()

                } else {

                    val dlg = this.let { AlertDialog.Builder(it) }
                    dlg.setTitle("Info")
                    dlg.setMessage(message)
                    dlg.setPositiveButton("OK", DialogInterface.OnClickListener { dialog, which ->
                        val i: Intent =

                            Intent(this, Circular::class.java)
                        i.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                        startActivity(i)
                    })

                    dlg.setCancelable(false)
                    dlg.create()
                    dlg.show()
                }

            } else {
                CommonUtil.ApiAlert(this, "Something went wrong")
            }
        }


        //Image or pdf particuler send

        appViewModel!!.Imageorpdfparticuler!!.observe(this) { response ->
            if (response != null) {
                val status = response.Status
                val message = response.Message
                if (status == 1) {


                    val dlg = this.let { AlertDialog.Builder(it) }
                    dlg.setTitle("Info")
                    dlg.setMessage(message)
                    dlg.setPositiveButton("OK", DialogInterface.OnClickListener { dialog, which ->
                        val i: Intent =

                            Intent(this, Circular::class.java)
                        i.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                        startActivity(i)
                    })

                    dlg.setCancelable(false)
                    dlg.create()
                    dlg.show()

                } else {

                    val dlg = this.let { AlertDialog.Builder(it) }
                    dlg.setTitle("Info")
                    dlg.setMessage(message)
                    dlg.setPositiveButton("OK", DialogInterface.OnClickListener { dialog, which ->
                        val i: Intent =

                            Intent(this, Circular::class.java)
                        i.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                        startActivity(i)
                    })

                    dlg.setCancelable(false)
                    dlg.create()
                    dlg.show()
                }

            } else {
                CommonUtil.ApiAlert(this, "Something went wrong")
            }
        }

        //Assignment send

        appViewModel!!.Assignment!!.observe(this) { response ->
            if (response != null) {
                val status = response.Status
                val message = response.Message
                if (status == 1) {

                    val dlg = this.let { AlertDialog.Builder(it) }
                    dlg.setTitle("Info")
                    dlg.setMessage(message)
                    dlg.setPositiveButton("OK", DialogInterface.OnClickListener { dialog, which ->
                        val i: Intent =

                            Intent(this, Assignment::class.java)
                        i.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                        startActivity(i)
                    })

                    dlg.setCancelable(false)
                    dlg.create()
                    dlg.show()

                } else {
                    CommonUtil.ApiAlert(this, message)
                }

            } else {
                CommonUtil.ApiAlert(this, "Something went wrong")
            }
        }

        //Assignment Forward

        appViewModel!!.Assign_forward!!.observe(this) { response ->
            if (response != null) {
                val status = response.Status
                val message = response.Message

                if (status == 1) {
                    val dlg = this.let { AlertDialog.Builder(it) }
                    dlg.setTitle("Info")
                    dlg.setMessage(message)
                    dlg.setPositiveButton("OK", DialogInterface.OnClickListener { dialog, which ->
                        val i: Intent =

                            Intent(this, Assignment::class.java)
                        i.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                        startActivity(i)
                    })

                    dlg.setCancelable(false)
                    dlg.create()
                    dlg.show()

                } else {
                    CommonUtil.ApiAlert(this, message)
                }
            } else {
                CommonUtil.ApiAlert(this, "Something went wrong")
            }
        }


        //subject data

        appViewModel!!.Getsubjectdata!!.observe(this) { response ->
            if (response != null) {
                val status = response.status
                val message = response.message
                if (status == 1) {
                    getsubjectlist = response.data!!
                    sublectadapter = Subject_Adapter(getsubjectlist, this)
                    val mLayoutManager: RecyclerView.LayoutManager = LinearLayoutManager(this)
                    recycle_Staffrecipients!!.layoutManager = mLayoutManager
                    recycle_Staffrecipients!!.itemAnimator = DefaultItemAnimator()
                    recycle_Staffrecipients!!.adapter = sublectadapter
                    recycle_Staffrecipients!!.recycledViewPool.setMaxRecycledViews(0, 80)
                    sublectadapter!!.notifyDataSetChanged()
                }
            } else {
                CommonUtil.ApiAlert(
                    this, "Subject or Section Not allocated / Students not allocated to the section"
                )
            }
        }

        //totor data

        appViewModel!!.Gettuter!!.observe(this) { response ->
            if (response != null) {
                val status = response.status
                val message = response.message
                if (status == 1) {
                    getsubjectlist = response.data!!
                    sublectadapter = Subject_Adapter(getsubjectlist, this)
                    val mLayoutManager: RecyclerView.LayoutManager = LinearLayoutManager(this)
                    recycle_Staffrecipients!!.layoutManager = mLayoutManager
                    recycle_Staffrecipients!!.itemAnimator = DefaultItemAnimator()
                    recycle_Staffrecipients!!.adapter = sublectadapter
                    recycle_Staffrecipients!!.recycledViewPool.setMaxRecycledViews(0, 80)
                    sublectadapter!!.notifyDataSetChanged()
                }
            } else {
                CommonUtil.ApiAlert(
                    this, "Subject or Section Not allocated / Students not allocated to the section"
                )
            }
        }

        //HOD COURSE DATA

        appViewModel!!.GetCoursesByDepartmenthod!!.observe(this) { response ->
            if (response != null) {
                val status = response.status
                val message = response.message

                if (status == 1) {
                    Getcoursedepartment = response.data!!
                    if (Getcoursedepartment!!.size > 0) {
                        SelectedRecipientlist.clear()

                        Getcoursedepartment!!.forEach {
                            it.course_id
                            it.course_name

                            var group = RecipientSelected(it.course_id, it.course_name)
                            SelectedRecipientlist.add(group)
                        }
                        if (SelecteRecipientType.equals("Courses")) {
                            Log.d("SelectedRecipientlist", SelectedRecipientlist.toString())
                            SelectedcourseAdapter = SelectedRecipientAdapter(
                                SelectedRecipientlist,
                                this,
                                object : RecipientCheckListener {
                                    override fun add(data: RecipientSelected?) {
                                        var groupid = data!!.SelectedId
                                        Log.d("groupid", groupid.toString())

                                    }

                                    override fun remove(data: RecipientSelected?) {
                                        var groupid = data!!.SelectedId
                                    }
                                })

                            val mLayoutManager: RecyclerView.LayoutManager =
                                LinearLayoutManager(this)

                            recycleRecipients!!.layoutManager = mLayoutManager
                            recycleRecipients!!.itemAnimator = DefaultItemAnimator()
                            recycleRecipients!!.adapter = SelectedcourseAdapter
                            recycleRecipients!!.recycledViewPool.setMaxRecycledViews(0, 80)
                            SelectedcourseAdapter!!.notifyDataSetChanged()

                        } else if (SelecteRecipientType.equals("Year/Section")) {
                            LoadyearandsectionSpinnerhod()
                            Log.d("SelecteRecipientType", SelecteRecipientType.toString())
                        }
                    }
                } else {
                    CommonUtil.ApiAlert(this, "No Data Found")
                }
            } else {
                //  CommonUtil.ApiAlert(this, "Something went wrong")
            }
        }

        //group

        appViewModel!!.GetGrouplist!!.observe(this) { response ->
            if (response != null) {
                val status = response.status
                val message = response.message

                if (status == 1) {
                    GetGroupdata = response.data!!
                    if (GetGroupdata!!.size > 0) {
                        SelectedRecipientlist.clear()

                        GetGroupdata!!.forEach {
                            it.groupid
                            it.groupname

                            var group = RecipientSelected(it.groupid, it.groupname)

                            SelectedRecipientlist.add(group)
                        }
                        if (SelecteRecipientType.equals("Groups")) {
                            groupAdapter = SelectedRecipientAdapter(
                                SelectedRecipientlist!!,
                                this,
                                object : RecipientCheckListener {
                                    override fun add(data: RecipientSelected?) {
                                        var groupid = data!!.SelectedId
                                        Log.d("groupid", groupid.toString())

                                    }

                                    override fun remove(data: RecipientSelected?) {
                                        var groupid = data!!.SelectedId
                                    }
                                })


                            val mLayoutManager: RecyclerView.LayoutManager =
                                LinearLayoutManager(this)
                            recycleRecipients!!.layoutManager = mLayoutManager
                            recycleRecipients!!.itemAnimator = DefaultItemAnimator()
                            recycleRecipients!!.adapter = groupAdapter
                            recycleRecipients!!.recycledViewPool.setMaxRecycledViews(0, 80)
                            groupAdapter!!.notifyDataSetChanged()

                        }
                    } else {
                        CommonUtil.ApiAlert(this, "No Data Found")
                    }
                } else {
                    CommonUtil.ApiAlert(this, "No Data Found")
                }
            } else {
                CommonUtil.ApiAlert(this, "Something went wrong")
            }
        }

        //year and section

        appViewModel!!.GetCoursesByDepartmenthodhod!!.observe(this) { response ->
            if (response != null) {
                recycleyearandsection!!.visibility = View.VISIBLE
                val status = response.Status
                val message = response.Message
                if (status == 1) {
                    Getyouurclassdata = (response.data as ArrayList<Data>?)!!

                    CommonUtil.seleteddataArray.clear()
                    sectionandyear_Adapter = sectionandyear_Adapter(Getyouurclassdata!!, this)
                    val mLayoutManager: RecyclerView.LayoutManager = LinearLayoutManager(this)
                    recycleyearandsection!!.layoutManager = mLayoutManager
                    recycleyearandsection!!.itemAnimator = DefaultItemAnimator()
                    recycleyearandsection!!.adapter = sectionandyear_Adapter
                    recycleyearandsection!!.recycledViewPool.setMaxRecycledViews(0, 80)
                    sectionandyear_Adapter!!.notifyDataSetChanged()
                } else {
                    CommonUtil.ApiAlert(this, "No Data Found")
                }
            } else {
                CommonUtil.ApiAlert(this, "Something went wrong")
                recycleyearandsection!!.visibility = View.GONE
            }
        }

        //division

        appViewModel!!.GetDivisionMutableLiveData!!.observe(this) { response ->
            if (response != null) {
                val status = response.status
                val message = response.message

                if (status == 1) {
                    GetDivisionData = response.data!!
                    if (GetDivisionData!!.size > 0) {
                        SelectedRecipientlist.clear()

                        GetDivisionData!!.forEach {
                            it.division_id
                            it.division_name

                            val divisions = RecipientSelected(it.division_id, it.division_name)
                            SelectedRecipientlist.add(divisions)
                        }

                        if (SelecteRecipientType.equals("Division")) {
                            divisionadapter = SelectedRecipientAdapter(
                                SelectedRecipientlist!!,
                                this,
                                object : RecipientCheckListener {
                                    override fun add(data: RecipientSelected?) {
                                        var divisionId = data!!.SelectedId
                                    }

                                    override fun remove(data: RecipientSelected?) {
                                        var divisionId = data!!.SelectedId
                                    }
                                })

                            val mLayoutManager: RecyclerView.LayoutManager =
                                LinearLayoutManager(this)
                            recycleRecipients!!.layoutManager = mLayoutManager
                            recycleRecipients!!.itemAnimator = DefaultItemAnimator()
                            recycleRecipients!!.adapter = divisionadapter
                            recycleRecipients!!.recycledViewPool.setMaxRecycledViews(0, 80)
                            divisionadapter!!.notifyDataSetChanged()

                        } else if (SelecteRecipientType.equals("Department")) {
                            LoadDivisionSpinner()
                        } else if (SelecteRecipientType.equals("Course")) {
                            LoadDivisionSpinner()
                        }
                    } else {
                        CommonUtil.ApiAlert(this, "No Data Found")
                    }
                } else {
                    CommonUtil.ApiAlert(this, "No Data Found")
                }
            } else {
                CommonUtil.ApiAlert(this, "Something went wrong")
            }
        }

        //principle course

        appViewModel!!.GetCourseDepartmentMutableLiveData!!.observe(this) { response ->

            if (response != null) {

                val status = response.status
                val message = response.message
                if (status == 1) {
                    GetCourseData = response.data
                    if (GetCourseData!!.size > 0) {
                        SelectedRecipientlist.clear()
                        GetCourseData!!.forEach {
                            it.course_id
                            it.course_name
                            var department = RecipientSelected(it.course_id, it.course_name)
                            SelectedRecipientlist.add(department)
                        }

                        if (SelecteRecipientType.equals("Course")) {
                            departmentAdapter = SelectedRecipientAdapter(
                                SelectedRecipientlist!!,
                                this,
                                object : RecipientCheckListener {
                                    override fun add(data: RecipientSelected?) {
                                        var depaetmentid = data!!.SelectedId
                                    }

                                    override fun remove(data: RecipientSelected?) {
                                        var departmentid = data!!.SelectedId
                                    }
                                })

                            val mLayoutManager: RecyclerView.LayoutManager =
                                LinearLayoutManager(this)
                            recycleRecipientscourse!!.layoutManager = mLayoutManager
                            recycleRecipientscourse!!.itemAnimator = DefaultItemAnimator()
                            recycleRecipientscourse!!.adapter = departmentAdapter
                            recycleRecipientscourse!!.recycledViewPool.setMaxRecycledViews(0, 80)
                            departmentAdapter!!.notifyDataSetChanged()
                        }
                    } else {
                        CommonUtil.ApiAlert(this, "No Data Found")
                    }
                } else {
                    CommonUtil.ApiAlert(this, "No Data Found")
                }
            } else {
                CommonUtil.ApiAlert(this, "Something went wrong")
            }
        }

        //GET DEPARTMENT PRINCIPLE

        appViewModel!!.GetDepartmentMutableLiveData!!.observe(this) { response ->
            if (response != null) {
                val status = response.status
                val message = response.message
                if (status == 1) {
                    GetDepartmentData = response.data!!
                    if (GetDepartmentData!!.size > 0) {
                        SelectedRecipientlist.clear()
                        GetDepartmentData!!.forEach {
                            it.department_id
                            it.department_name
                            var divisions = RecipientSelected(it.department_id, it.department_name)
                            SelectedRecipientlist.add(divisions)
                        }
                        if (SelecteRecipientType.equals("Department")) {
                            divisionadapter = SelectedRecipientAdapter(
                                SelectedRecipientlist,
                                this,
                                object : RecipientCheckListener {
                                    override fun add(data: RecipientSelected?) {
                                        var divisionId = data!!.SelectedId
                                    }

                                    override fun remove(data: RecipientSelected?) {
                                        var divisionId = data!!.SelectedId
                                    }
                                })

                            val mLayoutManager: RecyclerView.LayoutManager =
                                LinearLayoutManager(this)
                            recycleRecipients!!.layoutManager = mLayoutManager
                            recycleRecipients!!.itemAnimator = DefaultItemAnimator()
                            recycleRecipients!!.adapter = divisionadapter
                            recycleRecipients!!.recycledViewPool.setMaxRecycledViews(0, 80)
                            divisionadapter!!.notifyDataSetChanged()

                        } else if (SelecteRecipientType.equals("Course")) {
                            Log.d("Course", SelecteRecipientType!!)
                            LoadDepartmentSpinner()
                        }
                    } else {
                        CommonUtil.ApiAlert(this, "No Data Found")
                    }
                } else {
                    CommonUtil.ApiAlert(this, "No Data Found")
                }
            } else {
                CommonUtil.ApiAlert(this, "Something went wrong")
            }
        }


        //sms entire

        appViewModel!!.SendSMSToEntireCollegeLiveData!!.observe(this) { response ->
            if (response != null) {
                val status = response.Status
                val message = response.Message
                if (status == 1) {

                    val dlg = this.let { AlertDialog.Builder(it) }
                    dlg.setTitle("Info")
                    dlg.setMessage(message)
                    dlg.setPositiveButton("OK", DialogInterface.OnClickListener { dialog, which ->
                        val i: Intent =

                            Intent(this, Communication::class.java)
                        i.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                        startActivity(i)
                    })

                    dlg.setCancelable(false)
                    dlg.create()
                    dlg.show()

                } else {

                    val dlg = this.let { AlertDialog.Builder(it) }
                    dlg.setTitle("Info")
                    dlg.setMessage(message)
                    dlg.setPositiveButton("OK", DialogInterface.OnClickListener { dialog, which ->
                        val i: Intent =

                            Intent(this, Communication::class.java)
                        i.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                        startActivity(i)
                    })

                    dlg.setCancelable(false)
                    dlg.create()
                    dlg.show()
                }

            } else {
                CommonUtil.ApiAlert(this, "Something went wrong")
            }
        }

        //particuler sms

        appViewModel!!.SendSMStoParticularMutableData!!.observe(this) { response ->
            if (response != null) {
                val status = response.Status
                val message = response.Message
                if (status == 1) {

                    val dlg = this.let { AlertDialog.Builder(it) }
                    dlg.setTitle("Info")
                    dlg.setMessage(message)
                    dlg.setPositiveButton("OK", DialogInterface.OnClickListener { dialog, which ->
                        val i: Intent =

                            Intent(this, Communication::class.java)
                        i.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                        startActivity(i)
                    })

                    dlg.setCancelable(false)
                    dlg.create()
                    dlg.show()

                } else {

                    val dlg = this.let { AlertDialog.Builder(it) }
                    dlg.setTitle("Info")
                    dlg.setMessage(message)
                    dlg.setPositiveButton("OK", DialogInterface.OnClickListener { dialog, which ->
                        val i: Intent =

                            Intent(this, Communication::class.java)
                        i.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                        startActivity(i)
                    })

                    dlg.setCancelable(false)
                    dlg.create()
                    dlg.show()
                }

            } else {
                CommonUtil.ApiAlert(this, "Something went wrong")
            }
        }

        //NoticeBoard sms send

        appViewModel!!.NoticeBoardSendSMStoParticularMutableData!!.observe(this) { response ->
            if (response != null) {
                val status = response.Status
                val message = response.Message
                if (status == 1) {

                    val dlg = this.let { AlertDialog.Builder(it) }
                    dlg.setTitle("Info")
                    dlg.setMessage(message)
                    dlg.setPositiveButton("OK", DialogInterface.OnClickListener { dialog, which ->
                        val i: Intent =

                            Intent(this, Noticeboard::class.java)
                        i.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                        startActivity(i)
                    })

                    dlg.setCancelable(false)
                    dlg.create()
                    dlg.show()

                } else {

                    val dlg = this.let { AlertDialog.Builder(it) }
                    dlg.setTitle("Info")
                    dlg.setMessage(message)
                    dlg.setPositiveButton("OK", DialogInterface.OnClickListener { dialog, which ->
                        val i: Intent =

                            Intent(this, Noticeboard::class.java)
                        i.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                        startActivity(i)
                    })

                    dlg.setCancelable(false)
                    dlg.create()
                    dlg.show()
                }

            } else {
                CommonUtil.ApiAlert(this, "Something went wrong")
            }
        }


        chboxEntire!!.setOnClickListener {

            lnrStaff!!.visibility = View.VISIBLE
            lblDivision!!.setBackgroundResource(R.drawable.bg_available_outline_red)
            lblDivision!!.setTextColor(Color.parseColor(getString(R.string.lbl_clr_red)))
            lblDepartment!!.setBackgroundResource(R.drawable.bg_available_outline_red)
            lblDepartment!!.setTextColor(Color.parseColor(getString(R.string.lbl_clr_red)))
            lblCourse!!.setBackgroundResource(R.drawable.bg_available_outline_red)
            lblCourse!!.setTextColor(Color.parseColor(getString(R.string.lbl_clr_red)))
            lblYourClasses!!.setBackgroundResource(R.drawable.bg_available_outline_red)
            lblYourClasses!!.setTextColor(Color.parseColor(getString(R.string.lbl_clr_red)))
            lblGroups!!.setBackgroundResource(R.drawable.bg_available_outline_red)
            lblGroups!!.setTextColor(Color.parseColor(getString(R.string.lbl_clr_red)))
        }

        // Video send Entire
        appViewModel!!.VideosendEntire!!.observe(this) { response ->
            if (response != null) {
                val status = response.Status
                val message = response.Message
                if (status == 1) {

                    val dlg = this.let { AlertDialog.Builder(it) }
                    dlg.setTitle("Info")
                    dlg.setMessage(message)
                    dlg.setPositiveButton("OK", DialogInterface.OnClickListener { dialog, which ->
                        val i: Intent =

                            Intent(this, Video::class.java)
                        i.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                        startActivity(i)
                    })

                    dlg.setCancelable(false)
                    dlg.create()
                    dlg.show()

                } else {
                    val dlg = this.let { AlertDialog.Builder(it) }
                    dlg.setTitle("Info")
                    dlg.setMessage(message)
                    dlg.setPositiveButton("OK", DialogInterface.OnClickListener { dialog, which ->
                        val i: Intent =

                            Intent(this, Video::class.java)
                        i.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                        startActivity(i)
                    })

                    dlg.setCancelable(false)
                    dlg.create()
                    dlg.show()
                }

            } else {
                CommonUtil.ApiAlert(this, "Something went wrong")
            }
        }

        //Video Particuler send

        appViewModel!!.VideoParticulerSend!!.observe(this) { response ->
            if (response != null) {
                val status = response.Status
                val message = response.Message
                if (status == 1) {

                    val dlg = this.let { AlertDialog.Builder(it) }
                    dlg.setTitle("Info")
                    dlg.setMessage(message)
                    dlg.setPositiveButton("OK", DialogInterface.OnClickListener { dialog, which ->
                        val i: Intent =

                            Intent(this, Video::class.java)
                        i.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                        startActivity(i)
                    })

                    dlg.setCancelable(false)
                    dlg.create()
                    dlg.show()

                } else {

                    val dlg = this.let { AlertDialog.Builder(it) }
                    dlg.setTitle("Info")
                    dlg.setMessage(message)
                    dlg.setPositiveButton("OK", DialogInterface.OnClickListener { dialog, which ->
                        val i: Intent =

                            Intent(this, Video::class.java)
                        i.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                        startActivity(i)
                    })

                    dlg.setCancelable(false)
                    dlg.create()
                    dlg.show()
                }

            } else {
                CommonUtil.ApiAlert(this, "Something went wrong")
            }
        }
    }

    override val layoutResourceId: Int
        get() = R.layout.activity_add_recipients


    //-------------SPINNING DATA----------

    private fun LoadDivisionSpinner() {

        SpinnerData.clear()
        GetDivisionData!!.forEach {
            SpinnerData.add(it.division_name!!)
        }

        val adapter = ArrayAdapter(this, R.layout.spinner_textview, SpinnerData)

        adapter.setDropDownViewResource(R.layout.spinner_recipient_layout)
        spinnerDropdown!!.adapter = adapter
        spinnerDropdown!!.prompt = "Select Division"

        spinnerDropdown!!.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>, view: View, position: Int, id: Long
            ) {
                SelectedSpinnerID = GetDivisionData!!.get(position).division_id
                Log.d("spinnerselected", SelectedSpinnerID!!)
                GetDivisionData!!.get(position).division_name?.let {
                    Log.d("spinning data", it)
                    txt_division?.setText("Select Division")

                }
                GetDepartmentRequest()
            }

            override fun onNothingSelected(parent: AdapterView<*>) {

            }

        }
    }

    private fun LoadDepartmentSpinner() {

        SpinningCoursedata.clear()
        GetDepartmentData!!.forEach {
            SpinningCoursedata.add(it.department_name!!)
        }
        val adapter = ArrayAdapter(this, R.layout.spinner_rextview_course, SpinningCoursedata)
        adapter.setDropDownViewResource(R.layout.spinner_recipient_course_layout)
        spinnerDropdowncourse!!.adapter = adapter
        spinnerDropdown!!.prompt = "Select Department"

        spinnerDropdowncourse!!.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: AdapterView<*>, view: View, position: Int, id: Long
                ) {
                    SelectedSpinnerID = GetDepartmentData!!.get(position).department_id
                    Log.d("spinnerselected", SelectedSpinnerID!!)
                    GetDepartmentData!!.get(position).department_name?.let {
                        Log.d("spinning data", it)
                    }
                    GetCourseRequesr()
                }

                override fun onNothingSelected(parent: AdapterView<*>) {

                }
            }
    }

    private fun LoadyearandsectionSpinnerhod() {

        SpinningCoursedatahod.clear()
        Getcoursedepartment!!.forEach {
            SpinningCoursedatahod.add(it.course_name!!)
            Log.d("SpinningCoursedata", SpinningCoursedata.toString())
        }
        val adapter = ArrayAdapter(this, R.layout.spinner_rextview_course, SpinningCoursedatahod)
        adapter.setDropDownViewResource(R.layout.spinner_recipient_course_layout)
        spinnerDropdown!!.adapter = adapter
        spinnerDropdown!!.prompt = "Select Year"

        spinnerDropdown!!.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>, view: View, position: Int, id: Long
            ) {
                SelectedSpinnerIDhod = Getcoursedepartment!!.get(position).course_id

                Getcoursedepartment!!.get(position).course_name?.let {
                    Log.d("spinning data", it)
                }
                GetyearandsectionRequest()
            }

            override fun onNothingSelected(parent: AdapterView<*>) {

            }
        }
    }

    @OnClick(R.id.edt_selectiontuterorsubject)
    fun POPUP() {

        if (CommonUtil.Priority.equals("p3")) {
            edt_selectiontuterorsubject?.setOnClickListener {
                val popupMenu = PopupMenu(this@AddRecipients, edt_selectiontuterorsubject)
                popupMenu.menuInflater.inflate(R.menu.tutor_or_sublect, popupMenu.menu)
                popupMenu.setOnMenuItemClickListener { menuItem ->

                    edt_selectiontuterorsubject!!.setText(menuItem.title)
                    if (edt_selectiontuterorsubject!!.text.equals("Subjects")) {
                        recycle_Staffrecipients!!.visibility = View.VISIBLE
                        GetSubjectstaff()
                    } else if (edt_selectiontuterorsubject!!.text.equals("Tutor")) {
                        Gettuter()
                    }
                    true
                }
                popupMenu.show()
            }
        } else if (CommonUtil.Priority.equals("p2")) {

            edt_selectiontuterorsubject?.setOnClickListener {
                val popupMenu = PopupMenu(this@AddRecipients, edt_selectiontuterorsubject)
                popupMenu.menuInflater.inflate(R.menu.tutor_or_sublect, popupMenu.menu)
                popupMenu.setOnMenuItemClickListener { menuItem ->

                    edt_selectiontuterorsubject!!.setText(menuItem.title)
                    if (edt_selectiontuterorsubject!!.text.equals("Subjects")) {
                        recycle_Staffrecipients!!.visibility = View.VISIBLE
                        GetSubjecthod()
                    } else if (edt_selectiontuterorsubject!!.text.equals("Tutor")) {
                        Gettuterhod()
                    }
                    true
                }
                popupMenu.show()
            }
        } else if (CommonUtil.Priority.equals("p1")) {

            edt_selectiontuterorsubject?.setOnClickListener {
                val popupMenu = PopupMenu(this@AddRecipients, edt_selectiontuterorsubject)
                popupMenu.menuInflater.inflate(R.menu.tutor_or_sublect, popupMenu.menu)
                popupMenu.setOnMenuItemClickListener { menuItem ->

                    edt_selectiontuterorsubject!!.setText(menuItem.title)
                    if (edt_selectiontuterorsubject!!.text.equals("Subjects")) {
                        recycle_Staffrecipients!!.visibility = View.VISIBLE
                        CommonUtil.receivertype = "5"
                        GetSubjectprinciple()
                    } else if (edt_selectiontuterorsubject!!.text.equals("Tutor")) {
                        CommonUtil.receivertype = "5"
                        Gettuterprinciple()
                    }
                    true
                }
                popupMenu.show()
            }
        }
    }

    //----------CONFORM AND CANCLE BUTTON ------------

    @OnClick(R.id.btnConfirm)
    fun SendButtonAPi() {

        val alertDialog: AlertDialog.Builder = AlertDialog.Builder(this@AddRecipients)
        alertDialog.setTitle("info")
        alertDialog.setMessage("Are you want to Send?")
        alertDialog.setPositiveButton(
            "yes"
        ) { _, _ ->

            if (ScreenName.equals("Text")) {
                if (chboxEntire!!.isChecked && chboxEntire!!.getVisibility() == View.VISIBLE && txt_selectsubortutor!!.getVisibility() == View.GONE && lbl_select_student!!.getVisibility() == View.GONE) {

                    if ((chboxParents!!.isChecked) || (chboxStaff!!.isChecked) || (chboxStudent!!.isChecked) || (chboxParents!!.isChecked && chboxStaff!!.isChecked) || (chboxStudent!!.isChecked && chboxParents!!.isChecked) || (chboxStudent!!.isChecked && chboxStaff!!.isChecked) || (chboxParents!!.isChecked && chboxStaff!!.isChecked && chboxStudent!!.isChecked)) {
                        SmsToEntireCollegeRequest()
                        lblSelectedRecipient!!.setText("")
                        SelectedRecipientlist.clear()

                    } else {

                        Toast.makeText(
                            this, "kindly select the any one check box", Toast.LENGTH_LONG
                        ).show()
                    }

                } else if (txt_selectspecfic!!.getVisibility() == View.VISIBLE && txt_selectsubortutor!!.getVisibility() == View.VISIBLE) {
                    CommonUtil.receivertype = "7"
                    SmsToEntireCollegesubjectandtuterRequest()

                } else {

                    if ((chboxParents!!.isChecked) || (chboxStaff!!.isChecked) || (chboxStudent!!.isChecked) || (chboxParents!!.isChecked && chboxStaff!!.isChecked) || (chboxStudent!!.isChecked && chboxParents!!.isChecked) || (chboxStudent!!.isChecked && chboxStaff!!.isChecked) || (chboxParents!!.isChecked && chboxStaff!!.isChecked && chboxStudent!!.isChecked)) {
                        SmsToParticularTypeRequest()
                        lblSelectedRecipient!!.setText("")
                        SelectedRecipientlist.clear()

                    } else {

                        Toast.makeText(
                            this, "kindly select the any one check box", Toast.LENGTH_LONG
                        ).show()
                    }
                }

            } else if (ScreenName.equals("Noticeboard")) {

                if (chboxEntire!!.isChecked) {
                    CommonUtil.receivertype = "1"

                    if ((chboxParents!!.isChecked) || (chboxStaff!!.isChecked) || (chboxStudent!!.isChecked) || (chboxParents!!.isChecked && chboxStaff!!.isChecked) || (chboxStudent!!.isChecked && chboxParents!!.isChecked) || (chboxStudent!!.isChecked && chboxStaff!!.isChecked) || (chboxParents!!.isChecked && chboxStaff!!.isChecked && chboxStudent!!.isChecked)) {
                        NoticeBoardSMSsending()
                        lblSelectedRecipient!!.setText("")
                        SelectedRecipientlist.clear()
                    } else {
                        Toast.makeText(
                            this, "kindly select the any one check box", Toast.LENGTH_LONG
                        ).show()
                    }

                } else {

                    if ((chboxParents!!.isChecked) || (chboxStaff!!.isChecked) || (chboxStudent!!.isChecked) || (chboxParents!!.isChecked && chboxStaff!!.isChecked) || (chboxStudent!!.isChecked && chboxParents!!.isChecked) || (chboxStudent!!.isChecked && chboxStaff!!.isChecked) || (chboxParents!!.isChecked && chboxStaff!!.isChecked && chboxStudent!!.isChecked)) {
                        lblSelectedRecipient!!.setText("")
                        SelectedRecipientlist.clear()
                        NoticeBoardSMSsending()
                    } else {
                        Toast.makeText(
                            this, "kindly select the any one check box", Toast.LENGTH_LONG
                        ).show()
                    }
                }

            } else if (ScreenName.equals("Communication")) {
                if (chboxEntire!!.isChecked) {

                    if ((chboxParents!!.isChecked) || (chboxStaff!!.isChecked) || (chboxStudent!!.isChecked) || (chboxParents!!.isChecked && chboxStaff!!.isChecked) || (chboxStudent!!.isChecked && chboxParents!!.isChecked) || (chboxStudent!!.isChecked && chboxStaff!!.isChecked) || (chboxParents!!.isChecked && chboxStaff!!.isChecked && chboxStudent!!.isChecked)) {
                        VoiceSendEntire()

                        lblSelectedRecipient!!.setText("")
                        SelectedRecipientlist.clear()
                    } else {
                        Toast.makeText(
                            this, "kindly select the any one check box", Toast.LENGTH_LONG
                        ).show()
                    }

                } else if (txt_selectspecfic!!.getVisibility() == View.VISIBLE) {
                    CommonUtil.receivertype = "7"
                    VoiceSendTuter()

                } else {

                    if ((chboxParents!!.isChecked) || (chboxStaff!!.isChecked) || (chboxStudent!!.isChecked) || (chboxParents!!.isChecked && chboxStaff!!.isChecked) || (chboxStudent!!.isChecked && chboxParents!!.isChecked) || (chboxStudent!!.isChecked && chboxStaff!!.isChecked) || (chboxParents!!.isChecked && chboxStaff!!.isChecked && chboxStudent!!.isChecked)) {
                        VoiceSendParticuler()

                        lblSelectedRecipient!!.setText("")
                        SelectedRecipientlist.clear()
                    } else {
                        Toast.makeText(
                            this, "kindly select the any one check box", Toast.LENGTH_LONG
                        ).show()
                    }
                }
            } else if (ScreenName.equals("New Image/Pdf")) {

                awsFileUpload(this, pathIndex)
            } else if (ScreenName.equals("New Assignment")) {

                awsFileUpload(this, pathIndex)

            } else if (ScreenName.equals("New Video")) {

                if (chboxEntire!!.isChecked) {
                    CommonUtil.receivertype = "1"

                    if ((chboxParents!!.isChecked) || (chboxStaff!!.isChecked) || (chboxStudent!!.isChecked) || (chboxParents!!.isChecked && chboxStaff!!.isChecked) || (chboxStudent!!.isChecked && chboxParents!!.isChecked) || (chboxStudent!!.isChecked && chboxStaff!!.isChecked) || (chboxParents!!.isChecked && chboxStaff!!.isChecked && chboxStudent!!.isChecked)) {
                        lblSelectedRecipient!!.setText("")
                        SelectedRecipientlist.clear()
                        VideosendEntire()

                    } else {

                        Toast.makeText(
                            this, "kindly select the any one check box", Toast.LENGTH_LONG
                        ).show()
                    }
                } else {
                    if ((chboxParents!!.isChecked) || (chboxStaff!!.isChecked) || (chboxStudent!!.isChecked) || (chboxParents!!.isChecked && chboxStaff!!.isChecked) || (chboxStudent!!.isChecked && chboxParents!!.isChecked) || (chboxStudent!!.isChecked && chboxStaff!!.isChecked) || (chboxParents!!.isChecked && chboxStaff!!.isChecked && chboxStudent!!.isChecked)) {
                        lblSelectedRecipient!!.setText("")
                        SelectedRecipientlist.clear()
                        VideosendParticuler()

                    } else {
                        Toast.makeText(
                            this, "kindly select the any one check box", Toast.LENGTH_LONG
                        ).show()
                    }
                }
            } else if (ScreenNameEvent.equals("ScreenNameEvent")) {

                if (chboxEntire!!.isChecked) {
                    if ((chboxParents!!.isChecked) || (chboxStaff!!.isChecked) || (chboxStudent!!.isChecked) || (chboxParents!!.isChecked && chboxStaff!!.isChecked) || (chboxStudent!!.isChecked && chboxParents!!.isChecked) || (chboxStudent!!.isChecked && chboxStaff!!.isChecked) || (chboxParents!!.isChecked && chboxStaff!!.isChecked && chboxStudent!!.isChecked)) {
                        lblSelectedRecipient!!.setText("")
                        SelectedRecipientlist.clear()
                        CommonUtil.receivertype = "1"

                        if (CommonUtil.EventsendType.equals("Edit")){
                            CommonUtil.EventsendType=""
                            Eventsend("edit")
                        }else{
                            CommonUtil.EventsendType=""
                            Eventsend("add")
                        }
                    } else {
                        Toast.makeText(
                            this, "kindly select the any one check box", Toast.LENGTH_LONG
                        ).show()
                    }
                } else if (txt_selectsubortutor!!.getVisibility() == View.VISIBLE && lbl_select_student!!.getVisibility() == View.GONE) {
                    if ((chboxParents!!.isChecked) || (chboxStaff!!.isChecked) || (chboxStudent!!.isChecked) || (chboxParents!!.isChecked && chboxStaff!!.isChecked) || (chboxStudent!!.isChecked && chboxParents!!.isChecked) || (chboxStudent!!.isChecked && chboxStaff!!.isChecked) || (chboxParents!!.isChecked && chboxStaff!!.isChecked && chboxStudent!!.isChecked)) {
                        lblSelectedRecipient!!.setText("")
                        SelectedRecipientlist.clear()
                        CommonUtil.receivertype = "5"

                        if (CommonUtil.EventsendType.equals("Edit")){
                            CommonUtil.EventsendType=""
                            Eventsend("edit")
                        }else{
                            CommonUtil.EventsendType=""
                            Eventsend("add")
                        }

                    } else {
                        Toast.makeText(
                            this, "kindly select the any one check box", Toast.LENGTH_LONG
                        ).show()
                    }
                } else if (txt_selectsubortutor!!.getVisibility() == View.GONE && lbl_select_student!!.getVisibility() == View.VISIBLE) {
                    if ((chboxParents!!.isChecked) || (chboxStaff!!.isChecked) || (chboxStudent!!.isChecked) || (chboxParents!!.isChecked && chboxStaff!!.isChecked) || (chboxStudent!!.isChecked && chboxParents!!.isChecked) || (chboxStudent!!.isChecked && chboxStaff!!.isChecked) || (chboxParents!!.isChecked && chboxStaff!!.isChecked && chboxStudent!!.isChecked)) {
                        lblSelectedRecipient!!.setText("")
                        SelectedRecipientlist.clear()
                        CommonUtil.receivertype = "7"

                        if (CommonUtil.EventsendType.equals("Edit")){
                            CommonUtil.EventsendType=""
                            Eventsend("edit")
                        }else{
                            CommonUtil.EventsendType=""
                            Eventsend("add")
                        }

                    } else {
                        Toast.makeText(
                            this, "kindly select the any one check box", Toast.LENGTH_LONG
                        ).show()
                    }
                } else {
                    if ((chboxParents!!.isChecked) || (chboxStaff!!.isChecked) || (chboxStudent!!.isChecked) || (chboxParents!!.isChecked && chboxStaff!!.isChecked) || (chboxStudent!!.isChecked && chboxParents!!.isChecked) || (chboxStudent!!.isChecked && chboxStaff!!.isChecked) || (chboxParents!!.isChecked && chboxStaff!!.isChecked && chboxStudent!!.isChecked)) {

                        if (CommonUtil.EventsendType.equals("Edit")){
                            CommonUtil.EventsendType=""
                            Eventsend("edit")
                        }else{
                            CommonUtil.EventsendType=""
                            Eventsend("add")
                        }
                        lblSelectedRecipient!!.setText("")
                        SelectedRecipientlist.clear()
                    } else {
                        Toast.makeText(
                            this, "kindly select the any one check box", Toast.LENGTH_LONG
                        ).show()
                    }
                }
            } else if (ScreenName.equals("Forward Assignment")) {
                CommonUtil.receivertype = "1"
                Assignmentforward()
            }
        }
        alertDialog.setNegativeButton(
            "No"
        ) { _, _ -> }
        val alert: AlertDialog = alertDialog.create()
        alert.setCanceledOnTouchOutside(false)
        alert.show()
    }

    @OnClick(R.id.btnRecipientCancel)
    fun cancelClick() {

        if (lbl_select_student!!.getVisibility() == View.VISIBLE && CommonUtil.Priority.equals("p3")) {

            txt_selectsubortutor!!.visibility = View.VISIBLE
            Viewlinetwo!!.visibility = View.VISIBLE
            edt_selectiontuterorsubject!!.visibility = View.VISIBLE
            recycle_Staffrecipients!!.visibility = View.VISIBLE
            txt_selectspecfic!!.visibility = View.VISIBLE

            lbl_select_student!!.visibility = View.GONE
            Viewlinefour!!.visibility = View.GONE
            recycle_specificstudent!!.visibility = View.GONE
        } else if (txt_selectsubortutor!!.getVisibility() == View.VISIBLE && CommonUtil.Priority.equals(
                "p1"
            )
        ) {

            onBackPressed()

//            val i: Intent =
//
//                Intent(this, Assignment::class.java)
//            startActivity(i)

//            layoutEntireCollege!!.visibility = View.VISIBLE
//            LayoutRecipient!!.visibility = View.VISIBLE
//            Viewlineone!!.visibility = View.VISIBLE
//            NestedScrollView!!.visibility = View.VISIBLE
//
//            txt_selectsubortutor!!.visibility = View.GONE
//            Viewlinetwo!!.visibility = View.GONE
//            edt_selectiontuterorsubject!!.visibility = View.GONE
//            recycle_Staffrecipients!!.visibility = View.GONE
//            txt_selectspecfic!!.visibility = View.GONE


            //   layoutEntireDepartment!!.visibility = View.GONE
//            txt_department!!.visibility = View.GONE
//            Viewlinethree!!.visibility = View.GONE
//            txt_mydepartment!!.visibility = View.GONE
//            txt_myclass!!.visibility = View.GONE
//
//            lbl_select_student!!.visibility = View.GONE
//            Viewlinefour!!.visibility = View.GONE
//            recycle_specificstudent!!.visibility = View.GONE
        } else if (lbl_select_student!!.getVisibility() == View.VISIBLE && CommonUtil.Priority.equals(
                "p1"
            )
        ) {
            txt_selectsubortutor!!.visibility = View.VISIBLE
            Viewlinetwo!!.visibility = View.VISIBLE
            edt_selectiontuterorsubject!!.visibility = View.VISIBLE
            recycle_Staffrecipients!!.visibility = View.VISIBLE
            txt_selectspecfic!!.visibility = View.VISIBLE

            lbl_select_student!!.visibility = View.GONE
            Viewlinefour!!.visibility = View.GONE
            recycle_specificstudent!!.visibility = View.GONE
        } else if (lbl_select_student!!.getVisibility() == View.VISIBLE && CommonUtil.Priority.equals(
                "p2"
            )
        ) {
            txt_selectsubortutor!!.visibility = View.VISIBLE
            Viewlinetwo!!.visibility = View.VISIBLE
            edt_selectiontuterorsubject!!.visibility = View.VISIBLE
            recycle_Staffrecipients!!.visibility = View.VISIBLE
            txt_selectspecfic!!.visibility = View.VISIBLE

            lbl_select_student!!.visibility = View.GONE
            Viewlinefour!!.visibility = View.GONE
            recycle_specificstudent!!.visibility = View.GONE
        } else if (txt_selectsubortutor!!.getVisibility() == View.VISIBLE && CommonUtil.Priority.equals(
                "p2"
            )
        ) {

            // layoutEntireDepartment!!.visibility = View.VISIBLE
            txt_department!!.visibility = View.VISIBLE
            Viewlinethree!!.visibility = View.VISIBLE
            txt_mydepartment!!.visibility = View.VISIBLE
            txt_myclass!!.visibility = View.VISIBLE

            layoutEntireCollege!!.visibility = View.GONE
            LayoutRecipient!!.visibility = View.GONE
            Viewlineone!!.visibility = View.GONE
            NestedScrollView!!.visibility = View.GONE

            txt_selectsubortutor!!.visibility = View.GONE
            Viewlinetwo!!.visibility = View.GONE
            edt_selectiontuterorsubject!!.visibility = View.GONE
            recycle_Staffrecipients!!.visibility = View.GONE
            txt_selectspecfic!!.visibility = View.GONE

            lbl_select_student!!.visibility = View.GONE
            Viewlinefour!!.visibility = View.GONE
            recycle_specificstudent!!.visibility = View.GONE

        } else if (lblEntire!!.text.equals("Entire Department") && CommonUtil.Priority.equals("p2") && txt_department!!.getVisibility() == View.GONE) {
            txt_department!!.visibility = View.VISIBLE
            Viewlinethree!!.visibility = View.VISIBLE
            txt_mydepartment!!.visibility = View.VISIBLE
            txt_myclass!!.visibility = View.VISIBLE

            layoutEntireCollege!!.visibility = View.GONE
            LayoutRecipient!!.visibility = View.GONE
            Viewlineone!!.visibility = View.GONE
            NestedScrollView!!.visibility = View.GONE

            txt_selectsubortutor!!.visibility = View.GONE
            Viewlinetwo!!.visibility = View.GONE
            edt_selectiontuterorsubject!!.visibility = View.GONE
            recycle_Staffrecipients!!.visibility = View.GONE
            txt_selectspecfic!!.visibility = View.GONE

            lbl_select_student!!.visibility = View.GONE
            Viewlinefour!!.visibility = View.GONE
            recycle_specificstudent!!.visibility = View.GONE

        } else {
            onBackPressed()
        }
    }


    //----------------------API REQUESTS----------------------------------


    private fun GetDivisionRequest() {

        val jsonObject = JsonObject()
        jsonObject.addProperty(ApiRequestNames.Req_user_id, CommonUtil.MemberId)
        jsonObject.addProperty(ApiRequestNames.Req_college_id, CommonUtil.CollegeId)
        appViewModel!!.getDivision(jsonObject, this)
        Log.d("GetDivisionRequest", jsonObject.toString())
    }

    private fun GetSubjectstaff() {

        val jsonObject = JsonObject()
        jsonObject.addProperty(ApiRequestNames.Req_staffid, CommonUtil.MemberId)
        jsonObject.addProperty(ApiRequestNames.Req_collegeid, CommonUtil.CollegeId)
        appViewModel!!.getsubject(jsonObject, this)
        Log.d("GetstaffRequest", jsonObject.toString())
    }

    private fun GetSubjecthod() {

        val jsonObject = JsonObject()
        jsonObject.addProperty(ApiRequestNames.Req_staffid, CommonUtil.MemberId)
        jsonObject.addProperty(ApiRequestNames.Req_collegeid, CommonUtil.CollegeId)
        appViewModel!!.getsubject(jsonObject, this)
        Log.d("GetstaffRequest", jsonObject.toString())
    }

    private fun GetSubjectprinciple() {

        val jsonObject = JsonObject()
        jsonObject.addProperty(ApiRequestNames.Req_staffid, CommonUtil.MemberId)
        jsonObject.addProperty(ApiRequestNames.Req_collegeid, CommonUtil.CollegeId)
        appViewModel!!.getsubject(jsonObject, this)
        Log.d("GetstaffRequest", jsonObject.toString())
    }

    private fun Gettuter() {

        val jsonObject = JsonObject()
        jsonObject.addProperty(ApiRequestNames.Req_staffid, CommonUtil.MemberId)
        jsonObject.addProperty(ApiRequestNames.Req_collegeid, CommonUtil.CollegeId)
        appViewModel!!.gettuter(jsonObject, this)
        Log.d("GettuterRequest", jsonObject.toString())
    }

    private fun Gettuterhod() {

        val jsonObject = JsonObject()
        jsonObject.addProperty(ApiRequestNames.Req_staffid, CommonUtil.MemberId)
        jsonObject.addProperty(ApiRequestNames.Req_collegeid, CommonUtil.CollegeId)
        appViewModel!!.gettuter(jsonObject, this)
        Log.d("GettuterRequest", jsonObject.toString())
    }

    private fun Gettuterprinciple() {

        val jsonObject = JsonObject()
        jsonObject.addProperty(ApiRequestNames.Req_staffid, CommonUtil.MemberId)
        jsonObject.addProperty(ApiRequestNames.Req_collegeid, CommonUtil.CollegeId)
        appViewModel!!.gettuter(jsonObject, this)
        Log.d("GettuterRequest", jsonObject.toString())
    }

    private fun getcoursedepartment() {

        val jsonObject = JsonObject()
        jsonObject.addProperty(ApiRequestNames.Req_user_id, CommonUtil.MemberId)
        jsonObject.addProperty(ApiRequestNames.Req_college_id, CommonUtil.CollegeId)
        jsonObject.addProperty(ApiRequestNames.Req_dept_id, CommonUtil.DepartmentId)
        appViewModel!!.getcoursedepartment(jsonObject, this)
        Log.d("getdepartcousereq", jsonObject.toString())
    }

    private fun getspecificstudentdata() {

        val jsonObject = JsonObject()
        jsonObject.addProperty(ApiRequestNames.Req_staffid, CommonUtil.MemberId)
        jsonObject.addProperty(ApiRequestNames.Req_collegeid, CommonUtil.CollegeId)
        jsonObject.addProperty(ApiRequestNames.Req_dept_id, CommonUtil.deptid)
        jsonObject.addProperty(ApiRequestNames.Req_yearid, CommonUtil.YearId)
        jsonObject.addProperty(ApiRequestNames.Req_sectionid, CommonUtil.SectionId)

        appViewModel!!.getspecificstudentdata(jsonObject, this)
        Log.d("GettuterspecificRequest", jsonObject.toString())
    }

    private fun getspecificstudentdatasubject() {

        val jsonObject = JsonObject()
        jsonObject.addProperty(ApiRequestNames.Req_i_course_id, CommonUtil.Courseid)
        jsonObject.addProperty(ApiRequestNames.Req_collegeid, CommonUtil.CollegeId)
        jsonObject.addProperty(ApiRequestNames.Req_deptid, CommonUtil.deptid)
        jsonObject.addProperty(ApiRequestNames.Req_yearid, CommonUtil.YearId)
        jsonObject.addProperty(ApiRequestNames.Req_sectionid, CommonUtil.SectionId)

        appViewModel!!.getspecificstudentdatasubject(jsonObject, this)
        Log.d("Getspecificsubject", jsonObject.toString())
    }

    private fun GetDepartmentRequest() {

        val jsonObject = JsonObject()
        jsonObject.addProperty(ApiRequestNames.Req_user_id, CommonUtil.MemberId)
        jsonObject.addProperty(ApiRequestNames.Req_college_id, CommonUtil.CollegeId)
        jsonObject.addProperty(ApiRequestNames.Req_div_id, SelectedSpinnerID)
        appViewModel!!.getDepartment(jsonObject, this)
        Log.d("GetDepartmentRequest", jsonObject.toString())
    }

    private fun GetCourseRequesr() {
        val jsonObject = JsonObject()
        jsonObject.addProperty(ApiRequestNames.Req_user_id, CommonUtil.MemberId)
        jsonObject.addProperty(ApiRequestNames.Req_college_id, CommonUtil.CollegeId)
        jsonObject.addProperty(ApiRequestNames.Req_depart_id, SelectedSpinnerID)
        appViewModel!!.getCourseDepartment(jsonObject, this)
        Log.d("GetCourseRequeat", jsonObject.toString())
    }

    private fun GetyearandsectionRequest() {
        val jsonObject = JsonObject()
        jsonObject.addProperty(ApiRequestNames.Req_clgprocessby, CommonUtil.MemberId)
        jsonObject.addProperty(ApiRequestNames.Req_idcollege, CommonUtil.CollegeId)
        jsonObject.addProperty(ApiRequestNames.Req_idcourse, SelectedSpinnerIDhod)
        appViewModel!!.getyearsndsection(jsonObject, this)
        Log.d("Gety&sectionRequeat", jsonObject.toString())
    }

    private fun GetGroup() {
        val jsonObject = JsonObject()
        jsonObject.addProperty(ApiRequestNames.Req_idcollege, CommonUtil.CollegeId)
        Log.d("GetGroupRequeat", jsonObject.toString())
        appViewModel!!.getGroup(jsonObject, this)
    }

    private fun SmsToEntireCollegeRequest() {

        val jsonObject = JsonObject()
        jsonObject.addProperty(ApiRequestNames.Req_collegeid, CommonUtil.CollegeId)
        jsonObject.addProperty(ApiRequestNames.Req_staffid, CommonUtil.MemberId)
        jsonObject.addProperty(ApiRequestNames.Req_Callertye, CommonUtil.Priority)
        jsonObject.addProperty(ApiRequestNames.Req_filetype, "1")
        jsonObject.addProperty(ApiRequestNames.Req_MessageContent, CommonUtil.MenuTitle)
        jsonObject.addProperty(ApiRequestNames.Req_isStudent, isStudent)
        jsonObject.addProperty(ApiRequestNames.Req_isStaff, isStaff)
        jsonObject.addProperty(ApiRequestNames.Req_isParent, isParent)
        jsonObject.addProperty(ApiRequestNames.Req_Description, CommonUtil.MenuDescription)

        appViewModel!!.SendSmsToEntireCollege(jsonObject, this)
        Log.d("SMSJsonObject", jsonObject.toString())
    }


    private fun VoiceToEntireCollegeRequest() {

        val jsonObject = JsonObject()
        jsonObject.addProperty(ApiRequestNames.Req_collegeid, CommonUtil.CollegeId)
        jsonObject.addProperty(ApiRequestNames.Req_staffid, CommonUtil.MemberId)
        jsonObject.addProperty(ApiRequestNames.Req_Callertye, CommonUtil.Priority)
        jsonObject.addProperty(ApiRequestNames.Req_filetype, "1")
        jsonObject.addProperty(ApiRequestNames.Req_isStudent, isStudent)
        jsonObject.addProperty(ApiRequestNames.Req_isStaff, isStaff)
        jsonObject.addProperty(ApiRequestNames.Req_isParent, isParent)
        jsonObject.addProperty("fileduration", "20")
        jsonObject.addProperty("isemergencyvoice", "0")
        jsonObject.addProperty(ApiRequestNames.Req_Description, CommonUtil.MenuDescription)

        appViewModel!!.SendVoiceToEntireCollege(jsonObject, this)
        Log.d("SMSJsonObject", jsonObject.toString())
    }

    private fun SmsToEntireCollegesubjectandtuterRequest() {

        val jsonObject = JsonObject()
        jsonObject.addProperty(ApiRequestNames.Req_collegeid, CommonUtil.CollegeId)
        jsonObject.addProperty(ApiRequestNames.Req_staffid, CommonUtil.MemberId)
        jsonObject.addProperty(ApiRequestNames.Req_Callertye, CommonUtil.Priority)
        jsonObject.addProperty(ApiRequestNames.Req_filetype, "4")
        jsonObject.addProperty(ApiRequestNames.Req_MessageContent, CommonUtil.MenuTitle)
        jsonObject.addProperty(ApiRequestNames.Req_isStudent, isStudent)
        jsonObject.addProperty(ApiRequestNames.Req_isStaff, isStaff)
        jsonObject.addProperty(ApiRequestNames.Req_isParent, isParent)
        jsonObject.addProperty(ApiRequestNames.Req_receivertype, CommonUtil.receivertype)
        jsonObject.addProperty(ApiRequestNames.Req_receviedit, CommonUtil.receiverid)
        jsonObject.addProperty(ApiRequestNames.Req_Description, CommonUtil.MenuDescription)

        appViewModel!!.SendSmsToEntiretutorandsubjectCollege(jsonObject, this)
        Log.d("SMSJsonObject", jsonObject.toString())
    }

    private fun SmsToParticularTypeRequest() {
        val jsonObject = JsonObject()
        jsonObject.addProperty(ApiRequestNames.Req_collegeid, CommonUtil.CollegeId)
        jsonObject.addProperty(ApiRequestNames.Req_staffid, CommonUtil.MemberId)
        jsonObject.addProperty(ApiRequestNames.Req_Callertye, CommonUtil.Priority)
        jsonObject.addProperty(ApiRequestNames.Req_filetype, "4")
        jsonObject.addProperty(ApiRequestNames.Req_MessageContent, CommonUtil.MenuTitle)
        jsonObject.addProperty(ApiRequestNames.Req_isStudent, isStudent)
        jsonObject.addProperty(ApiRequestNames.Req_isStaff, isStaff)
        jsonObject.addProperty(ApiRequestNames.Req_isParent, isParent)
        jsonObject.addProperty(ApiRequestNames.Req_Description, CommonUtil.MenuDescription)
        jsonObject.addProperty(ApiRequestNames.Req_receivertype, CommonUtil.receivertype)
        jsonObject.addProperty(ApiRequestNames.Req_receviedit, CommonUtil.receiverid)

        appViewModel!!.SendSmsToParticularType(jsonObject, this)
        Log.d("SMSJsonObject", jsonObject.toString())
    }

    private fun NoticeBoardSMSsending() {
        val jsonObject = JsonObject()
        jsonObject.addProperty(ApiRequestNames.Req_noticeboardid, "0")
        jsonObject.addProperty(ApiRequestNames.Req_colgid, CommonUtil.CollegeId)
        jsonObject.addProperty(ApiRequestNames.Req_receivertype, CommonUtil.receivertype)
        jsonObject.addProperty(ApiRequestNames.Req_receiveridlist, CommonUtil.receiverid)
        jsonObject.addProperty(ApiRequestNames.Req_topic, CommonUtil.MenuTitle)
        jsonObject.addProperty(ApiRequestNames.Req_Description, CommonUtil.MenuDescription)
        jsonObject.addProperty(ApiRequestNames.Req_staffid, CommonUtil.MemberId)
        jsonObject.addProperty(ApiRequestNames.Req_Callertye, CommonUtil.Priority)
        jsonObject.addProperty(ApiRequestNames.Req_processtype, "add")
        jsonObject.addProperty(ApiRequestNames.Req_isStudent, isStudent)
        jsonObject.addProperty(ApiRequestNames.Req_isStaff, isStaff)
        jsonObject.addProperty(ApiRequestNames.Req_isParent, isParent)


        appViewModel!!.NoticeBoardsmssending(jsonObject, this)
        Log.d("SMSJsonObject", jsonObject.toString())
    }

    private fun Eventsend(prossertype:String) {
        val jsonObject = JsonObject()
        jsonObject.addProperty(ApiRequestNames.Req_eventid, "0")
        jsonObject.addProperty(ApiRequestNames.Req_collegeid, CommonUtil.CollegeId)
        jsonObject.addProperty(ApiRequestNames.Req_staffid, CommonUtil.MemberId)
        jsonObject.addProperty(ApiRequestNames.Req_eventdate, CommonUtil.Date)
        jsonObject.addProperty(ApiRequestNames.Req_eventtime, CommonUtil.Time)
        jsonObject.addProperty(ApiRequestNames.Req_eventbody, CommonUtil.MenuDescription)
        jsonObject.addProperty(ApiRequestNames.Req_eventtopic, CommonUtil.MenuTitle)
        jsonObject.addProperty(ApiRequestNames.Req_processtype, prossertype)
        jsonObject.addProperty(ApiRequestNames.Req_isStudent, isStudent)
        jsonObject.addProperty(ApiRequestNames.Req_isStaff, isStaff)
        jsonObject.addProperty(ApiRequestNames.Req_isParent, isParent)
        jsonObject.addProperty(ApiRequestNames.Req_eventvenue, CommonUtil.Venuetext)
        jsonObject.addProperty(ApiRequestNames.Req_callertye, CommonUtil.Priority)
        jsonObject.addProperty(ApiRequestNames.Req_receiveridlist, CommonUtil.receiverid)
        jsonObject.addProperty(ApiRequestNames.Req_receivertype, CommonUtil.receivertype)

        appViewModel!!.Eventsend(jsonObject, this)
        Log.d("SMSJsonObject", jsonObject.toString())
    }

    private fun ImageOrPdfsendentire() {
        val jsonObject = JsonObject()
        jsonObject.addProperty("collegeid", CommonUtil.CollegeId)
        jsonObject.addProperty(ApiRequestNames.Req_staffid, CommonUtil.MemberId)
        jsonObject.addProperty(ApiRequestNames.Req_Callertye, CommonUtil.Priority)

        if (CommonUtil.urlFromS3!!.contains(".pdf")) {
            jsonObject.addProperty(ApiRequestNames.Req_filetype, "3")
        } else if (CommonUtil.urlFromS3!!.contains(".jpg")) {
            jsonObject.addProperty(ApiRequestNames.Req_filetype, "2")
        }
        jsonObject.addProperty(ApiRequestNames.Req_isStudent, isStudent)
        jsonObject.addProperty(ApiRequestNames.Req_isStaff, isStaff)
        jsonObject.addProperty(ApiRequestNames.Req_isParent, isParent)
        jsonObject.addProperty(ApiRequestNames.Req_fileduraction, "0")
        jsonObject.addProperty(ApiRequestNames.Req_title, CommonUtil.MenuTitle)
        jsonObject.addProperty(ApiRequestNames.Req_description, CommonUtil.MenuDescription)

        val FileNameArray = JsonArray()
        val FileNameobject = JsonObject()
        FileNameobject.addProperty("FileName", Awsaupladedfilepath)
        FileNameArray.add(FileNameobject)

        jsonObject.add("FileNameArray", FileNameArray)

        appViewModel!!.ImageorPdf(jsonObject, this)
        Log.d("SMSJsonObject", jsonObject.toString())
    }

    private fun ImageOrPdfsendparticuler() {

        val jsonObject = JsonObject()
        jsonObject.addProperty("collegeid", CommonUtil.CollegeId)
        jsonObject.addProperty(ApiRequestNames.Req_staffid, CommonUtil.MemberId)
        jsonObject.addProperty(ApiRequestNames.Req_Callertye, CommonUtil.Priority)

        if (CommonUtil.urlFromS3!!.contains(".pdf")) {
            jsonObject.addProperty(ApiRequestNames.Req_filetype, "3")
        } else if (CommonUtil.urlFromS3!!.contains(".jpg")) {
            jsonObject.addProperty(ApiRequestNames.Req_filetype, "2")
        }

        jsonObject.addProperty(ApiRequestNames.Req_isStudent, isStudent)
        jsonObject.addProperty(ApiRequestNames.Req_isStaff, isStaff)
        jsonObject.addProperty(ApiRequestNames.Req_isParent, isParent)

        jsonObject.addProperty(ApiRequestNames.Req_fileduraction, "0")
        jsonObject.addProperty(ApiRequestNames.Req_title, CommonUtil.MenuTitle)
        jsonObject.addProperty(ApiRequestNames.Req_description, CommonUtil.MenuDescription)

        jsonObject.addProperty("receiverid", CommonUtil.receiverid)
        jsonObject.addProperty(ApiRequestNames.Req_receivertype, CommonUtil.receivertype)


        val FileNameArray = JsonArray()
        val FileNameobject = JsonObject()
        FileNameobject.addProperty("FileName", Awsaupladedfilepath)
        FileNameArray.add(FileNameobject)

        jsonObject.add("FileNameArray", FileNameArray)

        appViewModel!!.ImageorPdfparticuler(jsonObject, this)
        Log.d("SMSJsonObject", jsonObject.toString())
    }

    private fun AssignmentsendEntireSection() {

        val jsonObject = JsonObject()

        jsonObject.addProperty("collegeid", CommonUtil.CollegeId)
        jsonObject.addProperty("deptid", "16")
        jsonObject.addProperty("courseid", CommonUtil.Courseid)
        jsonObject.addProperty("yearid", CommonUtil.YearId)
        jsonObject.addProperty("staffid", CommonUtil.MemberId)
        jsonObject.addProperty("callertype", CommonUtil.Priority)
        jsonObject.addProperty("sectionid", CommonUtil.SectionId)
        jsonObject.addProperty("subjectid", "144")
        jsonObject.addProperty("assignmenttopic", CommonUtil.title)
        jsonObject.addProperty("assignmentdescription", CommonUtil.Description)
        jsonObject.addProperty("submissiondate", CommonUtil.startdate)
        jsonObject.addProperty("processtype", "add")
        jsonObject.addProperty("assignmentid", "0")

        if (txt_selectsubortutor!!.getVisibility() == View.VISIBLE && lbl_select_student!!.getVisibility() == View.GONE) {
            jsonObject.addProperty(ApiRequestNames.Req_receivertype, "1")
            jsonObject.addProperty("receiverid", CommonUtil.SectionId)

        } else if (txt_selectsubortutor!!.getVisibility() == View.GONE && lbl_select_student!!.getVisibility() == View.VISIBLE) {
            jsonObject.addProperty(ApiRequestNames.Req_receivertype, "2")
            jsonObject.addProperty("receiverid", CommonUtil.receiverid)

        }

        if (FileType.equals("IMAGE")) {

            jsonObject.addProperty("assignmenttype", "image")
            val FileNameArray = JsonArray()
            val FileNameobject = JsonObject()
            FileNameobject.addProperty("FileName", Awsaupladedfilepath)
            FileNameArray.add(FileNameobject)
            jsonObject.add("FileNameArray", FileNameArray)

        } else if (FileType.equals("PDF")) {
            jsonObject.addProperty("assignmenttype", "pdf")

            val FileNameArray = JsonArray()
            val FileNameobject = JsonObject()

            FileNameobject.addProperty("FileName", Awsaupladedfilepath)
            FileNameArray.add(FileNameobject)
            jsonObject.add("FileNameArray", FileNameArray)

        } else if (FileType.equals("VIDEO")) {


            jsonObject.addProperty("assignmenttype", "video")

            val FileNameArray = JsonArray()
            val FileNameobject = JsonObject()

            FileNameobject.addProperty("FileName", CommonUtil.VimeoIframe)
            Log.d("Videoiframe", CommonUtil.VimeoIframe.toString())

            FileNameArray.add(FileNameobject)
            jsonObject.add("FileNameArray", FileNameArray)

        } else if (FileType.equals("TEXT")) {

            jsonObject.addProperty("assignmenttype", "text")

            val FileNameArray = JsonArray()
            val FileNameobject = JsonObject()

            FileNameobject.addProperty("FileName", "")
            FileNameArray.add(FileNameobject)
            jsonObject.add("FileNameArray", FileNameArray)
        }

        appViewModel!!.Assignmentsend(jsonObject, this)
        Log.d("SMSJsonObject", jsonObject.toString())
    }

    private fun Assignmentforward() {

        val jsonObject = JsonObject()
        jsonObject.addProperty("collegeid", CommonUtil.CollegeId)
        jsonObject.addProperty("staffid", CommonUtil.MemberId)
        jsonObject.addProperty("callertype", CommonUtil.Priority)
        jsonObject.addProperty("sectionid", CommonUtil.SectionId)
        jsonObject.addProperty("subjectid", "144")
        jsonObject.addProperty("processtype", "add")
        jsonObject.addProperty("assignmentid", CommonUtil.Assignmentid)
        jsonObject.addProperty(ApiRequestNames.Req_receviedit, CommonUtil.receiverid)
        jsonObject.addProperty(ApiRequestNames.Req_receivertype, CommonUtil.receivertype)


        appViewModel!!.Assignmentfor(jsonObject, this)
        Log.d("SMSJsonObject", jsonObject.toString())
    }

    private fun VideosendEntire() {

        val jsonObject = JsonObject()
        jsonObject.addProperty(ApiRequestNames.Req_collegeid, CommonUtil.CollegeId)
        jsonObject.addProperty(ApiRequestNames.Req_staffid, CommonUtil.MemberId)
        jsonObject.addProperty(ApiRequestNames.Req_Callertye, CommonUtil.Priority)
        jsonObject.addProperty(ApiRequestNames.Req_title, CommonUtil.title)
        jsonObject.addProperty(ApiRequestNames.Req_Description, CommonUtil.Description)
        jsonObject.addProperty(ApiRequestNames.Req_isStudent, isStudent)
        jsonObject.addProperty(ApiRequestNames.Req_isStaff, isStaff)
        jsonObject.addProperty(ApiRequestNames.Req_isParent, isParent)
        jsonObject.addProperty("filename", "video")
        jsonObject.addProperty("iframe", CommonUtil.VimeoIframe)
        Log.d("Videoiframe", CommonUtil.VimeoIframe.toString())
        jsonObject.addProperty("url", CommonUtil.VimeoVideoUrl)

        appViewModel!!.VideoEntireSend(jsonObject, this)
        Log.d("SMSJsonObject", jsonObject.toString())
    }

    private fun VideosendParticuler() {


        val jsonObject = JsonObject()
        jsonObject.addProperty(ApiRequestNames.Req_collegeid, CommonUtil.CollegeId)
        jsonObject.addProperty(ApiRequestNames.Req_staffid, CommonUtil.MemberId)
        jsonObject.addProperty(ApiRequestNames.Req_Callertye, CommonUtil.Priority)
        jsonObject.addProperty(ApiRequestNames.Req_title, CommonUtil.title)
        jsonObject.addProperty(ApiRequestNames.Req_Description, CommonUtil.Description)
        jsonObject.addProperty(ApiRequestNames.Req_isStudent, isStudent)
        jsonObject.addProperty(ApiRequestNames.Req_isStaff, isStaff)
        jsonObject.addProperty(ApiRequestNames.Req_isParent, isParent)
        jsonObject.addProperty("iframe", CommonUtil.VimeoIframe)
        jsonObject.addProperty("url", CommonUtil.VimeoVideoUrl)
        jsonObject.addProperty(ApiRequestNames.Req_receivertype, CommonUtil.receivertype)
        jsonObject.addProperty(ApiRequestNames.Req_receviedit, CommonUtil.receiverid)
        appViewModel!!.VideoParticulerSend(jsonObject, this)
        Log.d("SMSJsonObject", jsonObject.toString())

    }

    private fun Attendancemarking() {
        val jsonObject = JsonObject()
        jsonObject.addProperty(ApiRequestNames.Req_colgid, CommonUtil.CollegeId)
        jsonObject.addProperty(ApiRequestNames.Req_staffid, CommonUtil.MemberId)
        jsonObject.addProperty(ApiRequestNames.Req_Callertye, CommonUtil.Priority)
        jsonObject.addProperty(ApiRequestNames.Req_receivertype, recivertype)
        jsonObject.addProperty(ApiRequestNames.Req_isStudent, isStudent)
        jsonObject.addProperty(ApiRequestNames.Req_isStaff, isStaff)
        jsonObject.addProperty(ApiRequestNames.Req_isParent, isParent)
        jsonObject.addProperty(ApiRequestNames.Req_fileduraction, "0")
        jsonObject.addProperty(ApiRequestNames.Req_topic, CommonUtil.MenuTitle)
        jsonObject.addProperty(ApiRequestNames.Req_Description, CommonUtil.MenuDescription)
        jsonObject.addProperty(ApiRequestNames.Req_FileNameArray, CommonUtil.receiverid)
        jsonObject.addProperty(ApiRequestNames.Req_processtype, "add")

        appViewModel!!.AttendanceTakedata(jsonObject, this)
        Log.d("SMSJsonObject", jsonObject.toString())
    }

//--------CLICK THE PARTICULER DATA

    @OnClick(R.id.lblDivision)
    fun divisionClick() {

        if (CommonUtil.Priority.equals("p1")) {

            lnrStaff!!.visibility = View.VISIBLE
            CommonUtil.receivertype = "8"
            chboxEntire!!.isChecked = false
            spinnerDropdowncourse!!.visibility = View.GONE
            spinnerDropdown!!.visibility = View.GONE
            recycleRecipientscourse!!.visibility = View.GONE
            txt_division!!.visibility = View.GONE
            GetDivisionRequest()

        } else if (CommonUtil.Priority.equals("p2")) {
            CommonUtil.receivertype = "2"
            recycleyearandsection!!.visibility = View.GONE
            NestedScrollView!!.visibility = View.VISIBLE
            chboxEntire!!.isChecked = false
            spinnerDropdowncourse!!.visibility = View.GONE
            spinnerDropdown!!.visibility = View.GONE
            recycleRecipients!!.visibility = View.VISIBLE
            recycleRecipientscourse!!.visibility = View.VISIBLE
            txt_division!!.visibility = View.GONE
            getcoursedepartment()
        }

        lblDivision!!.setBackgroundResource(R.drawable.bg_available_selected_green)
        lblDivision!!.setTextColor(Color.parseColor(getString(R.string.lbl_clr_white)))

        lblDepartment!!.setBackgroundResource(R.drawable.bg_available_outline_red)
        lblDepartment!!.setTextColor(Color.parseColor(getString(R.string.lbl_clr_red)))

        lblCourse!!.setBackgroundResource(R.drawable.bg_available_outline_red)
        lblCourse!!.setTextColor(Color.parseColor(getString(R.string.lbl_clr_red)))

        lblYourClasses!!.setBackgroundResource(R.drawable.bg_available_outline_red)
        lblYourClasses!!.setTextColor(Color.parseColor(getString(R.string.lbl_clr_red)))

        lblGroups!!.setBackgroundResource(R.drawable.bg_available_outline_red)
        lblGroups!!.setTextColor(Color.parseColor(getString(R.string.lbl_clr_red)))

        SelecteRecipientType = lblDivision!!.text.toString()
        lblSelectedRecipient?.text = SelecteRecipientType!!

    }

    @OnClick(R.id.lblDepartment)
    fun departmentClick() {

        if (CommonUtil.Priority.equals("p1")) {
            lnrStaff!!.visibility = View.VISIBLE

            CommonUtil.receivertype = "3"
            recycleRecipients!!.visibility = View.VISIBLE
            recycleRecipientscourse!!.visibility = View.GONE
            spinnerDropdowncourse!!.visibility = View.GONE
            chboxEntire!!.isChecked = false
            spinnerDropdown!!.visibility = View.VISIBLE
            txt_division!!.visibility = View.VISIBLE
            GetDivisionRequest()
        } else if (CommonUtil.Priority.equals("p2")) {
            CommonUtil.receivertype = "5"

            recycleyearandsection!!.visibility = View.VISIBLE
            recycleRecipientscourse!!.visibility = View.GONE
            recycleRecipients!!.visibility = View.GONE
            chboxEntire!!.isChecked = false
            spinnerDropdowncourse!!.visibility = View.VISIBLE
            spinnerDropdown!!.visibility = View.VISIBLE
            txt_division!!.visibility = View.GONE
            getcoursedepartment()
        }

        lblDivision!!.setBackgroundResource(R.drawable.bg_available_outline_red)
        lblDivision!!.setTextColor(Color.parseColor(getString(R.string.lbl_clr_red)))

        lblDepartment!!.setBackgroundResource(R.drawable.bg_available_selected_green)
        lblDepartment!!.setTextColor(Color.parseColor(getString(R.string.lbl_clr_white)))

        lblCourse!!.setBackgroundResource(R.drawable.bg_available_outline_red)
        lblCourse!!.setTextColor(Color.parseColor(getString(R.string.lbl_clr_red)))

        lblYourClasses!!.setBackgroundResource(R.drawable.bg_available_outline_red)
        lblYourClasses!!.setTextColor(Color.parseColor(getString(R.string.lbl_clr_red)))

        lblGroups!!.setBackgroundResource(R.drawable.bg_available_outline_red)
        lblGroups!!.setTextColor(Color.parseColor(getString(R.string.lbl_clr_red)))

        SelecteRecipientType = lblDepartment!!.text.toString()
        Log.d("SeleteRecipienttype", SelecteRecipientType.toString())
        lblSelectedRecipient?.text = SelecteRecipientType!!

    }

    @OnClick(R.id.lblCourse)
    fun CourseClick() {


        lnrStaff!!.visibility = View.GONE

        CommonUtil.receivertype = "2"
        recycleRecipients!!.visibility = View.GONE
        chboxEntire!!.isChecked = false
        spinnerDropdown!!.visibility = View.VISIBLE
        spinnerDropdowncourse!!.visibility = View.VISIBLE
        recycleRecipientscourse!!.visibility = View.VISIBLE
        txt_division!!.visibility = View.VISIBLE
        GetDivisionRequest()

        lblDivision!!.setBackgroundResource(R.drawable.bg_available_outline_red)
        lblDivision!!.setTextColor(Color.parseColor(getString(R.string.lbl_clr_red)))

        lblDepartment!!.setBackgroundResource(R.drawable.bg_available_outline_red)
        lblDepartment!!.setTextColor(Color.parseColor(getString(R.string.lbl_clr_red)))

        lblCourse!!.setBackgroundResource(R.drawable.bg_available_selected_green)
        lblCourse!!.setTextColor(Color.parseColor(getString(R.string.lbl_clr_white)))

        lblYourClasses!!.setBackgroundResource(R.drawable.bg_available_outline_red)
        lblYourClasses!!.setTextColor(Color.parseColor(getString(R.string.lbl_clr_red)))

        lblGroups!!.setBackgroundResource(R.drawable.bg_available_outline_red)
        lblGroups!!.setTextColor(Color.parseColor(getString(R.string.lbl_clr_red)))

        SelecteRecipientType = lblCourse!!.text.toString()
        Log.d("SeleteRecipienttype", SelecteRecipientType.toString())
        lblSelectedRecipient?.text = SelecteRecipientType!!

    }

    @OnClick(R.id.lblYourClasses)
    fun YourClassesClick() {
        CommonUtil.receivertype = "5"
        lnrStaff!!.visibility = View.GONE


//        if (CommonUtil.Priority.equals("p3")) {
//            GetSubjectstaff()
//        } else if (CommonUtil.Priority.equals("p2")) {
//            GetSubjecthod()
//        } else if (CommonUtil.Priority.equals("p1")) {
//            GetSubjectprinciple()
//        }

        recycleRecipients!!.visibility = View.GONE
        spinnerDropdown!!.visibility = View.GONE
        spinnerDropdowncourse!!.visibility = View.GONE
        recycleRecipientscourse!!.visibility = View.GONE
        txt_division!!.visibility = View.GONE

        SelecteRecipientType = lblYourClasses!!.text.toString()
        Log.d("Selectedtype", SelecteRecipientType.toString())
        lblSelectedRecipient?.text = SelecteRecipientType!!
        chboxEntire!!.isChecked = false


        layoutEntireCollege!!.visibility = View.GONE
        LayoutRecipient!!.visibility = View.GONE
        Viewlineone!!.visibility = View.GONE
        NestedScrollView!!.visibility = View.GONE

        txt_selectsubortutor!!.visibility = View.VISIBLE
        Viewlinetwo!!.visibility = View.VISIBLE
        edt_selectiontuterorsubject!!.visibility = View.VISIBLE
        recycle_Staffrecipients!!.visibility = View.VISIBLE
        txt_selectspecfic!!.visibility = View.VISIBLE

        //  layoutEntireDepartment!!.visibility = View.GONE
        txt_department!!.visibility = View.GONE
        Viewlinethree!!.visibility = View.GONE
        txt_mydepartment!!.visibility = View.GONE
        txt_myclass!!.visibility = View.GONE

        lblDivision!!.setBackgroundResource(R.drawable.bg_available_outline_red)
        lblDivision!!.setTextColor(Color.parseColor(getString(R.string.lbl_clr_red)))

        lblDepartment!!.setBackgroundResource(R.drawable.bg_available_outline_red)
        lblDepartment!!.setTextColor(Color.parseColor(getString(R.string.lbl_clr_red)))

        lblCourse!!.setBackgroundResource(R.drawable.bg_available_outline_red)
        lblCourse!!.setTextColor(Color.parseColor(getString(R.string.lbl_clr_red)))

        lblYourClasses!!.setBackgroundResource(R.drawable.bg_available_selected_green)
        lblYourClasses!!.setTextColor(Color.parseColor(getString(R.string.lbl_clr_white)))

        lblGroups!!.setBackgroundResource(R.drawable.bg_available_outline_red)
        lblGroups!!.setTextColor(Color.parseColor(getString(R.string.lbl_clr_red)))

    }

    @OnClick(R.id.lblGroups)
    fun GroupsClick() {


        lnrStaff!!.visibility = View.GONE
        GetGroup()
        CommonUtil.receivertype = "6"
        recycleRecipients!!.visibility = View.VISIBLE
        spinnerDropdown!!.visibility = View.GONE
        spinnerDropdowncourse!!.visibility = View.GONE
        recycleRecipientscourse!!.visibility = View.GONE
        txt_division!!.visibility = View.GONE

        SelecteRecipientType = lblGroups!!.text.toString()
        lblSelectedRecipient?.text = SelecteRecipientType!!
        chboxEntire!!.isChecked = false
        spinnerDropdown!!.visibility = View.GONE

        lblDivision!!.setBackgroundResource(R.drawable.bg_available_outline_red)
        lblDivision!!.setTextColor(Color.parseColor(getString(R.string.lbl_clr_red)))

        lblDepartment!!.setBackgroundResource(R.drawable.bg_available_outline_red)
        lblDepartment!!.setTextColor(Color.parseColor(getString(R.string.lbl_clr_red)))

        lblCourse!!.setBackgroundResource(R.drawable.bg_available_outline_red)
        lblCourse!!.setTextColor(Color.parseColor(getString(R.string.lbl_clr_red)))

        lblYourClasses!!.setBackgroundResource(R.drawable.bg_available_outline_red)
        lblYourClasses!!.setTextColor(Color.parseColor(getString(R.string.lbl_clr_red)))

        lblGroups!!.setBackgroundResource(R.drawable.bg_available_selected_green)
        lblGroups!!.setTextColor(Color.parseColor(getString(R.string.lbl_clr_white)))

    }


    // AWS UPLOAD FUNCTION
    fun awsFileUpload(activity: Activity?, pathind: Int?) {

        Log.d("SelcetedFileList", CommonUtil.SelcetedFileList.size.toString())
        val s3uploaderObj: S3Uploader
        s3uploaderObj = S3Uploader(activity)
        pathIndex = pathind!!

        for (index in pathIndex until CommonUtil.SelcetedFileList.size) {
            uploadFilePath = CommonUtil.SelcetedFileList.get(index)
            Log.d("uploadFilePath", uploadFilePath.toString())
            var extension = uploadFilePath!!.substring(uploadFilePath!!.lastIndexOf("."))
            if (extension.equals(".pdf")) {
                contentType = ".pdf"
            } else {
                contentType = ".jpg"
            }
            break
        }

        if (AWSUploadedFilesList.size < CommonUtil.SelcetedFileList.size) {
            Log.d("test", uploadFilePath!!)
            if (uploadFilePath != null) {
                progressDialog = CustomLoading.createProgressDialog(this)

                progressDialog!!.show()
                fileNameDateTime =
                    SimpleDateFormat("yyyyMMddHHmmss").format(Calendar.getInstance().getTime())
                fileNameDateTime = "File_" + fileNameDateTime
                Log.d("filenamedatetime", fileNameDateTime.toString())
                s3uploaderObj.initUpload(
                    uploadFilePath, contentType, CommonUtil.CollegeId.toString(), fileNameDateTime
                )

                s3uploaderObj.setOns3UploadDone(object : S3Uploader.S3UploadInterface {
                    override fun onUploadSuccess(response: String?) {
                        if (response!!.equals("Success")) {

                            CommonUtil.urlFromS3 = S3Utils.generates3ShareUrl(
                                this@AddRecipients,
                                CommonUtil.CollegeId.toString(),
                                uploadFilePath,
                                fileNameDateTime
                            )

                            Log.d("urifroms3", CommonUtil.urlFromS3.toString())

                            if (!TextUtils.isEmpty(CommonUtil.urlFromS3)) {


                                Awsuploadedfile.add(CommonUtil.urlFromS3.toString())
                                Awsaupladedfilepath = Awsuploadedfile.joinToString(separator)


                                fileName = File(uploadFilePath)

                                filename = fileName!!.name
                                AWSUploadedFilesList.add(
                                    AWSUploadedFiles(
                                        CommonUtil.urlFromS3!!, filename, contentType
                                    )
                                )

                                Log.d("AWSUploadedFilesList", AWSUploadedFilesList.toString())
                                awsFileUpload(activity, pathIndex + 1)

                                if (CommonUtil.SelcetedFileList.size == AWSUploadedFilesList.size) {
                                    progressDialog!!.dismiss()
                                }
                            }
                        }
                    }

                    override fun onUploadError(response: String?) {
                        progressDialog!!.dismiss()
                        Log.d("error", "Error Uploading")
                    }
                })
            }

        } else {

            if (ScreenName.equals("New Image/Pdf")) {
                if (chboxEntire!!.isChecked) {

                    if ((chboxParents!!.isChecked) || (chboxStaff!!.isChecked) || (chboxStudent!!.isChecked) || (chboxParents!!.isChecked && chboxStaff!!.isChecked) || (chboxStudent!!.isChecked && chboxParents!!.isChecked) || (chboxStudent!!.isChecked && chboxStaff!!.isChecked) || (chboxParents!!.isChecked && chboxStaff!!.isChecked && chboxStudent!!.isChecked)) {
                        lblSelectedRecipient!!.setText("")
                        SelectedRecipientlist.clear()
                        ImageOrPdfsendentire()
                    }
                } else {
                    if ((chboxParents!!.isChecked) || (chboxStaff!!.isChecked) || (chboxStudent!!.isChecked) || (chboxParents!!.isChecked && chboxStaff!!.isChecked) || (chboxStudent!!.isChecked && chboxParents!!.isChecked) || (chboxStudent!!.isChecked && chboxStaff!!.isChecked) || (chboxParents!!.isChecked && chboxStaff!!.isChecked && chboxStudent!!.isChecked)) {
                        lblSelectedRecipient!!.setText("")
                        SelectedRecipientlist.clear()
                        ImageOrPdfsendparticuler()
                    }
                }
            } else if (ScreenName.equals("New Assignment")) {
                AssignmentsendEntireSection()
            }
        }
    }

    private fun VoiceSendEntire() {
        val mProgressDialog = ProgressDialog(this)
        mProgressDialog.isIndeterminate = true
        mProgressDialog.setMessage("Loading...")
        mProgressDialog.setCancelable(false)
        mProgressDialog.show()


        val jsonObject = JsonObject()
        jsonObject.addProperty("collegeid", "1")
        jsonObject.addProperty("staffid", CommonUtil.MemberId)
        jsonObject.addProperty("callertype", CommonUtil.Priority)
        jsonObject.addProperty("filetype", "1")
        jsonObject.addProperty("fileduration", CommonUtil.VoiceDuration)
        jsonObject.addProperty("isparent", isParent)
        jsonObject.addProperty("isstudent", isStudent)
        jsonObject.addProperty("isstaff", isStaff)
        jsonObject.addProperty("description", CommonUtil.voicetitle)
        jsonObject.addProperty("isemergencyvoice", CommonUtil.VoiceType)

        Log.d("VoiceSend:req", jsonObject.toString())

        val file: File = File(CommonUtil.futureStudioIconFile!!.getPath())
        Log.d("FILE_Path", CommonUtil.futureStudioIconFile!!.getPath())

        val requestFile: RequestBody =
            RequestBody.create("multipart/form-data".toMediaTypeOrNull(), file)
        val bodyFile: MultipartBody.Part = createFormData("voice", file.name, requestFile)
        val requestBody: RequestBody = RequestBody.create(MultipartBody.FORM, jsonObject.toString())

        RestClient.apiInterfaces.UploadVoicefileEntire(requestBody, bodyFile)
            .enqueue(object : Callback<JsonObject> {

                override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                    try {
                        if (mProgressDialog.isShowing) mProgressDialog.dismiss()
                        run {
                            Log.d(
                                "voicesend:code-res",
                                response.code().toString() + " - " + response.toString()
                            )

                            if (response.code() == 200 || response.code() == 201) {

                                val js = JSONObject(response.body().toString())

                                var status: String? = null
                                status = js.getString("Status")

                                if (status.equals("1")) {
                                    var message: String? = null
                                    message = js.getString("Message")

                                    val dlg = this@AddRecipients.let { AlertDialog.Builder(it) }
                                    dlg.setTitle("Info")
                                    dlg.setMessage(message)
                                    dlg.setPositiveButton(
                                        "OK",
                                        DialogInterface.OnClickListener { dialog, which ->
                                            val i: Intent =

                                                Intent(
                                                    this@AddRecipients, Communication::class.java
                                                )
                                            i.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                                            startActivity(i)
                                        })

                                    dlg.setCancelable(false)
                                    dlg.create()
                                    dlg.show()

                                } else {
                                    var message: String? = null
                                    message = js.getString("Message")

                                    val dlg = this@AddRecipients.let { AlertDialog.Builder(it) }
                                    dlg.setTitle("Info")
                                    dlg.setMessage(message)
                                    dlg.setPositiveButton(
                                        "OK",
                                        DialogInterface.OnClickListener { dialog, which ->
                                            val i: Intent =

                                                Intent(
                                                    this@AddRecipients, Communication::class.java
                                                )
                                            i.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                                            startActivity(i)
                                        })

                                    dlg.setCancelable(false)
                                    dlg.create()
                                    dlg.show()

                                }
                            }
                        }
                    } catch (e: java.lang.Exception) {
                        Log.e("Response Exception", e.message!!)
                    }
                }

                override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                    mProgressDialog.dismiss()
                }
            })
    }


    private fun VoiceSendParticuler() {
        val mProgressDialog = ProgressDialog(this)
        mProgressDialog.isIndeterminate = true
        mProgressDialog.setMessage("Loading...")
        mProgressDialog.setCancelable(false)
        mProgressDialog.show()

        val jsonObject = JsonObject()
        jsonObject.addProperty("collegeid", "1")
        jsonObject.addProperty("staffid", CommonUtil.MemberId)
        jsonObject.addProperty("callertype", CommonUtil.Priority)
        jsonObject.addProperty("filetype", "1")
        jsonObject.addProperty("fileduration", CommonUtil.VoiceDuration)
        jsonObject.addProperty("isparent", isParent)
        jsonObject.addProperty("isstudent", isStudent)
        jsonObject.addProperty("isstaff", isStaff)
        jsonObject.addProperty("description", CommonUtil.voicetitle)
        jsonObject.addProperty(ApiRequestNames.Req_receivertype, CommonUtil.receivertype)
        jsonObject.addProperty(ApiRequestNames.Req_receviedit, CommonUtil.receiverid)
        jsonObject.addProperty("isemergencyvoice", CommonUtil.VoiceType)

        Log.d("VoiceSend:req", jsonObject.toString())

        val file: File = File(CommonUtil.futureStudioIconFile!!.getPath())
        Log.d("FILE_Path", CommonUtil.futureStudioIconFile!!.getPath())

        val requestFile: RequestBody =
            RequestBody.create("multipart/form-data".toMediaTypeOrNull(), file)
        val bodyFile: MultipartBody.Part = createFormData("voice", file.name, requestFile)
        val requestBody: RequestBody = RequestBody.create(MultipartBody.FORM, jsonObject.toString())

        RestClient.apiInterfaces.UploadVoicefileParticuler(requestBody, bodyFile)
            .enqueue(object : Callback<JsonObject> {

                override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                    try {
                        if (mProgressDialog.isShowing) mProgressDialog.dismiss()
                        run {
                            Log.d(
                                "voicesend:code-res",
                                response.code().toString() + " - " + response.toString()
                            )

                            if (response.code() == 200 || response.code() == 201) {

                                val js = JSONObject(response.body().toString())

                                var status: String? = null
                                status = js.getString("Status")

                                if (status.equals("1")) {
                                    var message: String? = null
                                    message = js.getString("Message")

                                    val dlg = this@AddRecipients.let { AlertDialog.Builder(it) }
                                    dlg.setTitle("Info")
                                    dlg.setMessage(message)
                                    dlg.setPositiveButton(
                                        "OK",
                                        DialogInterface.OnClickListener { dialog, which ->
                                            val i: Intent =

                                                Intent(
                                                    this@AddRecipients, Communication::class.java
                                                )
                                            i.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                                            startActivity(i)
                                        })

                                    dlg.setCancelable(false)
                                    dlg.create()
                                    dlg.show()

                                } else {
                                    var message: String? = null
                                    message = js.getString("Message")

                                    val dlg = this@AddRecipients.let { AlertDialog.Builder(it) }
                                    dlg.setTitle("Info")
                                    dlg.setMessage(message)
                                    dlg.setPositiveButton(
                                        "OK",
                                        DialogInterface.OnClickListener { dialog, which ->
                                            val i: Intent =

                                                Intent(
                                                    this@AddRecipients, Communication::class.java
                                                )
                                            i.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                                            startActivity(i)
                                        })

                                    dlg.setCancelable(false)
                                    dlg.create()
                                    dlg.show()

                                }
                            }
                        }
                    } catch (e: java.lang.Exception) {
                        Log.e("Response Exception", e.message!!)
                    }
                }

                override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                    mProgressDialog.dismiss()
                }
            })
    }


    private fun VoiceSendTuter() {
        val mProgressDialog = ProgressDialog(this)
        mProgressDialog.isIndeterminate = true
        mProgressDialog.setMessage("Loading...")
        mProgressDialog.setCancelable(false)
        mProgressDialog.show()


        val jsonObject = JsonObject()
        jsonObject.addProperty("collegeid", "1")
        jsonObject.addProperty("staffid", CommonUtil.MemberId)
        jsonObject.addProperty("callertype", CommonUtil.Priority)
        jsonObject.addProperty("filetype", "1")
        jsonObject.addProperty("fileduration", CommonUtil.VoiceDuration)
        jsonObject.addProperty("isparent", isParent)
        jsonObject.addProperty("isstudent", isStudent)
        jsonObject.addProperty("isstaff", isStaff)
        jsonObject.addProperty("description", CommonUtil.voicetitle)
        jsonObject.addProperty(ApiRequestNames.Req_receivertype, CommonUtil.receivertype)
        jsonObject.addProperty(ApiRequestNames.Req_receviedit, CommonUtil.receiverid)
        jsonObject.addProperty("isemergencyvoice", CommonUtil.VoiceType)

        Log.d("VoiceSend:req", jsonObject.toString())

        val file: File = File(CommonUtil.futureStudioIconFile!!.getPath())
        Log.d("FILE_Path", CommonUtil.futureStudioIconFile!!.getPath())

        val requestFile: RequestBody =
            RequestBody.create("multipart/form-data".toMediaTypeOrNull(), file)
        val bodyFile: MultipartBody.Part = createFormData("voice", file.name, requestFile)
        val requestBody: RequestBody = RequestBody.create(MultipartBody.FORM, jsonObject.toString())

        RestClient.apiInterfaces.UploadVoicefileTuterSend(requestBody, bodyFile)
            .enqueue(object : Callback<JsonObject> {

                override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                    try {
                        if (mProgressDialog.isShowing) mProgressDialog.dismiss()
                        run {
                            Log.d(
                                "voicesend:code-res",
                                response.code().toString() + " - " + response.toString()
                            )

                            if (response.code() == 200 || response.code() == 201) {

                                val js = JSONObject(response.body().toString())

                                var status: String? = null
                                status = js.getString("Status")

                                if (status.equals("1")) {
                                    var message: String? = null
                                    message = js.getString("Message")

                                    val dlg = this@AddRecipients.let { AlertDialog.Builder(it) }
                                    dlg.setTitle("Info")
                                    dlg.setMessage(message)
                                    dlg.setPositiveButton(
                                        "OK",
                                        DialogInterface.OnClickListener { dialog, which ->
                                            val i: Intent =

                                                Intent(
                                                    this@AddRecipients, Communication::class.java
                                                )
                                            i.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                                            startActivity(i)
                                        })

                                    dlg.setCancelable(false)
                                    dlg.create()
                                    dlg.show()

                                } else {
                                    var message: String? = null
                                    message = js.getString("Message")

                                    val dlg = this@AddRecipients.let { AlertDialog.Builder(it) }
                                    dlg.setTitle("Info")
                                    dlg.setMessage(message)
                                    dlg.setPositiveButton(
                                        "OK",
                                        DialogInterface.OnClickListener { dialog, which ->
                                            val i: Intent =

                                                Intent(
                                                    this@AddRecipients, Communication::class.java
                                                )
                                            i.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                                            startActivity(i)
                                        })

                                    dlg.setCancelable(false)
                                    dlg.create()
                                    dlg.show()

                                }
                            }
                        }
                    } catch (e: java.lang.Exception) {
                        Log.e("Response Exception", e.message!!)
                    }
                }

                override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                    mProgressDialog.dismiss()
                }
            })
    }
}


