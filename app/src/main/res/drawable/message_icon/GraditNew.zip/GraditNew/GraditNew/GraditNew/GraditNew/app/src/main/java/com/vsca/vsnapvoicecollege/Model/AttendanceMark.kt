package com.vsca.vsnapvoicecollege.Model

data class AttendanceMark(
    val Message: String,
    val Status: Int
)