package com.vsca.vsnapvoicecollege.Model

data class AttendancemardkingResponse(
    val Message: String,
    val Status: Int
)