package com.vsca.vsnapvoicecollege.VideoAlbum;
public class AlbumVideo {

    public String name;
    public String cover;
    public String count;

    public AlbumVideo(String name, String cover, String count) {
        this.name = name;
        this.cover = cover;
        this.count=count;
    }
}
