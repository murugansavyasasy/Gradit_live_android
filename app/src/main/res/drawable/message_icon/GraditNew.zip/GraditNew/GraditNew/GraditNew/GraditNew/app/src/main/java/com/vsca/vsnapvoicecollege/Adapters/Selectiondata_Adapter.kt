package com.vsca.vsnapvoicecollege.Adapters

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.CompoundButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import butterknife.BindView
import butterknife.ButterKnife
import com.vsca.vsnapvoicecollege.Interfaces.RecipientCheckListener
import com.vsca.vsnapvoicecollege.Interfaces.RecipientCheckListenerint
import com.vsca.vsnapvoicecollege.Model.Sectiondetail
import com.vsca.vsnapvoicecollege.R
import com.vsca.vsnapvoicecollege.Utils.CommonUtil
import com.vsca.vsnapvoicecollege.Utils.CommonUtil.seleteddataArray

class Selectiondata_Adapter(
    data: ArrayList<Sectiondetail>
) :
    RecyclerView.Adapter<Selectiondata_Adapter.MyViewHolder>() {
    var loginlist: List<Sectiondetail> = ArrayList()
    var seletedStringdata: String? = null
    var SeletedStringdataReplace: String? = null


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView: View = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.child_item, parent, false)
        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val data: Sectiondetail = loginlist.get(position)

        holder.section!!.setText(data.sectionname)

        holder.chboxsection!!.setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener { buttonView, isChecked ->

            if (isChecked) {
                Log.d("checked", "checked");
                seleteddataArray.add(data.sectionid.toString())
                holder.chboxsection!!.isChecked = true
            } else {
                Log.d("checked", "un_checked");
                seleteddataArray.remove(data.sectionid.toString())
                holder.chboxsection!!.isChecked = false
            }

            Log.d("seleteddata_size", seleteddataArray.size.toString())

            for (i in seleteddataArray) {
                seletedStringdata = seleteddataArray.joinToString("~")
                Log.d("seletedStringdata", seletedStringdata.toString());
            }


            if (seleteddataArray.size > 0) {
                CommonUtil.receiverid = seletedStringdata.toString()
            } else {
                CommonUtil.receiverid = ""
            }
        })
    }


    override fun getItemCount(): Int {
        return loginlist.size
    }

    inner class MyViewHolder constructor(itemView: View?) : RecyclerView.ViewHolder(
        (itemView)!!
    ) {

        @JvmField
        @BindView(R.id.section)
        var section: TextView? = null

        @JvmField
        @BindView(R.id.chboxsection)
        var chboxsection: CheckBox? = null


        init {
            ButterKnife.bind(this, (itemView)!!)
        }
    }

    init {
        loginlist = data
    }
}