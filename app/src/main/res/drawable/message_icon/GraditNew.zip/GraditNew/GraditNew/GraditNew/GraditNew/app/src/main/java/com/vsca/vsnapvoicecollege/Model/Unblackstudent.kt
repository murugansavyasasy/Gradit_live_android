package com.vsca.vsnapvoicecollege.Model

data class Unblackstudent(
    val idstaff: String,
    val idstudent: String
)