package com.vsca.vsnapvoicecollege.Model

data class DataXXXX(
    val applicationid: String,
    val coursename: String,
    val createdon: String,
    val departmentname: String,
    val leaveapplicationtype: String,
    val leavefromdate: String,
    val leavereason: String,
    val leavestatus: String,
    val leavestatusid: String,
    val leavetodate: String,
    val numofdays: String,
    val sectionname: String,
    val semestername: String,
    val studentid: String,
    val studentname: String,
    val yearname: String
)