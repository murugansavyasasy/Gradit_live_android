package com.vsca.vsnapvoicecollege.Model

data class Section_and_Subject(
    val Message: String,
    val Status: Int,
    val `data`: List<sectionnamelist>
)