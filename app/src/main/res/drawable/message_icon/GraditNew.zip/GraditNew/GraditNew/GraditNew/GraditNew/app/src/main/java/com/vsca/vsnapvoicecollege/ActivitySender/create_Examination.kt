package com.vsca.vsnapvoicecollege.ActivitySender

import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import butterknife.BindView
import butterknife.ButterKnife
import butterknife.OnClick
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.vsca.vsnapvoicecollege.Activities.ActionBarActivity
import com.vsca.vsnapvoicecollege.Activities.BaseActivity
import com.vsca.vsnapvoicecollege.Activities.ExamList
import com.vsca.vsnapvoicecollege.Adapters.Adaper_CreateExamination
import com.vsca.vsnapvoicecollege.Model.*
import com.vsca.vsnapvoicecollege.R
import com.vsca.vsnapvoicecollege.Repository.ApiRequestNames
import com.vsca.vsnapvoicecollege.Utils.CommonUtil
import com.vsca.vsnapvoicecollege.Utils.SharedPreference
import com.vsca.vsnapvoicecollege.ViewModel.App

class create_Examination : ActionBarActivity() {

    @JvmField
    @BindView(R.id.create_exam_recycle)
    var create_exam_recycle: RecyclerView? = null

    @JvmField
    @BindView(R.id.imgAdvertisement)
    var imgAdvertisement: ImageView? = null

    @JvmField
    @BindView(R.id.imgthumb)
    var imgthumb: ImageView? = null

    @JvmField
    @BindView(R.id.btn_conform)
    var btn_conform: Button? = null

    @JvmField
    @BindView(R.id.ibi_norecordsfound)
    var ibi_norecordsfound: TextView? = null


    var sectionnamelist: ArrayList<sectionnamelist>? = null


    var adapterExamination: Adaper_CreateExamination? = null
    var appViewModel: App? = null
    var AdWebURl: String? = null
    var PreviousAddId: Int = 0
    var AdBackgroundImage: String? = null
    var AdSmallImage: String? = null

    var GetAdForCollegeData: List<GetAdvertiseData> = ArrayList()


    var Examination_Creation: List<Examination_Creation> = java.util.ArrayList()
    var Sectiondetail_ExamCreation: List<Sectiondetail_ExamCreation> = java.util.ArrayList()
    var Subjectdetail_ExamCreation: List<Subjectdetail_ExamCreation> = java.util.ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        CommonUtil.SetTheme(this)
        super.onCreate(savedInstanceState)
        appViewModel = ViewModelProvider(this).get(App::class.java)
        appViewModel!!.init()
        ButterKnife.bind(this)
        ActionbarWithoutBottom(this)
        SemesterRequest()

        appViewModel!!.AdvertisementLiveData?.observe(
            this,
            Observer<GetAdvertisementResponse?> { response ->
                if (response != null) {
                    val status = response.status
                    val message = response.message
                    if (status == 1) {
                        GetAdForCollegeData = response.data!!
                        for (j in GetAdForCollegeData.indices) {
                            AdSmallImage = GetAdForCollegeData[j].add_image
                            AdBackgroundImage = GetAdForCollegeData[0].background_image!!
                            AdWebURl = GetAdForCollegeData[0].add_url.toString()
                        }
                        Glide.with(this)
                            .load(AdBackgroundImage)
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .into(imgAdvertisement!!)
                        Log.d("AdBackgroundImage", AdBackgroundImage!!)

                        Glide.with(this)
                            .load(AdSmallImage)
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .into(imgthumb!!)
                    }
                }
            })



        appViewModel!!.Examcreationdata!!.observe(this) { response ->
            if (response != null) {
                val status = response.Status
                val message = response.Message

                if (status == 1) {

                    val dlg1 = this.let { AlertDialog.Builder(it) }
                    dlg1.setTitle("Info")
                    dlg1.setMessage(message)
                    dlg1.setPositiveButton("OK", DialogInterface.OnClickListener { dialog, which ->


                        var i = Intent(this, ExamList::class.java)
                        i.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                        startActivity(i)

                    })

                    dlg1.setCancelable(false)
                    dlg1.create()
                    dlg1.show()

                } else {
                    CommonUtil.ApiAlert(this, message)
                }

            } else {
                CommonUtil.ApiAlert(this, "Something went wrong")
            }
        }

        appViewModel!!.Examsectionlist!!.observe(this) { response ->
            if (response != null) {
                val status = response.Status
                val message = response.Message
                if (status == 1) {
                    sectionnamelist = response.data as ArrayList<sectionnamelist>

                    CommonUtil.seleteddataArray.clear()
                    adapterExamination = Adaper_CreateExamination(sectionnamelist!!, this)
                    val mLayoutManager: RecyclerView.LayoutManager = LinearLayoutManager(this)
                    create_exam_recycle!!.layoutManager = mLayoutManager
                    create_exam_recycle!!.itemAnimator = DefaultItemAnimator()
                    create_exam_recycle!!.adapter = adapterExamination
                    create_exam_recycle!!.recycledViewPool.setMaxRecycledViews(0, 80)
                    adapterExamination!!.notifyDataSetChanged()
                } else {
                    CommonUtil.ApiAlert(this, "No Data Found")
                }
            } else {
                CommonUtil.ApiAlert(this, "Something went wrong")
            }
        }

        btn_conform!!.setOnClickListener {

            val alertDialog: AlertDialog.Builder = AlertDialog.Builder(this@create_Examination)
            alertDialog.setTitle("info")
            alertDialog.setMessage("Are you want to submit your exam schedule...")
            alertDialog.setPositiveButton(
                "yes"
            ) { _, _ ->

                Examcreation()

            }
            alertDialog.setNegativeButton(
                "No"
            ) { _, _ -> }
            val alert: AlertDialog = alertDialog.create()
            alert.setCanceledOnTouchOutside(false)
            alert.show()

        }
    }

    private fun SemesterRequest() {
        val jsonObject = JsonObject()
        run {
            jsonObject.addProperty(ApiRequestNames.Req_userid, CommonUtil.MemberId)
            jsonObject.addProperty(ApiRequestNames.Req_appid, "1")
            jsonObject.addProperty("semesterid", CommonUtil.semesterid)

            appViewModel!!.Examsectionandsubject(jsonObject, this)
            Log.d("SemesterSection:", jsonObject.toString())
        }
    }

    private fun AdForCollegeApi() {

        val mobilenumber = SharedPreference.getSH_MobileNumber(this)
        val devicetoken = SharedPreference.getSH_DeviceToken(this)
        val jsonObject = JsonObject()
        jsonObject.addProperty(ApiRequestNames.Req_ad_device_token, devicetoken)
        jsonObject.addProperty(ApiRequestNames.Req_MemberID, CommonUtil.MemberId)
        jsonObject.addProperty(ApiRequestNames.Req_mobileno, mobilenumber)
        jsonObject.addProperty(ApiRequestNames.Req_college_id, CommonUtil.CollegeId)
        jsonObject.addProperty(ApiRequestNames.Req_priority, CommonUtil.Priority)
        jsonObject.addProperty(ApiRequestNames.Req_previous_add_id, PreviousAddId)
        appviewModelbase!!.getAdforCollege(jsonObject, this)
        Log.d("AdForCollege:", jsonObject.toString())

        PreviousAddId = PreviousAddId + 1
        Log.d("PreviousAddId", PreviousAddId.toString())
    }

    // REFERANCE WITHOUT ARRAY LIST

    private fun Examcreation() {


//        for (i in 0 until CommonUtil.Examination_Creation.size){
//            Log.d("Exadfghjk","dfghjk")
//            val jsonObject = JsonObject()
//            jsonObject.addProperty(ApiRequestNames.Req_collegeid,CommonUtil.Examination_Creation[i].collegeid)
//            jsonObject.addProperty(ApiRequestNames.Req_staffid,CommonUtil.Examination_Creation[i].staffid)
//            jsonObject.addProperty(ApiRequestNames.Req_examid,CommonUtil.Examination_Creation[i].examid)
//            jsonObject.addProperty("examname",CommonUtil.Examination_Creation[i].examname)
//            jsonObject.addProperty("startdate",CommonUtil.Examination_Creation[i].startdate)
//            jsonObject.addProperty("enddate",CommonUtil.Examination_Creation[i].enddate)
//            jsonObject.addProperty("processtype",CommonUtil.Examination_Creation[i].processtype)
//
//            val sectiondetails = JsonArray()
//
//            Sectiondetail_ExamCreation=CommonUtil.Examination_Creation[i].Sectiondetails
//
//            for (k in 0 until Sectiondetail_ExamCreation.size){
//
//                val sectiondetailsobject = JsonObject()
//                sectiondetailsobject.addProperty("clgsectionid", Sectiondetail_ExamCreation[k].clgsectionid)
//                sectiondetails.add(sectiondetails)
//
//
//                Subjectdetail_ExamCreation=Sectiondetail_ExamCreation[k].Subjectdetails
//
//                for (j in 0 until Subjectdetail_ExamCreation.size){
//
//                    val subjectdetails = JsonObject()
//                    val subjectarray=JsonArray()
//                    subjectdetails.addProperty("examsubjectid", Subjectdetail_ExamCreation[j].examsubjectid)
//                    subjectdetails.addProperty("examdate", Subjectdetail_ExamCreation[j].examdate)
//                    subjectdetails.addProperty("examsyllabus", Subjectdetail_ExamCreation[j].examsyllabus)
//                    subjectdetails.addProperty("examvenue", Subjectdetail_ExamCreation[j].examvenue)
//                    subjectdetails.addProperty("examsession", Subjectdetail_ExamCreation[j].examsession)
//                    subjectarray.add(subjectdetails)
//                    sectiondetailsobject.add("Subjectdetails", subjectarray)
//                }
//            }
//            jsonObject.add("sectiondetails", sectiondetails)
//            appviewModelbase!!.Examcreation(jsonObject, this)
//            Log.d("Examcreation:", jsonObject.toString())
//
//        }


        val jsonObject = JsonObject()
        jsonObject.addProperty(ApiRequestNames.Req_collegeid, CommonUtil.CollegeId)
        jsonObject.addProperty(ApiRequestNames.Req_staffid, CommonUtil.MemberId)
        jsonObject.addProperty(ApiRequestNames.Req_examid, "0")
        jsonObject.addProperty("examname", CommonUtil.Examname)
        jsonObject.addProperty("startdate", CommonUtil.startdate)
        jsonObject.addProperty("enddate", CommonUtil.enddate)
        jsonObject.addProperty("processtype", "add")


        val sectiondetails = JsonArray()

        for (k in 0 until CommonUtil.Sectiondetail_ExamCreation.size) {

            val sectiondetailsobject = JsonObject()
            sectiondetailsobject.addProperty("clgsectionid", CommonUtil.Sectiondetail_ExamCreation[k].clgsectionid)
            sectiondetails.add(sectiondetailsobject)




            for (i in 0 until CommonUtil.Subjectdetail_ExamCreation.size) {

                val subjectdetails = JsonObject()
                val subjectdetailsarray = JsonArray()

                subjectdetails.addProperty(
                    "examsubjectid",
                    CommonUtil.Subjectdetail_ExamCreation[i].examsubjectid
                )
                subjectdetails.addProperty(
                    "examdate",
                    CommonUtil.Subjectdetail_ExamCreation[i].examdate
                )
                subjectdetails.addProperty(
                    "examsyllabus",
                    CommonUtil.Subjectdetail_ExamCreation[i].examsyllabus
                )
                subjectdetails.addProperty(
                    "examvenue",
                    CommonUtil.Subjectdetail_ExamCreation[i].examvenue
                )
                subjectdetails.addProperty(
                    "examsession",
                    CommonUtil.Subjectdetail_ExamCreation[i].examsession
                )

                subjectdetailsarray.add(subjectdetails)
                sectiondetailsobject.add("Subjectdetails", subjectdetailsarray)

            }
        }
        jsonObject.add("sectiondetails", sectiondetails)

        appviewModelbase!!.Examcreation(jsonObject, this)
        Log.d("Examcreation:", jsonObject.toString())

    }

    override val layoutResourceId: Int
        get() = R.layout.activity_create_examination

    @OnClick(R.id.LayoutAdvertisement)
    fun adclick() {
        BaseActivity.LoadWebViewContext(this, AdWebURl)
    }

    override fun onResume() {
        var AddId: Int = 1
        PreviousAddId = PreviousAddId + 1
        AdForCollegeApi()
        super.onResume()
    }

    @OnClick(R.id.imgback)
    fun imgback() {
        onBackPressed()
    }
}