package com.vsca.vsnapvoicecollege.Model

data class DataXX(
    val ivrheader: String
)