package com.vsca.vsnapvoicecollege.Model

data class VideoParticulertype(
    val Message: String,
    val Status: Int,
    val `data`: List<DataXXXXXX>
)