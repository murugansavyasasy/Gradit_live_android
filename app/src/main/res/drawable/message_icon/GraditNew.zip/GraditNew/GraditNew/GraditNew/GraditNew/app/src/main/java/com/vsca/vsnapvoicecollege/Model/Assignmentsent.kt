package com.vsca.vsnapvoicecollege.Model

data class Assignmentsent(
    val Message: String,
    val Status: Int
)