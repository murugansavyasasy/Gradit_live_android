package com.vsca.vsnapvoicecollege.Model

data class VoiceSendModelClass(
    val ivrheader: String
)