package com.vsca.vsnapvoicecollege.Adapters

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import butterknife.BindView
import butterknife.ButterKnife
import com.vsca.vsnapvoicecollege.Model.*
import com.vsca.vsnapvoicecollege.R
import com.vsca.vsnapvoicecollege.Utils.CommonUtil
import java.util.ArrayList

class Adaper_CreateExamination(private val data: ArrayList<sectionnamelist>, context: Context) :
    RecyclerView.Adapter<Adaper_CreateExamination.MyViewHolder>() {
    var sectionlist: List<sectionnamelist> = ArrayList()
    var context: Context
    var Position: Int = 0
    var Subject_List: Subject_List? = null
    var mExpandedPosition = -1

    var Examination_Creation: ArrayList<Examination_Creation> = java.util.ArrayList()
  //  var Sectiondetail_ExamCreation: ArrayList<Sectiondetail_ExamCreation> = java.util.ArrayList()
    var Subjectdetail_ExamCreation: ArrayList<Subjectdetail_ExamCreation> = java.util.ArrayList()

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): Adaper_CreateExamination.MyViewHolder {
        val itemView: View = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.create_examination, parent, false)
        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: Adaper_CreateExamination.MyViewHolder, position: Int) {

        val data: sectionnamelist = sectionlist.get(position)
        if (data.sectionname.equals("")) {

            holder.txt_section!!.text = "No Records Found"
        }
        val isExpanded = position == mExpandedPosition

        holder.txt_section!!.setText(data.sectionname)

        val itemViewchild = LinearLayoutManager(holder.subject_recyclerview!!.getContext(), LinearLayoutManager.VERTICAL, false)

        itemViewchild.setInitialPrefetchItemCount(data.subjectdetails.size)

        holder.constrine_first!!.setOnClickListener {

            if (isExpanded) {

                mExpandedPosition = if (isExpanded) -1 else position
                holder.subject_recyclerview!!.visibility = View.GONE
                notifyDataSetChanged()
                holder.tick!!.setBackgroundResource(R.drawable.tick_white)
                holder.down!!.setBackgroundResource(R.drawable.down_arrow_white)

            } else {

                CommonUtil.SectionId = data.sectionid

                CommonUtil.Sectiondetail_ExamCreation.add(Sectiondetail_ExamCreation(CommonUtil.SectionId))

                holder.tick!!.setBackgroundResource(R.drawable.examinatin_changeexpandclolur)
                holder.down!!.setBackgroundResource(R.drawable.ic_arrow_up_white)

                mExpandedPosition = if (isExpanded) -1 else position
                holder.subject_recyclerview!!.visibility = View.VISIBLE
                notifyDataSetChanged()

            }

            Subject_List = Subject_List(data.subjectdetails, context)
            holder.subject_recyclerview!!.layoutManager = itemViewchild
            holder.subject_recyclerview!!.itemAnimator = DefaultItemAnimator()
            holder.subject_recyclerview!!.adapter = Subject_List
            holder.subject_recyclerview!!.recycledViewPool.setMaxRecycledViews(0, 80)
            Subject_List!!.notifyDataSetChanged()

        }
    }

    override fun getItemCount(): Int {
        return sectionlist.size
    }

    inner class MyViewHolder constructor(itemView: View?) : RecyclerView.ViewHolder(
        (itemView)!!
    ) {

        @JvmField
        @BindView(R.id.constrine_first)
        var constrine_first: ConstraintLayout? = null

        @JvmField
        @BindView(R.id.txt_section)
        var txt_section: TextView? = null


        @JvmField
        @BindView(R.id.down)
        var down: TextView? = null


        @JvmField
        @BindView(R.id.tick)
        var tick: TextView? = null

        @JvmField
        @BindView(R.id.subject_recyclerview)
        var subject_recyclerview: RecyclerView? = null

        init {
            ButterKnife.bind(this, (itemView)!!)
        }
    }

    init {
        sectionlist = data
        this.context = context
    }
}