package com.vsca.vsnapvoicecollege.Model

data class subjectlist(
    val subject_category: String,
    val subject_code: String,
    val subject_credits: String,
    val subject_id: String,
    val subject_name: String,
    val subject_requirement: String,
    val subject_type: String
)