package com.vsca.vsnapvoicecollege.Model

data class ChatStudent_List(
    val answer: String,
    val answeredon: String,
    val createdon: String,
    val myquestion: String,
    val question: String,
    val questionid: String,
    val studentid: String,
    val studentname: String
)