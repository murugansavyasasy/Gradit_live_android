package com.vsca.vsnapvoicecollege.Activities

import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import butterknife.BindView
import butterknife.ButterKnife
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.vsca.vsnapvoicecollege.Adapters.Attendance_Edit_Adapter
import com.vsca.vsnapvoicecollege.Model.*
import com.vsca.vsnapvoicecollege.R
import com.vsca.vsnapvoicecollege.Repository.ApiRequestNames
import com.vsca.vsnapvoicecollege.Utils.CommonUtil
import com.vsca.vsnapvoicecollege.ViewModel.App

class Spectfice_TakeAttendance : ActionBarActivity() {

    var appViewModel: App? = null
    var Specific_StudentList: Specific_StudentList? = null
    var Attendance_Edit_Adapter: Attendance_Edit_Adapter? = null
    var getspecifictuterstudent: List<specificStudent_datalist> = ArrayList()
    var Attendance_Edit: List<Attendance_edit_List> = ArrayList()
    var AttendanceStatus: String? = null
    var Attendancestatus: String? = null


    @JvmField
    @BindView(R.id.recycle_specificstudentAttendance)
    var recycle_specificstudentAttendance: RecyclerView? = null

    @JvmField
    @BindView(R.id.btn_takeattendance)
    var btn_takeattendance: Button? = null


    override fun onCreate(savedInstanceState: Bundle?) {

        CommonUtil.SetTheme(this)
        super.onCreate(savedInstanceState)
        appViewModel = ViewModelProvider(this).get(App::class.java)
        appViewModel!!.init()
        ButterKnife.bind(this)
        ActionbarWithoutBottom(this)


        AttendanceStatus = intent.getStringExtra("EditAttendance")
        Log.d("AttendanceStatus", AttendanceStatus.toString())
        Attendancestatus = intent.getStringExtra("Attendance")


        appViewModel!!.MarkAttendance!!.observe(this) { response ->
            if (response != null) {
                val status = response.Status
                val message = response.Message
                if (status != null) {
                    if (status==1) {

                    } else {

//                        val dlg = this@Spectfice_TakeAttendance.let { AlertDialog.Builder(it) }
//                        dlg.setTitle("Info")
//                        dlg.setMessage(message)
//                        dlg.setPositiveButton("OK",
//                            DialogInterface.OnClickListener { dialog, which ->
//
//                                val i: Intent = Intent(this@Spectfice_TakeAttendance, Attendance::class.java)
//                              //  i.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
//                                startActivity(i)
//
//                            })

                         CommonUtil.ApiAlert(this, message)
                    }
                }
            } else {
                CommonUtil.ApiAlert(this, "Something went wrong")
            }
        }

        appViewModel!!.Getspecificstudenttutot!!.observe(this) { response ->

            if (response != null) {
                val status = response.status
                val message = response.message
                if (status == 1) {
                    getspecifictuterstudent = response.data!!
                    Specific_StudentList = Specific_StudentList(getspecifictuterstudent, this)
                    val mLayoutManager: RecyclerView.LayoutManager = LinearLayoutManager(this)
                    recycle_specificstudentAttendance!!.layoutManager = mLayoutManager
                    recycle_specificstudentAttendance!!.itemAnimator = DefaultItemAnimator()
                    recycle_specificstudentAttendance!!.adapter = Specific_StudentList
                    recycle_specificstudentAttendance!!.recycledViewPool.setMaxRecycledViews(0, 80)
                    Specific_StudentList!!.notifyDataSetChanged()
                }
            }
        }


        appViewModel!!.AttendanceEdit!!.observe(this) { response ->

            if (response != null) {
                val status = response.Status
                val message = response.Message
                if (status == 1) {
                    Attendance_Edit = response.data
                    Attendance_Edit_Adapter = Attendance_Edit_Adapter(Attendance_Edit, this)
                    val mLayoutManager: RecyclerView.LayoutManager = LinearLayoutManager(this)
                    recycle_specificstudentAttendance!!.layoutManager = mLayoutManager
                    recycle_specificstudentAttendance!!.itemAnimator = DefaultItemAnimator()
                    recycle_specificstudentAttendance!!.adapter = Attendance_Edit_Adapter
                    recycle_specificstudentAttendance!!.recycledViewPool.setMaxRecycledViews(0, 80)
                    Attendance_Edit_Adapter!!.notifyDataSetChanged()
                }
            }
        }

        btn_takeattendance!!.setOnClickListener {

            if (Attendancestatus.equals("False")) {
                TakeAttendance("edit")
                CommonUtil.PresentlistStudent.clear()
            } else {
                TakeAttendance("add")
                CommonUtil.PresentlistStudent.clear()
            }
        }
    }

    private fun Getspecificstudentdatasubject() {

        val jsonObject = JsonObject()
        jsonObject.addProperty(ApiRequestNames.Req_i_course_id, CommonUtil.Courseid)
        jsonObject.addProperty(ApiRequestNames.Req_collegeid, CommonUtil.CollegeId)
        jsonObject.addProperty(ApiRequestNames.Req_deptid, CommonUtil.deptid)
        jsonObject.addProperty(ApiRequestNames.Req_yearid, CommonUtil.YearId)
        jsonObject.addProperty(ApiRequestNames.Req_sectionid, CommonUtil.SectionId)

        appViewModel!!.getspecificstudentdatasubject(jsonObject, this)
        Log.d("Getspecificsubject", jsonObject.toString())
    }

    private fun Attendance_Edit() {

        val jsonObject = JsonObject()
        jsonObject.addProperty("date", CommonUtil.Selecteddata)
        jsonObject.addProperty("appid", "")
        jsonObject.addProperty("userid", CommonUtil.MemberId)
        jsonObject.addProperty("subjectid", CommonUtil.subjectid)
        jsonObject.addProperty("sectionid", CommonUtil.SectionId)

        appViewModel!!.Attendance_Edit(jsonObject, this)
        Log.d("AttendanceEdit", jsonObject.toString())
    }

    private fun TakeAttendance(statue: String) {

        val jsonObject = JsonObject()

        jsonObject.addProperty("sectionid", CommonUtil.SectionId)
        jsonObject.addProperty("subjectid", CommonUtil.subjectid)
        jsonObject.addProperty("userid", CommonUtil.MemberId)
        jsonObject.addProperty("date", CommonUtil.Selecteddata)
        jsonObject.addProperty("processtype", statue)

        val jsonArrayPresentlist = JsonArray()

        //PRESENT LIST

        for (i in 0 until CommonUtil.PresentlistStudent.size) {
            val jsonObjectPresentlist = JsonObject()

            jsonObjectPresentlist.addProperty("presentmemberid", CommonUtil.PresentlistStudent[i])
            jsonArrayPresentlist.add(jsonObjectPresentlist)
        }

        //ABSENDLIST

        val ABsendArray = JsonArray()

        for (i in 0 until CommonUtil.AttendanceAbsendid.size) {
            val jsonobjectabsend = JsonObject()

            jsonobjectabsend.addProperty("absentmemberid", CommonUtil.AttendanceAbsendid[i])
            ABsendArray.add(jsonobjectabsend)
        }

        jsonObject.add("presentlist", jsonArrayPresentlist)
        jsonObject.add("absentlist", ABsendArray)
        Log.d("jsonoblect", jsonObject.toString())

        appViewModel!!.MarkAttendance(jsonObject, this)
        Log.d("MarkAttendance", jsonObject.toString())

    }

    override val layoutResourceId: Int
        get() = R.layout.activity_spectfice_take_attendance


    override fun onResume() {
        var AddId: Int = 1

        if (AttendanceStatus.equals("AttendanceEdit")) {
            Attendance_Edit()
        } else {
            Getspecificstudentdatasubject()
        }
        super.onResume()
    }
}