package com.vsca.vsnapvoicecollege.Adapters

import android.content.Context
import android.graphics.Color
import android.os.Build
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.recyclerview.widget.RecyclerView
import butterknife.BindView
import butterknife.ButterKnife
import com.vsca.vsnapvoicecollege.Interfaces.LeaveHistoryListener
import com.vsca.vsnapvoicecollege.Model.LeaveHistoryData
import com.vsca.vsnapvoicecollege.R
import com.vsca.vsnapvoicecollege.Utils.CommonUtil

class LeaveHistoryAdapter(
    var leavelist: List<LeaveHistoryData>,
    private val context: Context?,
    val leaveListener: LeaveHistoryListener
) : RecyclerView.Adapter<LeaveHistoryAdapter.MyViewHolder>() {

    companion object {
        var leavelistenerClick: LeaveHistoryListener? = null
    }

    var mExpandedPosition = -1

    var Position: Int = 0

    inner class MyViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        @JvmField
        @BindView(R.id.lblLeaveCreatedDate)
        var lblLeaveCreatedDate: TextView? = null

        @JvmField
        @BindView(R.id.lblleaveStatus)
        var lblleaveStatus: TextView? = null

        @JvmField
        @BindView(R.id.lblLeaveType)
        var lblLeaveType: TextView? = null

        @JvmField
        @BindView(R.id.lblLeaveNoOfDays)
        var lblLeaveNoOfDays: TextView? = null

        @JvmField
        @BindView(R.id.lblFromDate)
        var lblFromDate: TextView? = null

        @JvmField
        @BindView(R.id.lblToDate)
        var lblToDate: TextView? = null

        @JvmField
        @BindView(R.id.rytLeaveDescription)
        var rytLeaveDescription: RelativeLayout? = null

        @JvmField
        @BindView(R.id.lblLeaveReason)
        var lblLeaveReason: TextView? = null

        @JvmField
        @BindView(R.id.lblEditleave)
        var lblEditleave: TextView? = null

        @JvmField
        @BindView(R.id.lblDelete)
        var lblDelete: TextView? = null


        @JvmField
        @BindView(R.id.lnrNoticeboardd)
        var lnrNoticeboardd: LinearLayout? = null

        init {
            ButterKnife.bind(this, (itemView)!!)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.leave_history_design, parent, false)
        return MyViewHolder(itemView)
    }

    @RequiresApi(Build.VERSION_CODES.M)
    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val data = leavelist[position]
        leavelistenerClick = leaveListener
        leavelistenerClick?.onLeaveClick(holder, data)
        val isExpanded = position == mExpandedPosition

        try {

            holder.lblLeaveReason!!.setText(data.leavereason)
            holder.lblLeaveType!!.setText(data.leaveapplicationtype)
            holder.lblLeaveCreatedDate!!.setText(data.createdon)
            holder.lblFromDate!!.setText(data.leavefromdate)
            holder.lblToDate!!.setText(data.leavetodate)
            holder.lblLeaveNoOfDays!!.setText(data.numofdays)

            if (data.leavestatus.equals("4")) {
                holder.lblleaveStatus!!.text = data.leavestatus
            } else {
                holder.lblleaveStatus!!.text = data.leavestatus
            }

            if (data.leavestatus.equals("Rejected")) {
                holder.lblleaveStatus!!.setTextColor(context!!.resources.getColor(R.color.clr_txt_red, null)
                )
            } else if (data.leavestatus.equals("Approved")) {
                holder.lblleaveStatus!!.setTextColor(
                    context!!.resources.getColor(
                        R.color.btn_clr_green,
                        null
                    )
                )
            } else {
                holder.lblleaveStatus!!.setTextColor(
                    context!!.resources.getColor(
                        R.color.black,
                        null
                    )
                )
            }

        } catch (e: NullPointerException) {
            e.printStackTrace()
        }

        holder.lnrNoticeboardd!!.setOnClickListener {

            if (data.leavestatus.equals("WaitingForApproval")) {


                if (isExpanded) {
                    mExpandedPosition = if (isExpanded) -1 else position
                    holder.rytLeaveDescription!!.visibility = View.GONE
                    notifyDataSetChanged()

                } else {

                    mExpandedPosition = if (isExpanded) -1 else position
                    holder.rytLeaveDescription!!.visibility = View.VISIBLE
                    notifyDataSetChanged()
                }

            } else {

                mExpandedPosition = if (isExpanded) -1 else position
                holder.rytLeaveDescription!!.visibility = View.GONE
                notifyDataSetChanged()
            }
        }
    }

    override fun getItemCount(): Int {
        return leavelist.size

    }
}