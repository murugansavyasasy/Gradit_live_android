package com.vsca.vsnapvoicecollege.Model

data class SubjectdetailX(
    val examdate: String,
    val examsession: String,
    val examsubjectid: String,
    val examsubjectname: String,
    val examsyllabus: String,
    val examvenue: String
)