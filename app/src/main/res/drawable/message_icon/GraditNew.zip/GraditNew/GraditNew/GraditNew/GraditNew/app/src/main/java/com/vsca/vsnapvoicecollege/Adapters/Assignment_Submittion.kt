package com.vsca.vsnapvoicecollege.Adapters

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import butterknife.BindView
import butterknife.ButterKnife
import com.vsca.vsnapvoicecollege.Activities.Assignment_MultipleFileView
import com.vsca.vsnapvoicecollege.Model.AssignmentSubmit
import com.vsca.vsnapvoicecollege.Model.Assignment_Submittion
import com.vsca.vsnapvoicecollege.R
import com.vsca.vsnapvoicecollege.Utils.CommonUtil
import java.util.ArrayList


class Assignment_SubmittionAdapter(data: ArrayList<AssignmentSubmit>, context: Context) :
    RecyclerView.Adapter<Assignment_SubmittionAdapter.MyViewHolder>() {
    var subjectdata: List<AssignmentSubmit> = ArrayList()
    var context: Context
    var Assignmnetview: String? = null

    override fun onCreateViewHolder(
        parent: ViewGroup, viewType: Int
    ): Assignment_SubmittionAdapter.MyViewHolder {
        val itemView: View = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.assignment_sumbittion, parent, false)
        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {

        val data: AssignmentSubmit = subjectdata.get(position)

        holder.txt_financeandaccounding!!.setText(data.course)
        holder.txt_student!!.setText(data.studentname)
        holder.txt_bcom_Accounts!!.setText(data.year)
        holder.txt_submited!!.setText(data.message)
        holder.txt_semester1!!.setText(data.semester)


        holder.lnrAttachment!!.setOnClickListener {
            Assignmnetview = "AssignmentData"
            CommonUtil.filetype=""
            val i: Intent = Intent(context, Assignment_MultipleFileView::class.java)
            i.putExtra("Assignment", Assignmnetview)
            CommonUtil.filetype = "Assignment previous Submited"
            CommonUtil.studentid = data.studentid
            context.startActivity(i)

        }
    }

    override fun getItemCount(): Int {
        return subjectdata.size

    }

    inner class MyViewHolder constructor(itemView: View?) : RecyclerView.ViewHolder(
        (itemView)!!
    ) {
        @JvmField
        @BindView(R.id.txt_financeandaccounding)
        var txt_financeandaccounding: TextView? = null

        @JvmField
        @BindView(R.id.txt_undefined)
        var txt_undefined: TextView? = null

        @JvmField
        @BindView(R.id.txt_submited)
        var txt_submited: TextView? = null

        @JvmField
        @BindView(R.id.txt_student)
        var txt_student: TextView? = null

        @JvmField
        @BindView(R.id.txt_bcom_Accounts)
        var txt_bcom_Accounts: TextView? = null

        @JvmField
        @BindView(R.id.img_book)
        var img_book: ImageView? = null

        @JvmField
        @BindView(R.id.txt_semester1)
        var txt_semester1: TextView? = null

        @JvmField
        @BindView(R.id.lnrAttachment)
        var lnrAttachment: LinearLayout? = null


        init {
            ButterKnife.bind(this, (itemView)!!)
        }
    }

    init {
        subjectdata = data
        this.context = context
    }

}