package com.vsca.vsnapvoicecollege.albumImage

import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity


class PDF_Reader : AppCompatActivity() {

    lateinit var webView: WebView

    var Filepath: String? = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(com.vsca.vsnapvoicecollege.R.layout.activity_pdf_reader)

        webView = findViewById(com.vsca.vsnapvoicecollege.R.id.web_view)

        Filepath = intent.getStringExtra("PdfView")!!

        webView.webViewClient = WebViewClient()
        webView.settings.setSupportZoom(true)
        webView.settings.javaScriptEnabled = true
        webView.loadUrl(Filepath!!)
    }
}