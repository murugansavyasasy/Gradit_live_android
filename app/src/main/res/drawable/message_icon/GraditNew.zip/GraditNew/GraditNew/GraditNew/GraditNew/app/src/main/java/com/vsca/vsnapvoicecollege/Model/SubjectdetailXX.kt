package com.vsca.vsnapvoicecollege.Model

data class SubjectdetailXX(
    val examdate: String,
    val examsession: String,
    val examsubjectid: String,
    val examsyllabus: String,
    val examvenue: String
)