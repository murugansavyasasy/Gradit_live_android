package com.vsca.vsnapvoicecollege.Model

data class DataXXXXX(
    val ivrheader: String
)