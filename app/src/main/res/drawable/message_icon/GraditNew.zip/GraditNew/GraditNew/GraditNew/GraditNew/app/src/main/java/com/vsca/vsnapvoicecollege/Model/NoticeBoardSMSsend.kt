package com.vsca.vsnapvoicecollege.Model

data class NoticeBoardSMSsend(
    val Message: String,
    val Status: Int
)