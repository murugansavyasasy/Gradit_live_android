package com.vsca.vsnapvoicecollege.Adapters

import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.recyclerview.widget.RecyclerView
import android.view.ViewGroup
import android.view.LayoutInflater
import com.vsca.vsnapvoicecollege.R
import butterknife.BindView
import butterknife.ButterKnife
import android.view.View
import android.view.View.VISIBLE
import android.widget.*
import androidx.appcompat.app.AlertDialog
import com.google.gson.JsonObject
import com.vsca.vsnapvoicecollege.Activities.Communication
import com.vsca.vsnapvoicecollege.Activities.Noticeboard
import com.vsca.vsnapvoicecollege.Model.Delete_noticeboard
import com.vsca.vsnapvoicecollege.Model.GetNoticeboardDetails
import com.vsca.vsnapvoicecollege.Model.LeaveRequest
import com.vsca.vsnapvoicecollege.Repository.RestClient
import com.vsca.vsnapvoicecollege.Utils.CommonUtil
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.ArrayList

class NoticeBoard constructor(data: List<GetNoticeboardDetails>, context: Context) :
    RecyclerView.Adapter<NoticeBoard.MyViewHolder>() {
    var noticeboarddata: List<GetNoticeboardDetails> = ArrayList()
    var context: Context
    var Position: Int = 0
    private var mExpandedPosition: Int = -1
    var msgcontent: String? = null
    var detailsid: String? = null
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView: View = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.noticeboard_list_design, parent, false)
        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MyViewHolder, positionindex: Int) {
        val data: GetNoticeboardDetails = noticeboarddata.get(positionindex)
        Position = holder.getAbsoluteAdapterPosition()
        holder.rytNoticeboard!!.visibility = VISIBLE
        holder.lnrNoticeboardd!!.setVisibility(View.GONE)
        holder.delete!!.visibility = View.GONE

        holder.lblNoticeboardTitle!!.setText(data.topic)
        holder.lblNoticeboardDescription!!.setText(data.description)
        holder.lblNoticeboardDate!!.setText(data.createdondate)
        holder.lblNoticetime!!.setText(data.createdontime)
        if (data.isappread.equals("0")) {
            holder.lblNewCircle!!.visibility = View.VISIBLE
        } else {
            holder.lblNewCircle!!.visibility = View.GONE
        }
        holder.lblSentByNotice!!.setText(data.sentbyname)

        if (CommonUtil.Priority.equals("p1") || CommonUtil.Priority.equals("p2") || CommonUtil.Priority.equals(
                "p3"
            )
        ) {

            if (data.createdby.toString() != CommonUtil.MemberId.toString()) {
                holder.delete!!.visibility = View.GONE
            } else {
                holder.delete!!.visibility = View.VISIBLE
            }

            holder.delete!!.setOnClickListener {
                CommonUtil.Noticeboardid = data.noticeboardheaderID.toString()
                DeleteNoticeBoard("delete")
            }
        }

    }

    public override fun getItemCount(): Int {
        return noticeboarddata.size
    }

    inner class MyViewHolder constructor(itemView: View?) : RecyclerView.ViewHolder(
        (itemView)!!
    ) {
        @JvmField
        @BindView(R.id.lblNoticeboardTitle1)
        var lblNoticeboardTitle: TextView? = null

        @JvmField
        @BindView(R.id.lblNoticeboardDescription1)
        var lblNoticeboardDescription: TextView? = null

        @JvmField
        @BindView(R.id.lblNoticeboardDate1)
        var lblNoticeboardDate: TextView? = null

        @JvmField
        @BindView(R.id.lblNoticetime1)
        var lblNoticetime: TextView? = null

        @JvmField
        @BindView(R.id.lblNoticePostedby)
        var lblNoticePostedby: TextView? = null

        @JvmField
        @BindView(R.id.rytNotice)
        var rytNotice: RelativeLayout? = null

        @JvmField
        @BindView(R.id.lnrNoticeboardd)
        var lnrNoticeboardd: LinearLayout? = null


        @JvmField
        @BindView(R.id.lblNewCircle)
        var lblNewCircle: TextView? = null

        @JvmField
        @BindView(R.id.rytNoticeboard)
        var rytNoticeboard: RelativeLayout? = null

        @JvmField
        @BindView(R.id.lblSentByNotice)
        var lblSentByNotice: TextView? = null

        @JvmField
        @BindView(R.id.delete)
        var delete: ImageView? = null

        init {
            ButterKnife.bind(this, (itemView)!!)
        }
    }

    init {
        noticeboarddata = data
        this.context = context
    }

    fun DeleteNoticeBoard(type: String) {


        val jsonObject = JsonObject()

        jsonObject.addProperty("noticeboardid", CommonUtil.Noticeboardid)
        jsonObject.addProperty("processtype", type)
        jsonObject.addProperty("colgid", "")
        jsonObject.addProperty("topic", "")
        jsonObject.addProperty("description", "")
        jsonObject.addProperty("staffid", "")
        jsonObject.addProperty("Callertype", "")
        jsonObject.addProperty("receiveridlist", "")
        jsonObject.addProperty("isstudent", "")
        jsonObject.addProperty("isstaff", "")
        jsonObject.addProperty("isparent", "")
        jsonObject.addProperty("receivertype", "")

        Log.d("jsonoblect", jsonObject.toString())

        RestClient.apiInterfaces.DeleteNoticeboarddata(jsonObject)
            ?.enqueue(object : Callback<Delete_noticeboard?> {
                override fun onResponse(
                    call: Call<Delete_noticeboard?>,
                    response: Response<Delete_noticeboard?>
                ) {
                    if (response.code() == 200 || response.code() == 201) {
                        if (response.body() != null) {
                            val response = response.body()!!.Message
                            Log.d("message", response)

                            val alertDialog: AlertDialog.Builder = AlertDialog.Builder(context)
                            alertDialog.setTitle("info")
                            alertDialog.setMessage("Are you want to Delete?")
                            alertDialog.setPositiveButton(
                                "yes"
                            ) { _, _ ->

                                val dlg = context.let { AlertDialog.Builder(it) }
                                dlg.setTitle("Info")
                                dlg.setMessage(response)
                                dlg.setPositiveButton("OK") { dialog, which ->

                                    val i: Intent =

                                        Intent(context, Noticeboard::class.java)
                                    i.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                                    context.startActivity(i)

                                }

                                dlg.setCancelable(false)
                                dlg.create()
                                dlg.show()
                            }

                            alertDialog.setNegativeButton(
                                "No"
                            ) { _, _ -> }
                            val alert: AlertDialog = alertDialog.create()
                            alert.setCanceledOnTouchOutside(false)
                            alert.show()
                        }

                    } else if (response.code() == 400 || response.code() == 404 || response.code() == 500) {

                    }
                }

                override fun onFailure(call: Call<Delete_noticeboard?>, t: Throwable) {

                }

            })
    }
}