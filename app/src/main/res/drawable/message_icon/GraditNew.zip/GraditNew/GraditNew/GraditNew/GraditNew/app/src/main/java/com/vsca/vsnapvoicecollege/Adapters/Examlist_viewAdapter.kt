package com.vsca.vsnapvoicecollege.Adapters

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import butterknife.BindView
import butterknife.ButterKnife
import com.vsca.vsnapvoicecollege.ActivitySender.SubjectList
import com.vsca.vsnapvoicecollege.Interfaces.ExamSubjectclick
import com.vsca.vsnapvoicecollege.Model.examlist
import com.vsca.vsnapvoicecollege.R
import java.util.ArrayList

class Examlist_viewAdapter(
    data: List<examlist>, context: Context, type: Boolean,
    val markListener: ExamSubjectclick
) :
    RecyclerView.Adapter<Examlist_viewAdapter.MyViewHolder>() {


    var eaxmlist: List<examlist> = ArrayList()
    var context: Context
    var Position: Int = 0


    override fun onCreateViewHolder(
        parent: ViewGroup, viewType: Int
    ): Examlist_viewAdapter.MyViewHolder {
        val itemView: View =
            LayoutInflater.from(parent.getContext()).inflate(R.layout.view_examlist, parent, false)
        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: Examlist_viewAdapter.MyViewHolder, position: Int) {
        val data: examlist = eaxmlist.get(position)

        holder.txt_financeandaccounding!!.setText(data.clgdepartmentname)
        holder.txt_testing_creating!!.setText(data.examnm)
        holder.txt_bcom_Accounts!!.setText(data.coursename)
        holder.txt_year1!!.setText(data.yearname)
        holder.txt_semester1!!.setText(data.semestername)
        holder.txt_b_section!!.setText(data.clgsectionname)
        holder.txt_startdate!!.setText(data.startdate)
        holder.txt_enddate!!.setText(data.enddate)

        holder.txt_get_subject!!.setOnClickListener {
            val i = Intent(context, SubjectList::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(i)

        }
    }

    override fun getItemCount(): Int {
        return eaxmlist.size
    }

    inner class MyViewHolder constructor(itemView: View?) : RecyclerView.ViewHolder(
        (itemView)!!
    ) {


        @JvmField
        @BindView(R.id.txt_get_subject)
        var txt_get_subject: TextView? = null

        @JvmField
        @BindView(R.id.examlist_constrine)
        var examlist_constrine: ConstraintLayout? = null


        @JvmField
        @BindView(R.id.txt_financeandaccounding)
        var txt_financeandaccounding: TextView? = null

        @JvmField
        @BindView(R.id.txt_testing_creating)
        var txt_testing_creating: TextView? = null

        @JvmField
        @BindView(R.id.txt_bcom_Accounts)
        var txt_bcom_Accounts: TextView? = null

        @JvmField
        @BindView(R.id.txt_year1)
        var txt_year1: TextView? = null

        @JvmField
        @BindView(R.id.txt_semester1)
        var txt_semester1: TextView? = null

        @JvmField
        @BindView(R.id.txt_b_section)
        var txt_b_section: TextView? = null

        @JvmField
        @BindView(R.id.txt_startdate)
        var txt_startdate: TextView? = null

        @JvmField
        @BindView(R.id.txt_enddate)
        var txt_enddate: TextView? = null

        init {
            ButterKnife.bind(this, (itemView)!!)
        }
    }

    init {
        eaxmlist = data
        this.context = context
    }
}