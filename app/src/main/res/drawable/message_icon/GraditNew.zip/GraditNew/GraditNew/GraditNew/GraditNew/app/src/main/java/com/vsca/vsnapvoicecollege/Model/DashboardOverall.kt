package com.vsca.vsnapvoicecollege.Model


import java.util.ArrayList

class DashboardOverall(var menuHeadings: String,
                       var menusubitemlist: ArrayList<DashboardSubItems>)