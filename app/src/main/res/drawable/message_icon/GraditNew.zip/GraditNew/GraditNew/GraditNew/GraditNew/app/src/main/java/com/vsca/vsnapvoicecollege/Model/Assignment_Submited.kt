package com.vsca.vsnapvoicecollege.Model

data class Assignment_Submited(
    val Message: String,
    val Status: Int
)