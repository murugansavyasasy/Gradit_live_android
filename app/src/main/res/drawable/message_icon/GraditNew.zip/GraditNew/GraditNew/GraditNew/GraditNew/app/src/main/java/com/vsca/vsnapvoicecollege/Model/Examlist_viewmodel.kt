package com.vsca.vsnapvoicecollege.Model

data class Examlist_viewmodel(
    val Message: String,
    val Status: Int,
    val `data`: List<examlist>
)