package com.vsca.vsnapvoicecollege.Model

import com.google.gson.annotations.SerializedName

class VideoRestrictionData {

    @SerializedName("content")
    var content: String? = null

}