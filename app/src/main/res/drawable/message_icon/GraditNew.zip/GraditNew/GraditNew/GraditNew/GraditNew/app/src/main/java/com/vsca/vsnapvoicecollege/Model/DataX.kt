package com.vsca.vsnapvoicecollege.Model

data class DataX(
    val courseid: String,
    val coursename: String,
    val isclassteacher: String,
    val sectionid: String,
    val sectionname: String,
    val semesterid: String,
    val semestername: String,
    val subjectid: String,
    val subjectname: String,
    val yearid: String,
    val yearname: String
)