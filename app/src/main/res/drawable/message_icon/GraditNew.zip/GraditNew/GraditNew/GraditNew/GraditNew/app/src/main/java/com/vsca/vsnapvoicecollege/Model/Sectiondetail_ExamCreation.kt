

package com.vsca.vsnapvoicecollege.Model

class Sectiondetail_ExamCreation {

    var clgsectionid: String? = null
   // var Subjectdetails = ArrayList<Subjectdetail_ExamCreation>()

    constructor(


        clgsectionid: String?
      //  Subjectdetails: List<Subjectdetail_ExamCreation>

    ) {
        this.clgsectionid = clgsectionid
       // this.Subjectdetails = Subjectdetails as ArrayList<Subjectdetail_ExamCreation>
    }
}
