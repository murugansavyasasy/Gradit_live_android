package com.vsca.vsnapvoicecollege.Model

data class Examdeletedata(
    val ivrheader: String
)