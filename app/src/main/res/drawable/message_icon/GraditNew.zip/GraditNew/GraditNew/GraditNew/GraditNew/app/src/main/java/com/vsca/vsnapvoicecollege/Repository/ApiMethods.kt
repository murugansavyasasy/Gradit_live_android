package com.vsca.vsnapvoicecollege.Repository

object ApiMethods {
    const val Country = "api/AppDetailsBal/Getcountrylist"
    const val VersionCheck = "api/AppDetailsBal/VersionCheck"
    const val Login = "api/AppDetailsBal/LoginFromApp"
    const val Dashboard = "api/AppDetailsBal/DashboardApi"
    const val UserMenus = "api/AppDetailsBal/GetUsermenu"
    const val GetNotifications = "api/AppDetailsBal/GetNotificationForCollege"
    const val GetCourseDetails = "api/AppDetailsBal/GetSubjectDetailsForSemester"
    const val GetProfileDetails = "api/AppDetailsBal/GetProfileDetails"
    const val GetExamApplicationDetails = "api/AppDetailsBal/getExamApplicationDetails"
    const val GetNoticeboardListbyType = "api/AppDetailsBal/GetNoticeListByType"
    const val DeleteNoticeboard = "/api/AppDetailsBal/ManageNoticeBoard"
    const val GetCircularListbyType = "api/AppDetailsBal/GetCircularListByType"
    const val GetAssignmentListByType = "api/AppDetailsBal/GetAssignmentListByType"
    const val GetAssignmentMemberCount = "api/AppDetailsBal/GetAssignmentMemberCount"
    const val ViewAssignmentContent = "api/AppDetailsBal/ViewAssignmentContent"
    const val Appreadstatus = "api/AppDetailsBal/Appreadstatus"
    const val GetEventListByType = "api/AppDetailsBal/GetEventListByType"
    const val GetCommunicationMessageBytype = "api/AppDetailsBal/GetCommunicationMessageBytype"
    const val GetOverallcountByMenuType = "api/AppDetailsBal/GetOverallcountByMenuType"
    const val FacultyList = "api/AppDetailsBal/FacultyListforPrincipalLoginSenderApp"
    const val Fcultylistforreveiver = "/api/AppDetailsBal/FacultyList"
    const val semesterandsectionListforApp = "api/AppDetailsBal/semesterandsectionListforApp"

    const val GetExamListByType = "api/AppDetailsBal/GetExamListByTypeforsenderapp"
        const val GetExamListByTypereciver = "api/AppDetailsBal/GetExamListByType"

    const val GetStudentMarkDetailsForApp = "api/AppDetailsBal/GetStudentMarkDetailsForApp"
    const val GetVideoList = "api/AppDetailsBal/GetVideoList"
    const val getsemesterlistforcourseid = "api/AppDetailsBal/getsemesterlistforcourseid"
    const val semesterwisestudentcreditdetails =
        "api/AppDetailsBal/semesterwisestudentcreditdetails"
    const val semesterwisestudentcreditdetailsall =
        "api/AppDetailsBal/semesterwisestudentcreditdetailsall"
    const val getcategorylistforclgeid = "api/AppDetailsBal/getcategorylistforclgeid"
    const val categorywisestudentcreditdetails =
        "api/AppDetailsBal/categorywisestudentcreditdetails"
    const val getattendanceforparent = "api/AppDetailsBal/getattendanceforparent"


    const val GetLeaveApplicationListForReceiverApp =
        "api/AppDetailsBal/GetLeaveApplicationListForReceiverApp"

    const val GetLeaveType = "api/AppDetailsBal/GetLeaveType"
    const val changepassword = "api/AppDetailsBal/changepassword"
    const val GetstaffdetailsForApp = "api/AppDetailsBal/GetstaffdetailsForApp"
    const val GetStaffClassesforChatForApp = "api/AppDetailsBal/GetStaffClassesforChatForApp"
    const val GetAddsForCollege = "api/AppDetailsBal/GetAddsForCollege"
    const val UpdateDeviceToken = "api/AppDetailsBal/DeviceToken"
    const val GetVideoContentRestriction = "api/AppDetailsBal/GetVideoContentRestriction"

    //SenderApi

    const val GetDivisions = "api/AppDetailsBal/GetDivisions"
    const val GetDepartment = "api/AppDetailsBal/GetDepartmentsbyDivision"
    const val GetCoursesByDepartment = "api/AppDetailsBal/GetCoursesByDepartment"
    const val SendSMSToParticularType = "api/AppDetailsBal/SendSMSToParticularType"
    const val SendSMSToEntireCollege = "api/AppDetailsBal/SendSMSToEntireCollege"

    const val SendVoiceToEntireCollege = "api/AppDetailsBal/SendFileToEntireCollege"


    const val SendSMSToEntiretutorandsubjectCollege =
        "api/AppDetailsBal/SendSMSToParticularTypeFromTutor"
    const val GetGroup = "api/AppDetailsBal/GetGrouplist"
    const val Getsubject = "api/AppDetailsBal/GetSubjectListforparticularstaff"
    const val Gettuter = "api/AppDetailsBal/GetClassListForTutor"
    const val Getspecificstudenttuter = "api/AppDetailsBal/GetMentorstudentListforapp"
    const val Getsubjectspecifistudent = "api/AppDetailsBal/GetstudentListforapp"
    const val Getdepartmnetcourse = "api/AppDetailsBal/GetCoursesByDepartment"
    const val GetYearandsection = "api/AppDetailsBal/YearAndSectionListforApp"
    const val Noticeboardsendsms = "api/AppDetailsBal/ManageNoticeBoard"
    const val Eventsenddata = "api/AppDetailsBal/ManageEventsFromTutor"
    const val ImageorPdf = "api/AppDetailsBal/SendImageOrPDFToEntireCollegeWithCloudURL"
    const val Imageorpdfparticuler = "/api/AppDetailsBal/SendImageOrPDFToParticularTypeWithCloudURL"
    const val Assignmentsenddata = "api/AppDetailsBal/ManageAssignmentWithCloudURL"
    const val AttendanceTaking = "api/AppDetailsBal/MarkAttendance"
    const val ManageLeaveApplication = "api/AppDetailsBal/ManageLeaveapplication"
    const val GetLeaveapplicationListforsenderapp =
        "api/AppDetailsBal/GetLeaveApplicationListForSenderApp"
    const val Examsectionandsubject = "api/AppDetailsBal/getsectionwisesubjectlist"

    const val ExamCreation = "api/AppDetailsBal/ExamCreation"
    const val Examviewapi = "api/AppDetailsBal/GetDetailsForExamEdit"
    const val Examdelete = "/api/AppDetailsBal/ExamCreation"
    const val TakeAttendance = "/api/AppDetailsBal/MarkAttendance"

    // const val ManageLeaveRequest="api/AppDetailsBal/ManageLeaveRequest"
    const val VideoEntireSend = "/api/AppDetailsBal/SendVideoToEntireCollege"
    const val VideoParticulerSend = "/api/AppDetailsBal/SendVideoToParticularType"
    const val Eventphotoupdate = "api/AppDetailsBal/AddeventphotosWithCloudURL"
    const val Assignmentforward = "api/AppDetailsBal/ForwardAssignment"
    const val Chatdatalist = "api/AppDetailsBal/GetStudentChatScreenForApp"
    const val ChatStudent = "api/AppDetailsBal/StudentAskQuestionForApp"
    const val Sendersidechat = "api/AppDetailsBal/GetStaffChatScreenForApp"
    const val ChatStaff="api/AppDetailsBal/AnswerStudentQuestionForApp"

    const val Assignmentsubmited = "api/AppDetailsBal/SubmitAssignmentFromAppWithCloudURL"
    const val AssignmentSubmittion = "api/AppDetailsBal/GetAssignmentMemberCount"
    const val Attendance_Check = "api/AppDetailsBal/CheckForAttendanceMarking"
    const val Attendance_Edit = "api/AppDetailsBal/Getlistforattendanceedit"
    const val AssignmentView = "api/AppDetailsBal/ViewAssignmentContent"
    const val BlackStudent="api/AppDetailsBal/BlockStudentForApp"
    const val UnblackStudent="api/AppDetailsBal/UnblockStudentForApp"


}