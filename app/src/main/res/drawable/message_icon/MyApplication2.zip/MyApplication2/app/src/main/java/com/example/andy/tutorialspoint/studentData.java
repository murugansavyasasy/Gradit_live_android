package com.example.andy.tutorialspoint;

class studentData {
    String name;
    int age;
    public studentData(String name, int age) {
        this.name=name;
        this.age=age;
    }
}
