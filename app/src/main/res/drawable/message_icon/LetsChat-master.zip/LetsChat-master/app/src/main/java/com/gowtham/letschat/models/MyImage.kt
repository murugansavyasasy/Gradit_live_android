package com.gowtham.letschat.models

data class MyImage(val url: String)