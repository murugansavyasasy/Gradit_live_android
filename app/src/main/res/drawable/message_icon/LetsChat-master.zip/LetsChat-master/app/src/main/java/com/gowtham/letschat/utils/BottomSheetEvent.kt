package com.gowtham.letschat.utils

data class BottomSheetEvent(var position: Int)