package com.gowtham.letschat.models


data class Contact(var name: String,var mobile: String)