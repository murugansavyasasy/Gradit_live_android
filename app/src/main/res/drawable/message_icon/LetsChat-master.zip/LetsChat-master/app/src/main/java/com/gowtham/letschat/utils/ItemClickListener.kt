package com.gowtham.letschat.utils

import android.view.View

interface ItemClickListener {
    fun onItemClicked(v: View, position: Int)
}