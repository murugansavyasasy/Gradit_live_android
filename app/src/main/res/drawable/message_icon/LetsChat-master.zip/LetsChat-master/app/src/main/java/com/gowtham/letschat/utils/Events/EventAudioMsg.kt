package com.gowtham.letschat.utils.Events

class EventAudioMsg(val isPlaying: Boolean)