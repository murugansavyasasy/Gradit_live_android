package com.gowtham.letschat.utils

interface OnSuccessListener {
    fun onResult(success: Boolean,data: Any?=null)
}