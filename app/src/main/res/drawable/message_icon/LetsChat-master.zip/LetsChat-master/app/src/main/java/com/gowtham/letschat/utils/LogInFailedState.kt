package com.gowtham.letschat.utils

enum class LogInFailedState {
    Verification,
    SignIn
}