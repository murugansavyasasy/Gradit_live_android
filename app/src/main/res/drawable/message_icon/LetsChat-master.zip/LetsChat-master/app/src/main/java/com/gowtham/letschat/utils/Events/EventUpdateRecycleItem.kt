package com.gowtham.letschat.utils.Events

class EventUpdateRecycleItem(val adapterPosition: Int)