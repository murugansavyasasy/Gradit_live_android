package com.gowtham.letschat.utils

class ConnectionChangeEvent(val message: String)
